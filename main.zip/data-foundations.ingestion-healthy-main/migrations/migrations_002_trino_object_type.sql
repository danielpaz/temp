-- 2026-10-09: o objeto do Trino de cada tabela pode ser uma tabela ou uma view; para a view guardamos o DDL
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS trino_object_type text CHECK (trino_object_type IN ('TABLE', 'VIEW'));
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS trino_object_ddl text;
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS trino_object_checked_at timestamptz;

-- What the filter/group column is: a date or timestamp (compared by day) or an id (compared up to the largest id in Trino).
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS filter_kind text NOT NULL DEFAULT 'date' CHECK (filter_kind IN ('date', 'id'));
ALTER TABLE table_result ADD COLUMN IF NOT EXISTS last_id bigint;
ALTER TABLE table_result_history ADD COLUMN IF NOT EXISTS last_id bigint;

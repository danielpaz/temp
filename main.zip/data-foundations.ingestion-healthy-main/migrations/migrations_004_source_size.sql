ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS source_size_bytes bigint;
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS source_size_checked_at timestamptz;

-- Migration validation (SQL Server -> Aurora PostgreSQL): the list of databases
-- and every validation run registered for them. Additive and idempotent.
CREATE TABLE IF NOT EXISTS migration_database (
    name            text PRIMARY KEY,
    host_sql        text NOT NULL DEFAULT '',
    host_postgresql text NOT NULL DEFAULT '',
    note            text NOT NULL DEFAULT '',
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS migration_validation (
    id            bigserial PRIMARY KEY,
    database_name text NOT NULL
        REFERENCES migration_database (name) ON DELETE CASCADE,
    captured_at   timestamptz NOT NULL,
    source_db     text NOT NULL,
    target_db     text NOT NULL,
    target_schema text,
    attention     int NOT NULL,
    review        int NOT NULL,
    ok            int NOT NULL,
    tables        int NOT NULL,
    resources     jsonb NOT NULL DEFAULT '{}'::jsonb,
    report        jsonb NOT NULL,
    registered_at timestamptz NOT NULL DEFAULT now(),
    registered_by text NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS migration_validation_latest_idx
    ON migration_validation (database_name, registered_at DESC, id DESC);

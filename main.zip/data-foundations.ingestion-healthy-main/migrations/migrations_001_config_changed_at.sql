-- 2026-10-08: marca a última mudança de configuração que invalida o resultado atual
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS config_changed_at timestamptz;

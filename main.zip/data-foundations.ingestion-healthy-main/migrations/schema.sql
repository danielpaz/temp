-- Ingestion Healthy: dados do app. Rodar como o próprio svc_ingestion_healthy, com search_path = ingestion_healthy.

CREATE OR REPLACE FUNCTION touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END $$;

-- Uma linha por tabela monitorada: é a configuração que hoje vive em table_list_date_fields.csv. Editável pela tela.
CREATE TABLE monitored_table (
    id              bigserial PRIMARY KEY,
    source_database text NOT NULL,
    source_schema   text NOT NULL,
    source_table    text NOT NULL,
    source_host     text,                       -- host do CSV de origem
    used_host       text,                       -- host de fato usado na conexão
    used_secret     text,                       -- nome do secret (não a credencial)
    target_catalog  text NOT NULL,
    target_schema   text NOT NULL,
    target_table    text NOT NULL,
    has_date_field  boolean NOT NULL DEFAULT false,
    date_field      text,
    trino_col_type  text,                       -- ex.: timestamp(3), timestamp(6) with time zone, date
    trino_day_mode  text NOT NULL DEFAULT 'sp' CHECK (trino_day_mode IN ('sp', 'utc')),   -- o dia é contado em America/Sao_Paulo ou em UTC
    mode_source     text CHECK (mode_source IN ('type', 'calibrated', 'calibrated_margin', 'calibrated_low', 'default_tie', 'manual')),
    enabled         boolean NOT NULL DEFAULT true,
    trino_object_type text CHECK (trino_object_type IN ('TABLE', 'VIEW')),   -- o objeto do Trino é tabela ou view
    trino_object_ddl  text,                     -- DDL da view (SHOW CREATE VIEW); vazio para tabela
    trino_object_checked_at timestamptz,
    source_size_bytes bigint,                   -- tamanho dos dados da tabela na origem, sem índices
    source_size_checked_at timestamptz,
    source_ddl text,                            -- DDL da tabela transacional, montado a partir do catálogo da origem
    source_indexes jsonb,                       -- índices da tabela transacional: nome, colunas, include, filtro e definição
    source_col_count integer,
    source_ddl_checked_at timestamptz,
    filter_kind text NOT NULL DEFAULT 'date' CHECK (filter_kind IN ('date', 'id')),   -- o campo de filtro/agrupamento é data/timestamp ou id
    config_changed_at timestamptz,              -- última mudança que invalida o resultado atual (nomes, secret, coluna, modo)
    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now(),
    updated_by      text
);
CREATE UNIQUE INDEX monitored_table_row_uq ON monitored_table
    (lower(source_database), lower(source_schema), lower(source_table), lower(target_catalog), lower(target_schema), lower(target_table));
CREATE TRIGGER monitored_table_touch BEFORE UPDATE ON monitored_table FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE TABLE table_tag (
    table_id   bigint NOT NULL REFERENCES monitored_table (id) ON DELETE CASCADE,
    tag        text NOT NULL CHECK (tag <> ''),
    created_at timestamptz NOT NULL DEFAULT now(),
    created_by text,
    PRIMARY KEY (table_id, tag)
);
CREATE INDEX table_tag_tag_idx ON table_tag (tag);

-- Histórico de execuções.
CREATE TABLE run (
    run_id       text PRIMARY KEY,
    status       text NOT NULL,
    full_run     boolean NOT NULL DEFAULT false,
    period_from  date NOT NULL,
    period_to    date NOT NULL,
    requested_by text,
    started_at   timestamptz NOT NULL DEFAULT now(),
    finished_at  timestamptz,
    message      text,
    tables_total integer NOT NULL DEFAULT 0,
    tables_done  integer NOT NULL DEFAULT 0,
    tables_error integer NOT NULL DEFAULT 0
);

CREATE TABLE run_table (
    run_id   text   NOT NULL REFERENCES run (run_id) ON DELETE CASCADE,
    table_id bigint NOT NULL REFERENCES monitored_table (id) ON DELETE CASCADE,
    state    text   NOT NULL,
    attempts integer NOT NULL DEFAULT 0,
    error    text,
    PRIMARY KEY (run_id, table_id)
);

-- Um resumo por execução e por tabela (histórico).
CREATE TABLE table_result_history (
    run_id         text   NOT NULL REFERENCES run (run_id) ON DELETE CASCADE,
    table_id       bigint NOT NULL REFERENCES monitored_table (id) ON DELETE CASCADE,
    period_from    date   NOT NULL,
    period_to      date   NOT NULL,
    status         text   NOT NULL CHECK (status IN ('Igual', 'Diferente', 'Erro')),
    date_field     text,
    day_mode       text,
    mode_source    text,
    days           integer,
    days_different integer,
    source_total   bigint,
    trino_total    bigint,
    diff           bigint,                      -- Trino menos origem
    error          text,
    last_id        bigint,                      -- comparação por ID: o maior id do Trino usado como limite
    computed_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (run_id, table_id)
);
CREATE INDEX table_result_history_table_idx ON table_result_history (table_id, computed_at DESC);

-- O resultado atual de cada tabela, que é o que a tela mostra, e o detalhe por dia dele.
CREATE TABLE table_result (
    table_id       bigint PRIMARY KEY REFERENCES monitored_table (id) ON DELETE CASCADE,
    run_id         text   NOT NULL REFERENCES run (run_id),
    period_from    date   NOT NULL,
    period_to      date   NOT NULL,
    status         text   NOT NULL CHECK (status IN ('Igual', 'Diferente', 'Erro')),
    date_field     text,
    day_mode       text,
    mode_source    text,
    days           integer,
    days_different integer,
    source_total   bigint,
    trino_total    bigint,
    diff           bigint,
    error          text,
    last_id        bigint,                      -- comparação por ID: o maior id do Trino usado como limite
    computed_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX table_result_status_idx ON table_result (status);

CREATE TABLE table_result_day (
    table_id     bigint  NOT NULL REFERENCES table_result (table_id) ON DELETE CASCADE,
    day          date    NOT NULL,
    source_count bigint  NOT NULL,
    trino_count  bigint  NOT NULL,
    diff         bigint  NOT NULL,
    status       text    NOT NULL CHECK (status IN ('Igual', 'Diferente')),
    PRIMARY KEY (table_id, day)
);

-- Quem mudou o quê, e quando (edições pela tela).
CREATE TABLE audit_log (
    id        bigserial PRIMARY KEY,
    at        timestamptz NOT NULL DEFAULT now(),
    actor     text,
    action    text NOT NULL,
    table_id  bigint REFERENCES monitored_table (id) ON DELETE SET NULL,
    field     text,
    old_value text,
    new_value text
);
CREATE INDEX audit_log_table_idx ON audit_log (table_id, at DESC);

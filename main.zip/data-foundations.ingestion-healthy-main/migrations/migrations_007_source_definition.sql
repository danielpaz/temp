-- DDL and indexes of the transactional (origin) table, read from the origin catalog on every update of the table.
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS source_ddl text;
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS source_indexes jsonb;
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS source_col_count integer;
ALTER TABLE monitored_table ADD COLUMN IF NOT EXISTS source_ddl_checked_at timestamptz;

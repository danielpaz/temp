-- A row is identified by origin + Trino table: a view and the table it reads have the same origin.
DROP INDEX IF EXISTS monitored_table_source_uq;
CREATE UNIQUE INDEX IF NOT EXISTS monitored_table_row_uq ON monitored_table
    (lower(source_database), lower(source_schema), lower(source_table), lower(target_catalog), lower(target_schema), lower(target_table));

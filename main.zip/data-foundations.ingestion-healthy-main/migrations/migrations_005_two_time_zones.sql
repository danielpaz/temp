-- A table's day is counted in America/Sao_Paulo (sp) or UTC (utc); sp is the default for every table.
ALTER TABLE monitored_table DROP CONSTRAINT IF EXISTS monitored_table_trino_day_mode_check;
UPDATE monitored_table SET trino_day_mode = 'sp', mode_source = 'manual';
ALTER TABLE monitored_table ALTER COLUMN trino_day_mode SET DEFAULT 'sp';
ALTER TABLE monitored_table ADD CONSTRAINT monitored_table_trino_day_mode_check CHECK (trino_day_mode IN ('sp', 'utc'));

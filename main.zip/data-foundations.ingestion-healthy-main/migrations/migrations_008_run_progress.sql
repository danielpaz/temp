-- Progress of a run, shared between the web pod (supervisor) and the worker pods.
-- Rows are removed 7 days after the run started (see PostgresProgressStore.save_plan).
CREATE TABLE IF NOT EXISTS run_plan (
    run_id     text PRIMARY KEY,
    body       jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS run_worker_progress (
    run_id     text NOT NULL REFERENCES run_plan (run_id) ON DELETE CASCADE,
    worker_id  text NOT NULL,
    body       jsonb NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (run_id, worker_id)
);

CREATE TABLE IF NOT EXISTS run_cancel_request (
    run_id    text NOT NULL REFERENCES run_plan (run_id) ON DELETE CASCADE,
    table_key text NOT NULL,
    PRIMARY KEY (run_id, table_key)
);

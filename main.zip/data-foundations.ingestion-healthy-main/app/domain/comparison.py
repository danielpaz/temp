"""The outcome of comparing one table: what each side counted and what was learned."""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Dict, List, Mapping, Optional

from app.domain.entities import MonitoredTable
from app.domain.values import (
    Basis,
    Criterion,
    DayMode,
    ObjectType,
    Period,
    ResultStatus,
    TableKey,
)


@dataclass(frozen=True)
class DayCount:
    day: dt.date
    origin: int
    lake: int

    @property
    def diff(self) -> int:
        return self.lake - self.origin

    @property
    def status(self) -> ResultStatus:
        return ResultStatus.EQUAL if self.diff == 0 else ResultStatus.DIFFERENT


@dataclass(frozen=True)
class LakeObject:
    """Whether the analytical object is a table or a view (and the DDL of a view)."""

    type: ObjectType
    ddl: Optional[str] = None


@dataclass(frozen=True)
class OriginDefinition:
    """The DDL and the indexes of the transactional table, rebuilt from its catalog."""

    ddl: str
    indexes: List[dict]
    column_count: int


@dataclass
class TableFacts:
    """What was learned about the two tables while comparing them."""

    lake_object: Optional[LakeObject] = None
    lake_column_type: Optional[str] = None
    origin_size_bytes: Optional[int] = None
    origin_definition: Optional[OriginDefinition] = None
    origin_read: bool = False


@dataclass
class ComparisonResult:
    key: TableKey
    status: ResultStatus
    period: Period
    basis: Optional[Basis] = None
    filter_column: Optional[str] = None
    days: List[DayCount] = field(default_factory=list)
    origin_total: Optional[int] = None
    lake_total: Optional[int] = None
    last_id: Optional[int] = None
    error: Optional[str] = None
    facts: TableFacts = field(default_factory=TableFacts)

    @property
    def diff(self) -> Optional[int]:
        if self.origin_total is None or self.lake_total is None:
            return None
        return self.lake_total - self.origin_total

    @property
    def days_different(self) -> int:
        return sum(1 for d in self.days if d.diff != 0)

    @classmethod
    def daily(
        cls,
        table: MonitoredTable,
        period: Period,
        origin: Mapping[dt.date, int],
        lake: Mapping[dt.date, int],
        facts: TableFacts,
    ) -> "ComparisonResult":
        days = [DayCount(d, origin.get(d, 0), lake.get(d, 0)) for d in period.days]
        differs = any(d.diff != 0 for d in days)
        return cls(
            key=table.key,
            status=ResultStatus.DIFFERENT if differs else ResultStatus.EQUAL,
            period=period,
            basis=_day_basis(table.day_mode),
            filter_column=table.filter_column,
            days=days,
            origin_total=sum(d.origin for d in days),
            lake_total=sum(d.lake for d in days),
            facts=facts,
        )

    @classmethod
    def whole_table(
        cls,
        table: MonitoredTable,
        period: Period,
        origin_total: int,
        lake_total: int,
        facts: TableFacts,
    ) -> "ComparisonResult":
        return cls(
            key=table.key,
            status=_status_of(origin_total, lake_total),
            period=period,
            basis=Basis.TOTAL,
            origin_total=origin_total,
            lake_total=lake_total,
            facts=facts,
        )

    @classmethod
    def up_to_id(
        cls,
        table: MonitoredTable,
        period: Period,
        origin_total: int,
        lake_total: int,
        last_id: Optional[int],
        facts: TableFacts,
    ) -> "ComparisonResult":
        return cls(
            key=table.key,
            status=_status_of(origin_total, lake_total),
            period=period,
            basis=Basis.ID,
            filter_column=table.filter_column,
            origin_total=origin_total,
            lake_total=lake_total,
            last_id=last_id,
            facts=facts,
        )

    @classmethod
    def failed(
        cls, table: MonitoredTable, period: Period, message: str, facts: TableFacts
    ) -> "ComparisonResult":
        return cls(
            key=table.key,
            status=ResultStatus.ERROR,
            period=period,
            basis=_basis_of(table),
            filter_column=table.filter_column,
            error=message,
            facts=facts,
        )


def _status_of(origin_total: int, lake_total: int) -> ResultStatus:
    return ResultStatus.EQUAL if origin_total == lake_total else ResultStatus.DIFFERENT


def _basis_of(table: MonitoredTable) -> Basis:
    if table.criterion is Criterion.ID:
        return Basis.ID
    if table.criterion is Criterion.TOTAL:
        return Basis.TOTAL
    return _day_basis(table.day_mode)


def _day_basis(mode: DayMode) -> Basis:
    return Basis.UTC if mode is DayMode.UTC else Basis.SAO_PAULO


ResultsByKey = Dict[str, ComparisonResult]

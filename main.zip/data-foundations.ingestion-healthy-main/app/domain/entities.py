"""Entities of the volume comparison."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from app.domain.values import Criterion, DayMode, FilterKind, TableKey


@dataclass
class MonitoredTable:
    """A transactional table compared with its analytical table in the lake."""

    key: TableKey
    secret: str
    host: str
    filter_column: Optional[str] = None
    filter_kind: FilterKind = FilterKind.DATE
    day_mode: DayMode = DayMode.SAO_PAULO
    enabled: bool = True
    id: Optional[int] = None

    @property
    def criterion(self) -> Criterion:
        """No column: the whole volume. An id column: up to the largest id of
        the lake. A date column: day by day."""
        if not self.filter_column:
            return Criterion.TOTAL
        if self.filter_kind is FilterKind.ID:
            return Criterion.ID
        return Criterion.DATE

    @property
    def origin_instance(self) -> tuple:
        """The origin instance this table is read from: one worker per instance."""
        return (self.secret, self.host)

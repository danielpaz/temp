"""State machine of a run: its workers (one pod per origin instance) and tables."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Mapping, Optional, Tuple

from app.domain.policies import RetryPolicy
from app.domain.progress import Chunks, TableProgress, TableState, WorkerProgress
from app.domain.values import Period

STOPPED_MESSAGE = "A atualização foi interrompida: o orquestrador parou de responder."


class WorkerStatus(str, Enum):
    PENDING = "pending"
    STARTING = "starting"
    RUNNING = "running"
    RETRYING = "retrying"
    DONE = "done"
    FAILED = "failed"

    @property
    def active(self) -> bool:
        return self in (
            WorkerStatus.STARTING,
            WorkerStatus.RUNNING,
            WorkerStatus.RETRYING,
        )

    @property
    def over(self) -> bool:
        return self in (WorkerStatus.DONE, WorkerStatus.FAILED)


class RunStatus(str, Enum):
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    COMPLETED_WITH_ERRORS = "completed_with_errors"
    FAILED = "failed"
    CANCELLED = "cancelled"
    INTERRUPTED = "interrupted"


@dataclass(frozen=True)
class RunRules:
    """Tunables of the supervision of a run."""

    max_attempts: int = 3
    retry: RetryPolicy = RetryPolicy(3, (10, 30))
    heartbeat_ttl: float = 90
    run_timeout: float = 14400
    pending_timeout: float = 600
    launch_grace: float = 15
    max_parallel: int = 30
    max_runs: int = 5
    max_days: int = 90
    publish_every: float = 30
    keep_finished: int = 10
    poll: float = 4.0


@dataclass(frozen=True)
class PodInfo:
    name: str
    phase: str
    reason: str
    created: float


class Action(str, Enum):
    WAIT = "wait"
    LAUNCH = "launch"
    RUNNING = "running"
    FINISH = "finish"
    FAIL = "fail"


@dataclass(frozen=True)
class Decision:
    action: Action
    reason: str = ""


class CancelAction(str, Enum):
    NONE = "none"
    FINISH = "finish"
    REPLACE = "replace"


@dataclass
class Worker:
    """A pod, and its retries, that compares the tables of one origin instance."""

    worker_id: str
    host: str
    secret: str
    keys: List[str]
    attempt: int = 0
    status: WorkerStatus = WorkerStatus.PENDING
    pod: Optional[str] = None
    error: str = ""
    retry_at: float = 0.0
    launched: float = 0.0
    succeeded_seen: int = 0
    cancels: int = 0
    handled: List[str] = field(default_factory=list)

    def react(
        self,
        pod: Optional[PodInfo],
        progress: Optional[WorkerProgress],
        now: float,
        rules: RunRules,
        can_start: bool,
    ) -> Decision:
        if self.status in (WorkerStatus.PENDING, WorkerStatus.RETRYING):
            return self._idle(now, can_start)
        if self.status not in (WorkerStatus.STARTING, WorkerStatus.RUNNING):
            return Decision(Action.WAIT)
        return self._active(pod, progress, now, rules)

    def _idle(self, now: float, can_start: bool) -> Decision:
        due = self.status is WorkerStatus.PENDING or now >= self.retry_at
        return Decision(Action.LAUNCH if due and can_start else Action.WAIT)

    def _active(self, pod, progress, now, rules) -> Decision:
        if progress is not None and progress.finished_by(self.attempt):
            return Decision(Action.FINISH)
        if pod is None:
            gone = now - self.launched > rules.launch_grace
            return (
                Decision(Action.FAIL, "o pod desapareceu")
                if gone
                else Decision(Action.WAIT)
            )
        return self._by_phase(pod, now, rules)

    def _by_phase(self, pod: PodInfo, now: float, rules: RunRules) -> Decision:
        if pod.phase == "Failed":
            return Decision(Action.FAIL, pod.reason or "pod falhou")
        if pod.phase == "Succeeded":
            return self._succeeded_without_result()
        if pod.phase == "Pending":
            return self._stuck_pending(pod, now, rules)
        return Decision(Action.RUNNING)

    def _succeeded_without_result(self) -> Decision:
        self.succeeded_seen += 1
        if self.succeeded_seen >= 2:
            return Decision(Action.FAIL, "o pod terminou sem concluir")
        return Decision(Action.WAIT)

    def _stuck_pending(self, pod: PodInfo, now: float, rules: RunRules) -> Decision:
        if now - pod.created > rules.pending_timeout:
            reason = pod.reason or "sem motivo"
            return Decision(Action.FAIL, f"pod preso em Pending ({reason})")
        return Decision(Action.WAIT)

    def start_attempt(self, pod_name: str, now: float) -> None:
        self.attempt += 1
        self.launched = now
        self.succeeded_seen = 0
        self.pod = pod_name

    def register_failure(self, reason: str, now: float, rules: RunRules) -> None:
        """Replacing a pod because a table was stopped is not a failure."""
        self.error = reason
        if self.attempt - self.cancels < rules.max_attempts:
            self.retry_at = now + rules.retry.delay_after(self.attempt)
            self.status = WorkerStatus.RETRYING
        else:
            self.status = WorkerStatus.FAILED

    def cancel_action(
        self, progress: Optional[WorkerProgress], asked: set
    ) -> Tuple[CancelAction, List[str]]:
        """What to do with this worker when the user stopped some tables, and
        which of them that action covers."""
        if self.status.over:
            return CancelAction.NONE, []
        tables = progress.tables if progress else {}
        left = [k for k in self.keys if not _state_of(tables, k).finished]
        new = [k for k in left if k in asked and k not in self.handled]
        if not new:
            return CancelAction.NONE, []
        if all(k in asked for k in left):
            return CancelAction.FINISH, new
        running = [k for k in new if _state_of(tables, k).working]
        replace = running and self.status in (
            WorkerStatus.STARTING,
            WorkerStatus.RUNNING,
        )
        return (CancelAction.REPLACE, running) if replace else (CancelAction.NONE, [])

    def snapshot(self) -> dict:
        return {
            "host": self.host,
            "secret": self.secret,
            "pod": self.pod,
            "attempt": self.attempt,
            "state": self.status.value,
            "error": self.error,
        }


def _state_of(tables: Mapping[str, TableProgress], key: str) -> TableState:
    progress = tables.get(key)
    return progress.state if progress else TableState.PENDING


@dataclass
class TableRun:
    state: TableState = TableState.PENDING
    attempts: int = 0
    error: str = ""
    chunks: Optional[Chunks] = None
    published: bool = False

    def snapshot(self) -> dict:
        out: dict = {
            "state": self.state.value,
            "attempts": self.attempts,
            "error": self.error,
        }
        if self.chunks:
            out["chunks"] = {"done": self.chunks.done, "total": self.chunks.total}
        if self.published:
            out["published"] = True
        return out


@dataclass
class RunCounts:
    total: int = 0
    done: int = 0
    error: int = 0
    cancelled: int = 0

    @property
    def settled(self) -> int:
        return self.done + self.error + self.cancelled

    def snapshot(self) -> dict:
        return {
            "total": self.total,
            "done": self.done,
            "error": self.error,
            "cancelled": self.cancelled,
        }


def count_tables(tables: Mapping[str, TableRun]) -> RunCounts:
    states = [t.state for t in tables.values()]
    return RunCounts(
        total=len(states),
        done=states.count(TableState.DONE),
        error=states.count(TableState.ERROR),
        cancelled=states.count(TableState.CANCELLED),
    )


def fold_tables(
    workers: Mapping[str, Worker],
    progress: Mapping[str, Optional[WorkerProgress]],
    cancelled: set,
) -> Dict[str, TableRun]:
    """What every table of the run is doing, from what the workers reported."""
    tables: Dict[str, TableRun] = {}
    for worker_id, worker in workers.items():
        reported = progress.get(worker_id)
        for key in worker.keys:
            tables[key] = _fold_one(worker, reported, key, key in cancelled)
    return tables


def _fold_one(
    worker: Worker, reported: Optional[WorkerProgress], key: str, cancelled: bool
) -> TableRun:
    seen = reported.tables.get(key) if reported else None
    settled = seen is not None and seen.state in (TableState.DONE, TableState.ERROR)
    attempts = seen.attempts if seen else 0
    if cancelled and not settled:
        return TableRun(TableState.CANCELLED, attempts)
    if worker.status is WorkerStatus.FAILED and not settled:
        why = f"worker falhou após {worker.attempt} tentativas: {worker.error}"
        return TableRun(TableState.ERROR, attempts, why)
    run = _from_progress(seen)
    if worker.status is WorkerStatus.RETRYING and run.state.working:
        run.state = TableState.PENDING
    return run


def _from_progress(seen: Optional[TableProgress]) -> TableRun:
    if seen is None:
        return TableRun()
    chunks = seen.chunks if seen.state.working else None
    return TableRun(seen.state, seen.attempts, seen.error, chunks)


@dataclass
class RunState:
    run_id: str
    period: Period
    started_at: float
    heartbeat: float
    merge: bool = False
    status: RunStatus = RunStatus.RUNNING
    finished_at: Optional[float] = None
    message: str = ""
    workers: Dict[str, dict] = field(default_factory=dict)
    tables: Dict[str, TableRun] = field(default_factory=dict)
    counts: RunCounts = field(default_factory=RunCounts)
    published: Optional[int] = None

    def is_active(self, now: float, ttl: float) -> bool:
        return self.status is RunStatus.RUNNING and now - self.heartbeat <= ttl

    def busy_keys(self) -> List[str]:
        return [
            k for k, t in self.tables.items() if t.state is not TableState.CANCELLED
        ]

    def open_keys(self) -> List[str]:
        return [k for k, t in self.tables.items() if not t.state.finished]

    def update_tables(self, tables: Dict[str, TableRun], workers: Mapping) -> None:
        self.tables = tables
        self.counts = count_tables(tables)
        self.workers = {wid: w.snapshot() for wid, w in workers.items()}

    def snapshot(self) -> dict:
        out = {
            "run_id": self.run_id,
            "status": self.status.value,
            "period": self.period.iso(),
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "heartbeat": self.heartbeat,
            "message": self.message,
            "merge": self.merge,
            "workers": self.workers,
            "tables": {k: t.snapshot() for k, t in self.tables.items()},
            "counts": self.counts.snapshot(),
        }
        if self.published is not None:
            out["published"] = self.published
        return out

    @classmethod
    def from_snapshot(cls, data: Mapping) -> "RunState":
        start, end = data["period"]
        state = cls(
            run_id=data["run_id"],
            period=Period(_date(start), _date(end)),
            started_at=data.get("started_at", 0.0),
            heartbeat=data.get("heartbeat", 0.0),
            merge=bool(data.get("merge")),
            status=RunStatus(data.get("status", "running")),
            finished_at=data.get("finished_at"),
            message=data.get("message", ""),
            workers=dict(data.get("workers") or {}),
            published=data.get("published"),
        )
        state.tables = {k: _table_run(v) for k, v in (data.get("tables") or {}).items()}
        state.counts = RunCounts(
            **{**RunCounts().snapshot(), **(data.get("counts") or {})}
        )
        return state


def _date(text: str):
    import datetime as dt

    return dt.date.fromisoformat(text)


def _table_run(data: Mapping) -> TableRun:
    chunks = data.get("chunks")
    return TableRun(
        TableState(data.get("state", "pending")),
        data.get("attempts", 0),
        data.get("error", ""),
        Chunks(chunks["done"], chunks["total"]) if chunks else None,
        bool(data.get("published")),
    )

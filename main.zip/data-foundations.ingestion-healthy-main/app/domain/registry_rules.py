"""Rules of the table registry: what a name may look like, what an edit may
change and which stored facts an edit makes stale."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Set

from app.domain.exceptions import InvalidRequest
from app.domain.values import DayMode, FilterKind, TableKey

IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,127}")
SOURCE_NAME = re.compile(r"[A-Za-z0-9_$]{1,128}")
TARGET_NAME = re.compile(r"[A-Za-z0-9_$-]{1,128}")
SECRET_NAME = re.compile(r"[A-Za-z0-9/_+=.@-]{1,512}")
TAG = re.compile(r"[A-Za-z0-9_.:-]{1,40}")
MAX_TAGS = 20

SOURCE_FIELDS = ("source_database", "source_schema", "source_table")
TARGET_FIELDS = ("target_catalog", "target_schema", "target_table")
COLUMN_FIELD = "date_field"
SECRET_FIELD = "used_secret"
NAME_RULES = {
    **{name: SOURCE_NAME for name in SOURCE_FIELDS},
    **{name: TARGET_NAME for name in TARGET_FIELDS},
    SECRET_FIELD: SECRET_NAME,
    COLUMN_FIELD: IDENT,
}
LABELS = {
    "source_database": "banco da origem",
    "source_schema": "schema da origem",
    "source_table": "tabela da origem",
    "target_catalog": "catálogo do Trino",
    "target_schema": "schema do Trino",
    "target_table": "tabela do Trino",
    SECRET_FIELD: "secret",
    COLUMN_FIELD: "coluna de filtro/agrupamento",
}
KEY_FIELDS = SOURCE_FIELDS + TARGET_FIELDS
EDITABLE = set(NAME_RULES) | {"trino_day_mode", "filter_kind", "tags", "enabled"}
STALE_FIELDS = set(NAME_RULES) | {"trino_day_mode", "filter_kind"}


def clean_name(name: str, value: object, required: bool) -> Optional[str]:
    text = str(value or "").strip()
    if not text:
        if name == COLUMN_FIELD and not required:
            return None
        raise InvalidRequest(f"Informe {LABELS[name]}.")
    if not NAME_RULES[name].fullmatch(text):
        extra = " (e / . + = @ -)" if name == SECRET_FIELD else ""
        raise InvalidRequest(
            f"Valor inválido para {LABELS[name]}: use só letras, números e _"
            f"{extra}, sem espaços."
        )
    return text


def clean_names(
    fields: Mapping, required: Iterable[str] = ()
) -> Dict[str, Optional[str]]:
    required = set(required)
    return {
        name: clean_name(name, fields.get(name), name in required)
        for name in NAME_RULES
        if name in fields or name in required
    }


def clean_tags(tags: object) -> List[str]:
    if not isinstance(tags, list) or len(tags) > MAX_TAGS:
        tags = None
    valid = tags is not None and all(
        isinstance(t, str) and TAG.fullmatch(t.strip()) for t in tags
    )
    if tags is None or not valid:
        raise InvalidRequest(
            "Tags: até 20, cada uma com 1 a 40 caracteres entre letras, "
            "números e _ . : -"
        )
    return sorted({t.strip() for t in tags})


def parse_day_mode(value: object) -> DayMode:
    text = str(value or "").strip().lower() or DayMode.SAO_PAULO.value
    try:
        return DayMode(text)
    except ValueError:
        raise InvalidRequest("Fuso inválido. Use America/Sao_Paulo (sp) ou UTC (utc).")


def parse_filter_kind(value: object) -> FilterKind:
    try:
        return FilterKind(str(value or "").strip().lower())
    except ValueError:
        raise InvalidRequest("Tipo do campo inválido. Use DATE/TIMESTAMP ou ID.")


@dataclass
class NewTable:
    key: TableKey
    secret: str
    filter_column: Optional[str]
    filter_kind: FilterKind
    tags: List[str] = field(default_factory=list)


def parse_new_table(raw: Mapping) -> NewTable:
    unknown = set(raw) - (set(NAME_RULES) | {"tags", "filter_kind"})
    if unknown:
        raise InvalidRequest("Campos desconhecidos: " + ", ".join(sorted(unknown)))
    required = set(KEY_FIELDS) | {SECRET_FIELD}
    names = clean_names(raw, required)
    kind = FilterKind.DATE
    if raw.get("filter_kind"):
        kind = parse_filter_kind(raw["filter_kind"])
    return NewTable(
        key=TableKey(*(names[f] or "" for f in KEY_FIELDS)),
        secret=names[SECRET_FIELD] or "",
        filter_column=names.get(COLUMN_FIELD),
        filter_kind=kind,
        tags=clean_tags(raw.get("tags", [])),
    )


@dataclass
class TableChanges:
    """What a person asked to change on a registered table, already validated."""

    names: Dict[str, Optional[str]] = field(default_factory=dict)
    day_mode: Optional[DayMode] = None
    filter_kind: Optional[FilterKind] = None
    enabled: Optional[bool] = None
    tags: Optional[List[str]] = None


def parse_changes(raw: Mapping) -> TableChanges:
    unknown = set(raw) - EDITABLE
    if unknown:
        raise InvalidRequest("Campos não editáveis: " + ", ".join(sorted(unknown)))
    changes = TableChanges(names=clean_names(raw))
    if "trino_day_mode" in raw:
        changes.day_mode = parse_day_mode(raw["trino_day_mode"])
    if "filter_kind" in raw:
        changes.filter_kind = parse_filter_kind(raw["filter_kind"])
    if "enabled" in raw:
        changes.enabled = _parse_flag(raw["enabled"])
    if "tags" in raw:
        changes.tags = clean_tags(raw["tags"])
    return changes


def _parse_flag(value: object) -> bool:
    if not isinstance(value, bool):
        raise InvalidRequest("'enabled' deve ser verdadeiro ou falso.")
    return value


@dataclass(frozen=True)
class Invalidation:
    """Stored facts that stop being true after an edit."""

    origin_facts: bool
    lake_object: bool
    lake_column_type: bool
    result_stale: bool


def invalidated_by(changed: Set[str]) -> Invalidation:
    """`changed` holds the registry field names that really changed."""
    origin = set(SOURCE_FIELDS) | {SECRET_FIELD}
    target = set(TARGET_FIELDS)
    return Invalidation(
        origin_facts=bool(changed & origin),
        lake_object=bool(changed & target),
        lake_column_type=bool(changed & (target | {COLUMN_FIELD, "filter_kind"})),
        result_stale=bool(changed & STALE_FIELDS),
    )


def normalize_actor(actor: object) -> str:
    """Who made a change, as it is recorded in the audit log."""
    return (str(actor or "").strip() or "anônimo")[:80]

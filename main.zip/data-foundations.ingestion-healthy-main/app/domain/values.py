"""Value objects of the volume comparison."""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from enum import Enum
from typing import List

from app.domain.exceptions import InvalidPeriod, InvalidRequest


class DayMode(str, Enum):
    """The time zone in which the day of a record is counted in the lake."""

    SAO_PAULO = "sp"
    UTC = "utc"


class FilterKind(str, Enum):
    """What the filter/group column holds."""

    DATE = "date"
    ID = "id"


class Criterion(str, Enum):
    """How a table is compared."""

    DATE = "date"
    ID = "id"
    TOTAL = "total"


class Basis(str, Enum):
    """What a stored result was counted by."""

    SAO_PAULO = "sp"
    UTC = "utc"
    ID = "id"
    TOTAL = "total"


class ObjectType(str, Enum):
    TABLE = "TABLE"
    VIEW = "VIEW"


class ResultStatus(str, Enum):
    EQUAL = "Igual"
    DIFFERENT = "Diferente"
    ERROR = "Erro"


KEY_FORMAT = "'banco.schema.tabela@catalogo.schema.tabela'"


@dataclass(frozen=True)
class TableKey:
    """A row is identified by its origin and its Trino table: a view and the
    table it reads share the same origin."""

    source_database: str
    source_schema: str
    source_table: str
    target_catalog: str
    target_schema: str
    target_table: str

    @classmethod
    def parse(cls, text: str) -> "TableKey":
        source, _, target = str(text).partition("@")
        parts = source.split(".", 2) + target.split(".", 2)
        if len(parts) != 6 or not all(parts):
            raise InvalidRequest(f"A tabela deve ser informada como {KEY_FORMAT}.")
        return cls(*parts)

    @property
    def source_name(self) -> str:
        return f"{self.source_database}.{self.source_schema}.{self.source_table}"

    @property
    def target_name(self) -> str:
        return f"{self.target_catalog}.{self.target_schema}.{self.target_table}"

    def __str__(self) -> str:
        return f"{self.source_name}@{self.target_name}"


@dataclass(frozen=True)
class Period:
    """Days compared, both ends included."""

    start: dt.date
    end: dt.date

    @classmethod
    def parse(
        cls, date_from, date_to, max_days: int, today: dt.date | None = None
    ) -> "Period":
        try:
            start = dt.date.fromisoformat(str(date_from))
            end = dt.date.fromisoformat(str(date_to))
        except ValueError:
            raise InvalidPeriod("Datas inválidas. Use o formato AAAA-MM-DD.")
        period = cls(start, end)
        period.ensure_valid(max_days, today or dt.date.today())
        return period

    def ensure_valid(self, max_days: int, today: dt.date) -> None:
        if self.start > self.end:
            raise InvalidPeriod(
                "A data inicial deve ser anterior ou igual à data final."
            )
        if self.end > today:
            raise InvalidPeriod("A data final não pode estar no futuro.")
        if self.size > max_days:
            raise InvalidPeriod(f"O período máximo é de {max_days} dias.")

    @property
    def size(self) -> int:
        return (self.end - self.start).days + 1

    @property
    def end_exclusive(self) -> dt.date:
        return self.end + dt.timedelta(days=1)

    @property
    def days(self) -> List[dt.date]:
        return [self.start + dt.timedelta(days=i) for i in range(self.size)]

    def iso(self) -> List[str]:
        return [self.start.isoformat(), self.end.isoformat()]

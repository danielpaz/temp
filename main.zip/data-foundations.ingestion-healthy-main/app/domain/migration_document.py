"""The document format of a validation run: what the import command sends, what
is stored and what the page reads. Parsing it is where bad input is refused."""

from __future__ import annotations

import datetime as dt
from typing import Any, Callable, Mapping, Optional, Tuple, TypeVar

from app.domain.exceptions import InvalidRequest
from app.domain.migration import (
    Check,
    ColumnReport,
    DatabaseFinding,
    EngineInfo,
    Finding,
    Severity,
    SideMeasure,
    TableReport,
    ValidationRun,
)

T = TypeVar("T")
MAX_TABLES = 5000
MAX_ITEMS = 20000
MAX_TEXT = 4000
RESOURCE_KEYS = ("teleport_sql", "teleport_sql_uri", "teleport_aurora", "sct_answer")


def _text(value: Any, label: str, required: bool = True) -> str:
    if value is None or value == "":
        if required:
            raise InvalidRequest(f"Campo obrigatório ausente: {label}.")
        return ""
    if not isinstance(value, (str, int, float)):
        raise InvalidRequest(f"Campo inválido: {label}.")
    return str(value)[:MAX_TEXT]


def _opt(value: Any) -> Optional[str]:
    return None if value is None else str(value)[:MAX_TEXT]


def _int(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise InvalidRequest("Número inválido no documento.")
    return int(value)


def _items(value: Any, label: str, build: Callable[[Mapping], T]) -> Tuple[T, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or len(value) > MAX_ITEMS:
        raise InvalidRequest(f"Lista inválida: {label}.")
    if not all(isinstance(item, dict) for item in value):
        raise InvalidRequest(f"Lista inválida: {label}.")
    return tuple(build(item) for item in value)


def _severity(value: Any) -> Severity:
    try:
        return Severity(str(value))
    except ValueError:
        raise InvalidRequest(f"Severidade desconhecida: {str(value)[:20]!r}.")


def _check(d: Mapping) -> Check:
    return Check(
        _text(d.get("id"), "check.id"),
        _text(d.get("title"), "check.title"),
        _severity(d.get("sev")),
        _text(d.get("detail"), "check.detail", False),
    )


def _finding(d: Mapping) -> Finding:
    return Finding(
        _text(d.get("check"), "finding.check"),
        _severity(d.get("sev")),
        _text(d.get("detail"), "finding.detail", False),
        _opt(d.get("column")),
        _opt(d.get("src")),
        _opt(d.get("tgt")),
        bool(d.get("expected", False)),
    )


def _column(d: Mapping) -> ColumnReport:
    return ColumnReport(
        _text(d.get("name"), "column.name"),
        _text(d.get("src"), "column.src", False),
        _text(d.get("tgt_name"), "column.tgt_name", False),
        _text(d.get("tgt"), "column.tgt", False),
        _text(d.get("exp"), "column.exp", False),
        _text(d.get("nsrc"), "column.nsrc", False),
        _text(d.get("ntgt"), "column.ntgt", False),
        _text(d.get("status"), "column.status", False) or "info",
        _text(d.get("detail"), "column.detail", False),
    )


def _measure(d: Optional[Mapping]) -> Optional[SideMeasure]:
    if d is None:
        return None
    if not isinstance(d, dict):
        raise InvalidRequest("Medida inválida no documento.")
    return SideMeasure(
        _int(d.get("approx")),
        _int(d.get("size")),
        _opt(d.get("wm_col")),
        _opt(d.get("wm_min")),
        _opt(d.get("wm_max")),
        _int(d.get("exact")),
        _opt(d.get("cutoff")),
    )


def _table(d: Mapping) -> TableReport:
    return TableReport(
        _text(d.get("name"), "table.name"),
        _opt(d.get("tgt_name")),
        _items(d.get("checks"), "checks", _check),
        _items(d.get("findings"), "findings", _finding),
        _items(d.get("columns"), "columns", _column),
        _measure(d.get("src")),
        _measure(d.get("tgt")),
        bool(d.get("count_caveat", False)),
        _opt(d.get("note")),
    )


def _database_finding(d: Mapping) -> DatabaseFinding:
    return DatabaseFinding(
        _text(d.get("check"), "db_finding.check"),
        _severity(d.get("sev")),
        _text(d.get("title"), "db_finding.title", False),
        _text(d.get("detail"), "db_finding.detail", False),
    )


def _engine(d: Any, label: str) -> EngineInfo:
    if not isinstance(d, dict):
        raise InvalidRequest(f"Campo obrigatório ausente: {label}.")
    return EngineInfo(
        _text(d.get("engine"), f"{label}.engine"), _text(d.get("tz"), f"{label}.tz")
    )


def _captured(value: Any) -> dt.datetime:
    try:
        moment = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        raise InvalidRequest("captured deve ser uma data ISO 8601.")
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=dt.timezone.utc)
    return moment.astimezone(dt.timezone.utc)


def _resources(value: Any) -> dict:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise InvalidRequest("res inválido.")
    return {k: _text(value[k], k, False) for k in RESOURCE_KEYS if k in value}


def from_document(doc: Mapping) -> ValidationRun:
    """Raises InvalidRequest for anything that is not a well-formed document."""
    tables = doc.get("tables")
    if not isinstance(tables, list) or not tables or len(tables) > MAX_TABLES:
        raise InvalidRequest("O documento precisa de uma lista 'tables'.")
    return ValidationRun(
        database=_text(doc.get("database"), "database"),
        source_db=_text(doc.get("src_db"), "src_db"),
        target_db=_text(doc.get("tgt_db"), "tgt_db"),
        target_schema=_opt(doc.get("tgt_schema")),
        captured_at=_captured(doc.get("captured")),
        source=_engine(doc.get("src_meta"), "src_meta"),
        target=_engine(doc.get("tgt_meta"), "tgt_meta"),
        tables=_items(tables, "tables", _table),
        database_findings=_items(
            doc.get("db_findings"), "db_findings", _database_finding
        ),
        resources=_resources(doc.get("res")),
    )


def _measure_doc(m: Optional[SideMeasure]) -> Optional[dict]:
    if m is None:
        return None
    return {
        "approx": m.approx_rows,
        "size": m.size_bytes,
        "wm_col": m.watermark_column,
        "wm_min": m.watermark_min,
        "wm_max": m.watermark_max,
        "exact": m.exact_rows,
        "cutoff": m.cutoff,
    }


def _table_doc(t: TableReport) -> dict:
    return {
        "name": t.name,
        "tgt_name": t.target_name,
        "checks": [
            {"id": c.id, "title": c.title, "sev": c.severity.value, "detail": c.detail}
            for c in t.checks
        ],
        "findings": [
            {
                "check": f.check,
                "sev": f.severity.value,
                "column": f.column,
                "src": f.source,
                "tgt": f.target,
                "detail": f.detail,
                "expected": f.expected,
            }
            for f in t.findings
        ],
        "columns": [
            {
                "name": c.name,
                "src": c.source_type,
                "tgt_name": c.target_name,
                "tgt": c.target_type,
                "exp": c.expected_type,
                "nsrc": c.source_nullable,
                "ntgt": c.target_nullable,
                "status": c.status,
                "detail": c.detail,
            }
            for c in t.columns
        ],
        "src": _measure_doc(t.source),
        "tgt": _measure_doc(t.target),
        "count_caveat": t.count_caveat,
        "note": t.note,
    }


def to_document(run: ValidationRun) -> dict:
    return {
        "database": run.database,
        "src_db": run.source_db,
        "tgt_db": run.target_db,
        "tgt_schema": run.target_schema,
        "captured": run.captured_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "src_meta": {"engine": run.source.engine, "tz": run.source.timezone},
        "tgt_meta": {"engine": run.target.engine, "tz": run.target.timezone},
        "tables": [_table_doc(t) for t in run.tables],
        "db_findings": [
            {
                "check": f.check,
                "sev": f.severity.value,
                "title": f.title,
                "detail": f.detail,
            }
            for f in run.database_findings
        ],
        "res": dict(run.resources),
    }

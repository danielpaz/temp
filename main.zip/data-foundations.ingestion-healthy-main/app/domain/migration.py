"""Migration validation: the result of comparing a SQL Server database with its
Aurora PostgreSQL copy, as produced by the sqlserver-aurora-compare skill."""

from __future__ import annotations

import datetime as dt
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Mapping, Optional, Tuple

from app.domain.exceptions import InvalidRequest

DATABASE_NAME = re.compile(r"[A-Za-z0-9_$.-]{1,128}")


class Severity(str, Enum):
    OK = "ok"
    YELLOW = "yellow"
    RED = "red"
    SKIP = "skip"
    INFO = "info"


class TableStatus(str, Enum):
    ATTENTION = "attention"
    REVIEW = "review"
    OK = "ok"

    @property
    def rank(self) -> int:
        return {"attention": 0, "review": 1, "ok": 2}[self.value]


@dataclass(frozen=True)
class MigrationDatabase:
    """One line of the source/target list: where a database lived and where it went."""

    name: str
    host_sql: str = ""
    host_postgresql: str = ""
    note: str = ""

    def __post_init__(self) -> None:
        if not DATABASE_NAME.fullmatch(self.name):
            raise InvalidRequest(f"Nome de banco inválido: {self.name[:60]!r}.")


@dataclass(frozen=True)
class Check:
    id: str
    title: str
    severity: Severity
    detail: str


@dataclass(frozen=True)
class Finding:
    check: str
    severity: Severity
    detail: str
    column: Optional[str] = None
    source: Optional[str] = None
    target: Optional[str] = None
    expected: bool = False


@dataclass(frozen=True)
class ColumnReport:
    name: str
    source_type: str
    target_name: str
    target_type: str
    expected_type: str
    source_nullable: str
    target_nullable: str
    status: str
    detail: str = ""


@dataclass(frozen=True)
class SideMeasure:
    approx_rows: Optional[int] = None
    size_bytes: Optional[int] = None
    watermark_column: Optional[str] = None
    watermark_min: Optional[str] = None
    watermark_max: Optional[str] = None
    exact_rows: Optional[int] = None
    cutoff: Optional[str] = None


@dataclass(frozen=True)
class TableReport:
    name: str
    target_name: Optional[str]
    checks: Tuple[Check, ...] = ()
    findings: Tuple[Finding, ...] = ()
    columns: Tuple[ColumnReport, ...] = ()
    source: Optional[SideMeasure] = None
    target: Optional[SideMeasure] = None
    count_caveat: bool = False
    note: Optional[str] = None

    def pending(self, severity: Severity) -> int:
        """Findings of this severity that were not expected by the migration design."""
        return sum(
            1 for f in self.findings if f.severity is severity and not f.expected
        )

    @property
    def status(self) -> TableStatus:
        if self.pending(Severity.RED):
            return TableStatus.ATTENTION
        if self.pending(Severity.YELLOW):
            return TableStatus.REVIEW
        return TableStatus.OK


@dataclass(frozen=True)
class DatabaseFinding:
    check: str
    severity: Severity
    title: str
    detail: str


@dataclass(frozen=True)
class EngineInfo:
    engine: str
    timezone: str


@dataclass(frozen=True)
class VerificationSummary:
    title: str
    total: int
    ok: int
    yellow: int
    red: int
    skip: int


@dataclass(frozen=True)
class StatusCounts:
    attention: int = 0
    review: int = 0
    ok: int = 0

    @property
    def total(self) -> int:
        return self.attention + self.review + self.ok

    @property
    def status(self) -> TableStatus:
        if self.attention:
            return TableStatus.ATTENTION
        return TableStatus.REVIEW if self.review else TableStatus.OK


@dataclass(frozen=True)
class ValidationRun:
    database: str
    source_db: str
    target_db: str
    target_schema: Optional[str]
    captured_at: dt.datetime
    source: EngineInfo
    target: EngineInfo
    tables: Tuple[TableReport, ...]
    database_findings: Tuple[DatabaseFinding, ...] = ()
    resources: Mapping[str, str] = field(default_factory=dict)

    @property
    def counts(self) -> StatusCounts:
        by: Dict[TableStatus, int] = {s: 0 for s in TableStatus}
        for table in self.tables:
            by[table.status] += 1
        return StatusCounts(
            by[TableStatus.ATTENTION], by[TableStatus.REVIEW], by[TableStatus.OK]
        )

    @property
    def status(self) -> TableStatus:
        return self.counts.status

    def ordered_tables(self) -> List[TableReport]:
        return sorted(self.tables, key=lambda t: (t.status.rank, t.name))

    def verifications(self) -> List[VerificationSummary]:
        """One summary per kind of check, in the order the checks first appear."""
        titles: List[str] = []
        for table in self.ordered_tables():
            for check in table.checks:
                if check.title not in titles:
                    titles.append(check.title)
        return [self._summary(title) for title in titles]

    def _summary(self, title: str) -> VerificationSummary:
        found = [c for t in self.tables for c in t.checks if c.title == title]

        def n(severity: Severity) -> int:
            return sum(1 for c in found if c.severity is severity)

        return VerificationSummary(
            title,
            len(found),
            n(Severity.OK),
            n(Severity.YELLOW),
            n(Severity.RED),
            n(Severity.SKIP),
        )

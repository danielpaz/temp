"""What a worker reports while it compares the tables of one origin instance."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set

from app.domain.comparison import ComparisonResult
from app.domain.entities import MonitoredTable
from app.domain.values import Period


class TableState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    RETRYING = "retrying"
    DONE = "done"
    ERROR = "error"
    CANCELLED = "cancelled"

    @property
    def finished(self) -> bool:
        return self in (TableState.DONE, TableState.ERROR, TableState.CANCELLED)

    @property
    def working(self) -> bool:
        return self in (TableState.RUNNING, TableState.RETRYING)


@dataclass
class Chunks:
    done: int
    total: int


@dataclass
class TableProgress:
    state: TableState = TableState.PENDING
    attempts: int = 0
    error: str = ""
    chunks: Optional[Chunks] = None


@dataclass
class WorkerProgress:
    """The progress file of one pod attempt, kept in the progress store."""

    worker_id: str
    host: str
    pod_attempt: str
    state: str = "running"
    updated: float = 0.0
    tables: Dict[str, TableProgress] = field(default_factory=dict)
    results: Dict[str, ComparisonResult] = field(default_factory=dict)
    partial: Dict[str, dict] = field(default_factory=dict)

    def finished_by(self, attempt: int) -> bool:
        return self.state == "done" and str(self.pod_attempt) == str(attempt)

    def table(self, key: str) -> TableProgress:
        return self.tables.setdefault(key, TableProgress())

    def unfinished(self, keys: List[str]) -> List[str]:
        return [k for k in keys if not self.table(k).state.finished]

    def reuse(self, previous: "WorkerProgress") -> None:
        """Keeps the tables a previous pod attempt of this worker already finished."""
        for key, progress in previous.tables.items():
            if progress.state is TableState.DONE and key in previous.results:
                self.tables[key] = progress
                self.results[key] = previous.results[key]
        self.partial = {
            k: v for k, v in previous.partial.items() if k not in self.results
        }


@dataclass
class RunPlan:
    """What a run compares: written once, read by every worker pod."""

    run_id: str
    period: Period
    tables: List[MonitoredTable]
    merge: bool = False

    def tables_of(self, secret: str, host: str) -> List[MonitoredTable]:
        return [t for t in self.tables if t.origin_instance == (secret, host)]


CancelRequests = Set[str]

"""Rules about how work is retried and split. No I/O: time is injected."""

from __future__ import annotations

import datetime as dt
import time
from dataclasses import dataclass
from typing import Callable, Generic, List, Optional, Sequence, Tuple, TypeVar

from app.domain.exceptions import PermanentError, describe
from app.domain.values import Period

T = TypeVar("T")
Window = Tuple[dt.date, dt.date]


@dataclass(frozen=True)
class RetryPolicy:
    attempts: int
    backoff: Sequence[float]

    def delay_after(self, attempt: int) -> float:
        return float(self.backoff[min(attempt - 1, len(self.backoff) - 1)])


@dataclass
class Attempted(Generic[T]):
    result: Optional[T]
    error: Optional[str]
    attempts_used: int


def _ignore(*_args) -> None:
    return None


def run_with_retry(
    work: Callable[[int], T],
    policy: RetryPolicy,
    on_attempt: Callable[[int], None] = _ignore,
    on_failure: Callable[[int, Exception], None] = _ignore,
    sleep: Callable[[float], None] = time.sleep,
) -> Attempted[T]:
    """Runs `work(attempt)` until it succeeds or the attempts end.
    A PermanentError is never retried."""
    last: Optional[Exception] = None
    for attempt in range(1, policy.attempts + 1):
        on_attempt(attempt)
        try:
            return Attempted(work(attempt), None, attempt)
        except PermanentError as error:
            return Attempted(None, str(error), attempt)
        except Exception as error:
            last = error
            on_failure(attempt, error)
            if attempt < policy.attempts:
                sleep(policy.delay_after(attempt))
    return Attempted(None, describe(last), policy.attempts)


@dataclass(frozen=True)
class WindowPlanner:
    """Big tables whose date column leads an index are counted in windows of a
    few days; without such an index every window would be a full scan."""

    chunk_days: int
    min_rows: int

    def should_chunk(self, rows: int, leading_index: bool, period_days: int) -> bool:
        return (
            rows >= self.min_rows
            and bool(leading_index)
            and period_days > self.chunk_days
        )

    def windows(self, period: Period, chunked: bool) -> List[Window]:
        if not chunked:
            return [(period.start, period.end_exclusive)]
        out, start = [], period.start
        while start < period.end_exclusive:
            end = min(start + dt.timedelta(days=self.chunk_days), period.end_exclusive)
            out.append((start, end))
            start = end
        return out


def halves(start: dt.date, end: dt.date) -> Tuple[Window, Window]:
    """Splits [start, end) in two, to retry a window that timed out."""
    middle = start + dt.timedelta(days=(end - start).days // 2)
    return (start, middle), (middle, end)

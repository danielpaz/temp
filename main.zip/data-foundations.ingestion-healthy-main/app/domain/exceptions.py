"""Errors the domain and the use cases raise. Adapters translate them to HTTP."""

from __future__ import annotations


class DomainError(Exception):
    """Base of every error that carries a message meant for the user."""


class InvalidRequest(DomainError, ValueError):
    """The request is not valid as it was written."""


class InvalidPeriod(InvalidRequest):
    """The period of a comparison is malformed, in the future or too long."""


class NotFound(DomainError, LookupError):
    """The table (or run) asked for does not exist."""


class Conflict(DomainError):
    """The request clashes with the current state, e.g. a run already active."""


class Duplicate(DomainError):
    """A row with the same origin and the same Trino table already exists."""


class Unavailable(DomainError):
    """A collaborator the request depends on cannot be used right now."""


class PermanentError(DomainError):
    """Retrying cannot help, e.g. the table does not exist in the origin."""


class OriginError(DomainError):
    """A retryable failure while reading the origin database."""


class LakeError(DomainError):
    """A retryable failure while reading the lake (Trino)."""


class WindowTimeout(DomainError):
    """One window of days exceeded its time limit; the caller may split it."""


def describe(error: BaseException | None) -> str:
    """One line with the type and the start of the message, safe to show or store."""
    if error is None:
        return "unknown error"
    return f"{type(error).__name__}: {' '.join(str(error).split())[:300]}"

"""Decisions about runs that need no I/O: who may start, who gets which worker,
what a cancel covers and what the status screen shows."""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Optional, Sequence, Set, Tuple

from app.domain.entities import MonitoredTable
from app.domain.exceptions import Conflict, InvalidRequest, Unavailable
from app.domain.run import (
    STOPPED_MESSAGE,
    RunCounts,
    RunRules,
    RunState,
    RunStatus,
    Worker,
)

SAMPLE = 5


def admit(
    active: Sequence[RunState],
    requested: Optional[Sequence[str]],
    available: List[MonitoredTable],
    rules: RunRules,
) -> List[MonitoredTable]:
    """The tables a new run will compare, or why it may not start.
    `requested` None means every table, which needs the cluster to itself."""
    if requested is None and active:
        raise Conflict(
            "Há atualizações em andamento. "
            "Aguarde terminarem para atualizar todas as tabelas."
        )
    if any(not state.merge for state in active):
        raise Conflict("Há uma atualização completa em andamento.")
    chosen = (
        available if requested is None else _subset(active, requested, available, rules)
    )
    if not chosen:
        raise Unavailable("Nenhuma tabela para validar.")
    return chosen


def _subset(active, requested, available, rules) -> List[MonitoredTable]:
    wanted = {str(key) for key in requested}
    if not wanted:
        raise InvalidRequest("Informe ao menos uma tabela.")
    unknown = sorted(wanted - {str(t.key) for t in available})
    if unknown:
        raise InvalidRequest("Tabelas desconhecidas: " + _sample(unknown))
    busy = sorted(wanted & {k for state in active for k in state.busy_keys()})
    if busy:
        raise Conflict("Já em atualização: " + _sample(busy))
    if len(active) >= rules.max_runs:
        raise Conflict(
            f"Limite de {rules.max_runs} atualizações simultâneas. "
            "Aguarde alguma terminar."
        )
    return [t for t in available if str(t.key) in wanted]


def _sample(items: List[str]) -> str:
    text = ", ".join(items[:SAMPLE])
    return text + ("…" if len(items) > SAMPLE else "")


def assign_workers(tables: Sequence[MonitoredTable]) -> Dict[str, Worker]:
    """One worker per origin instance: every secret gets its own pod."""
    groups: Dict[tuple, List[MonitoredTable]] = defaultdict(list)
    for table in tables:
        groups[table.origin_instance].append(table)
    ordered = sorted(groups.items(), key=lambda item: (-len(item[1]), item[0]))
    return {
        f"w{number}": Worker(f"w{number}", host, secret, [str(t.key) for t in rows])
        for number, ((secret, host), rows) in enumerate(ordered, 1)
    }


def select_cancellations(
    active: Sequence[RunState], wanted: Optional[Set[str]]
) -> Dict[str, Set[str]]:
    """Per run, the open tables a cancel covers: the wanted ones, or all of them."""
    chosen: Dict[str, Set[str]] = {}
    for state in active:
        open_keys = set(state.open_keys())
        mine = open_keys if wanted is None else open_keys & wanted
        if mine:
            chosen[state.run_id] = mine
    return chosen


def build_status(states: Sequence[RunState], now: float, rules: RunRules) -> dict:
    """One view over every run: while any is running its tables and counters
    are summed; otherwise the latest run."""
    views = [_with_stale_marked(s, now, rules) for s in states]
    active = sorted(
        (v for v in views if v["status"] == RunStatus.RUNNING.value),
        key=lambda v: v.get("started_at", 0),
    )
    extra = {"active_runs": len(active), "max_runs": rules.max_runs}
    if active:
        return {**_merge_active(active, now), **extra}
    if views:
        last = max(views, key=lambda v: v.get("started_at", 0))
        return {**last, "full": not last.get("merge"), **extra}
    return {"status": "idle", **extra}


def _with_stale_marked(state: RunState, now: float, rules: RunRules) -> dict:
    view = state.snapshot()
    stale = state.status is RunStatus.RUNNING and not state.is_active(
        now, rules.heartbeat_ttl
    )
    if stale:
        view.update(status=RunStatus.INTERRUPTED.value, message=STOPPED_MESSAGE)
    return view


def _merge_active(active: List[dict], now: float) -> dict:
    tables: dict = {}
    for view in active:
        tables.update(view.get("tables", {}))
    keys = ("total", "done", "error", "cancelled")
    counts = {k: sum(v.get("counts", {}).get(k, 0) for v in active) for k in keys}
    return {
        **active[-1],
        "tables": tables,
        "counts": counts,
        "full": any(not v.get("merge") for v in active),
        "started_at": min(v.get("started_at", now) for v in active),
        "heartbeat": max(v.get("heartbeat", 0) for v in active),
    }


def conclude(counts: RunCounts, total: int) -> Tuple[RunStatus, str]:
    """How a finished run is described: its status and the message shown."""
    stopped = counts.cancelled
    if stopped == total:
        return RunStatus.CANCELLED, "Atualização interrompida."
    errors = counts.error
    if errors == 0:
        status, message = RunStatus.SUCCEEDED, "Atualização concluída."
    elif errors == total - stopped:
        status, message = RunStatus.FAILED, "A atualização falhou em todas as tabelas."
    else:
        status = RunStatus.COMPLETED_WITH_ERRORS
        message = f"Atualização concluída com erro em {errors} tabela(s)."
    if stopped:
        message += f" {stopped} tabela(s) interrompida(s)."
    return status, message

"""The database engines of the transactional origins."""

from __future__ import annotations

from enum import Enum
from typing import Mapping, Optional


class Engine(str, Enum):
    POSTGRESQL = "postgresql"
    SQLSERVER = "sqlserver"

    @property
    def label(self) -> str:
        return "PostgreSQL" if self is Engine.POSTGRESQL else "SQL Server"


# Secrets that are Trino catalog files carry no engine in their name.
KNOWN_ENGINES: Mapping[str, Engine] = {
    "prod/engenhariadedados/trino/catalog/pix": Engine.SQLSERVER,
}


def guess_engine(
    secret_name: str, known: Mapping[str, Engine] = KNOWN_ENGINES
) -> Optional[Engine]:
    """The engine a secret points at, from its name."""
    name = secret_name.lower()
    if name in known:
        return known[name]
    if "/postgres" in name:
        return Engine.POSTGRESQL
    if "/sql-server/" in name or "/sqlserver/" in name:
        return Engine.SQLSERVER
    return None


def engine_label(secret_name: str, known: Mapping[str, Engine] = KNOWN_ENGINES) -> str:
    engine = guess_engine(secret_name, known)
    return engine.label if engine else ""

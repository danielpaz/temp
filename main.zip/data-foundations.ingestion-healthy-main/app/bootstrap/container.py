"""Composition root: the only place that knows every concrete class."""

from __future__ import annotations

from typing import Any

import boto3
from dependency_injector import containers, providers

from app.adapters.outbound.aws.secrets_manager import SecretsManagerProvider
from app.adapters.outbound.kubernetes.kube_api import OfficialKubeApi
from app.adapters.outbound.kubernetes.pod_builder import WorkerPodSpec
from app.adapters.outbound.kubernetes.run_state_store import ConfigMapRunStateStore
from app.adapters.outbound.kubernetes.worker_pods import KubernetesWorkerPods
from app.adapters.outbound.origins.base import OriginSettings
from app.adapters.outbound.origins.factory import RegistryOriginReaderFactory
from app.adapters.outbound.postgres import (
    PostgresConnections,
    PostgresMigrationValidations,
    PostgresProgressStore,
    PostgresRegistryQueries,
    PostgresResultStore,
    PostgresRunHistory,
    PostgresTableRegistry,
)
from app.adapters.outbound.trino.reader import TrinoLakeReaderFactory
from app.adapters.outbound.trino.settings_loader import load_trino_settings
from app.application.concurrency import SingleFlight
from app.application.ports.runtime import SystemClock, ThreadSpawner
from app.application.use_cases.comparers import (
    DailyComparer,
    IdComparer,
    WholeTableComparer,
)
from app.application.use_cases.coordinator import RunCoordinator, RunReaper
from app.application.use_cases.fleet import WorkerFleet
from app.application.use_cases.migration_commands import (
    GetMigrationValidation,
    ImportMigrationDatabases,
    ListMigrationOverview,
    RegisterValidation,
)
from app.application.use_cases.origin_day_counter import OriginDayCounter
from app.application.use_cases.process_table import ProcessTable
from app.application.use_cases.publisher import ResultPublisher
from app.application.use_cases.registry_commands import (
    CreateTable,
    DeleteTable,
    EditTable,
    GetSourceDefinition,
    ListAudit,
    ListResults,
    ListTags,
)
from app.application.use_cases.run_commands import (
    BusyTables,
    CancelRun,
    GetRunStatus,
    StartRun,
)
from app.application.use_cases.supervisor import RunSupervisor
from app.application.use_cases.worker_job import RunWorkerJob
from app.config.settings import Settings
from app.domain.policies import RetryPolicy, WindowPlanner
from app.domain.run import RunRules
from app.domain.values import Criterion


def _client(service: str, settings: Settings) -> Any:
    return boto3.client(service, region_name=settings.aws_region)  # type: ignore


def _rules(settings: Settings) -> RunRules:
    return RunRules(
        max_runs=settings.max_runs,
        max_days=settings.max_days,
        run_timeout=settings.run_timeout,
        publish_every=settings.publish_every,
    )


def _pod_spec(settings: Settings) -> WorkerPodSpec:
    return WorkerPodSpec(
        image=settings.worker_image,
        service_account=settings.service_account,
        run_as_user=settings.worker_run_as_user,
        run_as_group=settings.worker_run_as_group,
        memory_request=settings.worker_memory_request,
        memory_limit=settings.worker_memory_limit,
        forwarded_env=settings.forwarded_env(),
    )


def _comparers(settings: Settings):
    counter = OriginDayCounter(
        WindowPlanner(settings.chunk_days, settings.chunk_min_rows),
        SingleFlight(),
        settings.query_timeout,
        settings.chunk_timeout,
    )
    return {
        Criterion.DATE: DailyComparer(counter),
        Criterion.ID: IdComparer(),
        Criterion.TOTAL: WholeTableComparer(),
    }


class Container(containers.DeclarativeContainer):
    settings: providers.Dependency[Settings] = providers.Dependency(
        instance_of=Settings
    )

    clock = providers.Singleton(SystemClock)
    spawner = providers.Singleton(ThreadSpawner)

    secrets_manager = providers.Singleton(_client, "secretsmanager", settings)
    secrets = providers.Singleton(SecretsManagerProvider, secrets_manager)

    connections = providers.Singleton(
        PostgresConnections, secrets, settings.provided.db_secret
    )
    registry = providers.Singleton(PostgresTableRegistry, connections)
    queries = providers.Singleton(PostgresRegistryQueries, connections)
    results = providers.Singleton(PostgresResultStore, connections)
    history = providers.Singleton(PostgresRunHistory, connections)
    migrations = providers.Singleton(PostgresMigrationValidations, connections)

    progress = providers.Singleton(PostgresProgressStore, connections)
    kube = providers.Singleton(OfficialKubeApi, settings.provided.namespace)
    states = providers.Singleton(ConfigMapRunStateStore, kube)
    pods = providers.Singleton(
        KubernetesWorkerPods, kube, providers.Callable(_pod_spec, settings)
    )

    rules = providers.Singleton(_rules, settings)
    coordinator = providers.Singleton(RunCoordinator)
    reaper = providers.Singleton(RunReaper, states, pods, history, clock, rules)
    fleet = providers.Singleton(WorkerFleet, pods, clock, rules)
    publisher = providers.Singleton(ResultPublisher, results)
    supervisor = providers.Singleton(
        RunSupervisor, states, progress, pods, fleet, publisher, history, clock, rules
    )

    start_run = providers.Singleton(
        StartRun,
        registry,
        states,
        history,
        reaper,
        coordinator,
        supervisor,
        spawner,
        clock,
        rules,
    )
    cancel_run = providers.Singleton(CancelRun, progress, reaper, coordinator)
    run_status = providers.Singleton(GetRunStatus, states, coordinator, clock, rules)
    busy_tables = providers.Singleton(BusyTables, states, clock, rules)

    list_results = providers.Singleton(ListResults, queries)
    list_tags = providers.Singleton(ListTags, queries)
    list_audit = providers.Singleton(ListAudit, queries)
    source_definition = providers.Singleton(GetSourceDefinition, queries)
    create_table = providers.Singleton(CreateTable, registry, secrets)
    edit_table = providers.Singleton(EditTable, registry, secrets)
    delete_table = providers.Singleton(DeleteTable, registry, busy_tables)

    import_migration_databases = providers.Singleton(
        ImportMigrationDatabases, migrations
    )
    register_validation = providers.Singleton(RegisterValidation, migrations)
    migration_overview = providers.Singleton(ListMigrationOverview, migrations)
    migration_validation = providers.Singleton(GetMigrationValidation, migrations)

    origins = providers.Singleton(
        RegistryOriginReaderFactory,
        secrets,
        providers.Callable(
            OriginSettings, query_timeout=settings.provided.query_timeout
        ),
    )
    trino_settings = providers.Singleton(
        load_trino_settings,
        secrets_manager,
        settings.provided.trino_secret,
        settings.provided.trino_timezone,
        settings.provided.trino_host,
    )
    lakes = providers.Singleton(TrinoLakeReaderFactory, trino_settings)
    process_table = providers.Singleton(
        ProcessTable,
        providers.Callable(_comparers, settings),
        providers.Callable(
            lambda s: RetryPolicy(s.table_attempts, s.backoff), settings
        ),
        providers.Callable(lambda c: c.sleep, clock),
    )
    worker_job = providers.Singleton(
        RunWorkerJob,
        progress,
        origins,
        lakes,
        process_table,
        clock,
        settings.provided.table_concurrency,
    )

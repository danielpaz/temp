"""Web entrypoint: `uvicorn app.main:app`."""

from __future__ import annotations

from app.adapters.inbound.http.app import create_app
from app.adapters.inbound.http.services import HttpServices
from app.bootstrap.container import Container
from app.config.settings import Settings


def build_app():
    container = Container(settings=Settings())
    services = HttpServices(
        start_run=container.start_run(),
        cancel_run=container.cancel_run(),
        run_status=container.run_status(),
        list_results=container.list_results(),
        list_tags=container.list_tags(),
        list_audit=container.list_audit(),
        source_definition=container.source_definition(),
        create_table=container.create_table(),
        edit_table=container.edit_table(),
        delete_table=container.delete_table(),
        import_migration_databases=container.import_migration_databases(),
        register_validation=container.register_validation(),
        migration_overview=container.migration_overview(),
        migration_validation=container.migration_validation(),
    )
    return create_app(services)


app = build_app()

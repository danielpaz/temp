"""Operator command: sends databases.csv and skill result folders to the app.

  python -m app.adapters.inbound.cli.migration_import databases databases.csv
  python -m app.adapters.inbound.cli.migration_import validation PASTA \
      --database NOME [--resources recursos.json] [--sibling NOME=PASTA]
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import List, Optional

from app.adapters.inbound.cli import skill_output
from app.domain.exceptions import InvalidRequest
from app.domain.migration_document import from_document

TIMEOUT_SECONDS = 60


class ImportFailure(Exception):
    """A failure to report to the operator, without a traceback."""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="migration_import",
        description="Envia validações de migração SQL Server -> Aurora.",
    )
    parser.add_argument("--url", default=os.environ.get("MIGRATION_URL"))
    parser.add_argument("--actor", default=None)
    parser.add_argument("--dry-run", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)
    dbs = sub.add_parser("databases", help="envia o databases.csv")
    dbs.add_argument("csv", type=Path)
    val = sub.add_parser("validation", help="envia a pasta de resultado de um banco")
    val.add_argument("folder", type=Path)
    val.add_argument("--database", required=True)
    val.add_argument("--resources", type=Path, default=None)
    val.add_argument(
        "--sibling",
        action="append",
        default=[],
        metavar="NOME=PASTA",
        help="outro banco que divide o mesmo Aurora; as tabelas dele que o "
        "comparação dele vale para elas aqui, com uma nota",
    )
    val.add_argument("--sibling-note", default=skill_output.DEFAULT_SIBLING_NOTE)
    return parser


def post(url: str, path: str, payload: dict) -> dict:
    target = url.rstrip("/") + path
    request = urllib.request.Request(
        target,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            return json.loads(response.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as error:
        raise ImportFailure(f"O servidor recusou ({error.code}): {_reason(error)}")
    except (urllib.error.URLError, OSError) as error:
        raise ImportFailure(f"Não foi possível falar com {url}: {error}")
    except ValueError:
        raise ImportFailure("Resposta inválida do servidor.")


def _reason(error: urllib.error.HTTPError) -> str:
    try:
        return str(json.loads(error.read().decode("utf-8")).get("error", ""))
    except (ValueError, AttributeError, OSError):
        return error.reason or ""


def _with_actor(payload: dict, actor: Optional[str]) -> dict:
    return {**payload, "actor": actor} if actor else payload


def _require_url(args: argparse.Namespace) -> str:
    if not args.url:
        raise ImportFailure("Informe --url ou defina a variável MIGRATION_URL.")
    return str(args.url)


def run_databases(args: argparse.Namespace) -> str:
    databases = skill_output.read_databases(args.csv)
    if not databases:
        raise ImportFailure("O CSV não tem nenhum banco.")
    if args.dry_run:
        return f"Simulação: {len(databases)} bancos seriam enviados."
    result = post(
        _require_url(args),
        "/api/migration/databases",
        _with_actor({"databases": databases}, args.actor),
    )
    return f"{result.get('imported', 0)} bancos importados."


def summarize(document: dict) -> str:
    run = from_document(document)
    counts = run.counts
    lines = [
        f"Banco {run.database}: {len(run.tables)} tabelas, status {run.status.value}",
        f"  atenção: {counts.attention}  revisar: {counts.review}  ok: {counts.ok}",
    ]
    lines += [f"  {t.status.value:9} {t.name}" for t in run.ordered_tables()]
    return "\n".join(lines)


def read_siblings(items: List[str]) -> dict:
    siblings = {}
    for item in items:
        name, _, folder = item.partition("=")
        if not name or not folder:
            raise ImportFailure(f"--sibling deve ser NOME=PASTA, recebi {item!r}.")
        siblings[name] = skill_output.sibling_tables(Path(folder), name)
    return siblings


def run_validation(args: argparse.Namespace) -> str:
    resources = (
        skill_output.read_resources(args.resources, args.database)
        if args.resources
        else None
    )
    document = skill_output.build_document(
        args.folder,
        args.database,
        resources,
        read_siblings(args.sibling),
        args.sibling_note,
    )
    try:
        summary = summarize(document)
    except InvalidRequest as error:
        raise ImportFailure(f"Documento inválido: {error}")
    if args.dry_run:
        return "Simulação, nada foi enviado.\n" + summary
    result = post(
        _require_url(args),
        "/api/migration/validations",
        _with_actor({"run": document}, args.actor),
    )
    return f"{summary}\nValidação registrada (id {result.get('id')})."


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    handler = run_databases if args.command == "databases" else run_validation
    try:
        print(handler(args))
    except (ImportFailure, skill_output.SkillOutputError) as error:
        print(f"Erro: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

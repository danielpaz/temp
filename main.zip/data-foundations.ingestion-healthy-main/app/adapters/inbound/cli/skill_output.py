"""Reads the output folder of the sqlserver-aurora-compare skill and turns it into
the validation document the app accepts. Pure functions, standard library only."""

from __future__ import annotations

import csv
import datetime as dt
import json
import dataclasses
import re
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

from app.domain.migration import (
    Check,
    ColumnReport,
    DatabaseFinding,
    EngineInfo,
    Finding,
    Severity,
    TableReport,
    ValidationRun,
)
from app.domain.migration_document import to_document

SEV_ORDER = {"red": 0, "yellow": 1, "info": 2, "skip": 3, "ok": 4}
DATABASE_LEVEL = "(database)"
RESOURCE_ALIASES = {"sct_resposta": "sct_answer"}
RESOURCE_KEYS = ("teleport_sql", "teleport_sql_uri", "teleport_aurora", "sct_answer")
REQUIRED_FILES = (
    "diff.json",
    "snapshot_mssql.json",
    "snapshot_pg.json",
    "colunas.csv",
    "run.json",
)


class SkillOutputError(Exception):
    """The folder or a file in it is missing or unreadable."""


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise SkillOutputError(f"Arquivo não encontrado: {path.name}.")
    except (OSError, ValueError) as error:
        raise SkillOutputError(f"Não foi possível ler {path.name}: {error}")


def parse_timestamp(value: Optional[str]) -> Optional[dt.datetime]:
    if not value:
        return None
    text = value.strip().replace(" ", "T").replace("Z", "+00:00")
    text = re.sub(r"([+-]\d\d)$", r"\1:00", text)
    text = re.sub(r"(\.\d{6})\d+", r"\1", text)
    try:
        moment = dt.datetime.fromisoformat(text)
    except ValueError:
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=dt.timezone.utc)
    return moment.astimezone(dt.timezone.utc)


def column_status(raw: str) -> str:
    text = (raw or "").lower()
    for prefix, status in (
        ("ok", "ok"),
        ("diverg", "red"),
        ("verif", "yellow"),
        ("esper", "expected"),
    ):
        if text.startswith(prefix):
            return status
    return "info"


def read_columns(path: Path) -> Dict[str, List[ColumnReport]]:
    columns: Dict[str, List[ColumnReport]] = {}
    try:
        with open(path, newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                columns.setdefault(row["table_name"], []).append(
                    ColumnReport(
                        row["column_name"],
                        row["src_type"],
                        row["tgt_column"],
                        row["tgt_type"],
                        row["expected_type"],
                        row["src_nullable"],
                        row["tgt_nullable"],
                        column_status(row["status"]),
                        row["detail"],
                    )
                )
    except FileNotFoundError:
        raise SkillOutputError(f"Arquivo não encontrado: {path.name}.")
    except (OSError, KeyError) as error:
        raise SkillOutputError(f"Não foi possível ler {path.name}: {error!r}")
    return columns


def _severity(raw: Any) -> Severity:
    try:
        return Severity(str(raw))
    except ValueError:
        raise SkillOutputError(f"Severidade desconhecida no diff.json: {raw!r}.")


def _check(item: Mapping) -> Check:
    return Check(
        item["check"],
        item.get("title") or item["check"],
        _severity(item["severity"]),
        item["detail"],
    )


def _finding(item: Mapping) -> Finding:
    return Finding(
        item["check"],
        _severity(item["severity"]),
        item["detail"],
        item.get("column"),
        item.get("src"),
        item.get("tgt"),
        bool(item.get("expected")),
    )


def _target_name(checks: List[Check]) -> Optional[str]:
    name = None
    for check in checks:
        if check.title == "Tabela":
            found = re.search(r"como ([\w.-]+)", check.detail)
            if found:
                name = found.group(1)
    return name


def _table(
    name: str,
    items: List[Mapping],
    columns: Dict[str, List[ColumnReport]],
) -> TableReport:
    checks = [_check(i) for i in items if i.get("kind") == "summary"]
    findings = [_finding(i) for i in items if i.get("kind") != "summary"]
    findings.sort(key=lambda f: SEV_ORDER.get(f.severity.value, 9))
    target_name = _target_name(checks)
    return TableReport(
        name,
        target_name,
        tuple(checks),
        tuple(findings),
        tuple(columns.get(name, [])),
    )


def _split_diff(diff: Any) -> Tuple[List[DatabaseFinding], Dict[str, List[Mapping]]]:
    if not isinstance(diff, list):
        raise SkillOutputError("diff.json deve ser uma lista.")
    database: List[DatabaseFinding] = []
    per_table: Dict[str, List[Mapping]] = {}
    for item in diff:
        if item["table"] == DATABASE_LEVEL:
            database.append(
                DatabaseFinding(
                    item["check"],
                    _severity(item["severity"]),
                    item.get("title") or "",
                    item["detail"],
                )
            )
        else:
            per_table.setdefault(item["table"], []).append(item)
    return database, per_table


def normalize_resources(entry: Optional[Mapping]) -> Dict[str, str]:
    """The known resource links of one database, under the document's key names."""
    resources: Dict[str, str] = {}
    for key, value in (entry or {}).items():
        key = RESOURCE_ALIASES.get(key, key)
        if key in RESOURCE_KEYS and isinstance(value, str):
            resources[key] = value
    return resources


def _engine_sql(meta: Mapping) -> EngineInfo:
    version = str(meta["version"]).split("\n")[0].split(" - ")[0].strip()
    return EngineInfo(version, str(meta["server_tz"]))


def _moved(table: TableReport, source_db: str, target_db: str) -> TableReport:
    """A table that exists in the Aurora under another database than its origin."""
    if not table.target_name:
        return table
    detail = (
        f"A tabela estava no database {source_db.upper()} (SQL Server) e agora "
        f"está no database {target_db.upper()} (Aurora)."
    )
    return dataclasses.replace(
        table,
        checks=table.checks + (Check("C10", MOVED_TITLE, Severity.RED, detail),),
        findings=(Finding("C10", Severity.RED, detail),) + table.findings,
    )


def _mark_moved(
    tables: Tuple[TableReport, ...], source_db: str, target_db: str
) -> Tuple[TableReport, ...]:
    if source_db.lower() == target_db.lower():
        return tables
    return tuple(_moved(t, source_db, target_db) for t in tables)


def load_run(
    folder: Path, database: str, resources: Optional[Mapping] = None
) -> ValidationRun:
    for name in REQUIRED_FILES:
        if not (folder / name).is_file():
            raise SkillOutputError(f"Arquivo não encontrado: {name} em {folder}.")
    diff = _read_json(folder / "diff.json")
    source = _read_json(folder / "snapshot_mssql.json")
    target = _read_json(folder / "snapshot_pg.json")
    run = _read_json(folder / "run.json")
    columns = read_columns(folder / "colunas.csv")
    try:
        database_findings, per_table = _split_diff(diff)
        tables = tuple(_table(n, items, columns) for n, items in per_table.items())
        tables = _mark_moved(tables, run["db"], run["tgt_db"])
        captured = parse_timestamp(target["meta"].get("captured_at"))
        return ValidationRun(
            database=database,
            source_db=run["db"],
            target_db=run["tgt_db"],
            target_schema=run.get("tgt_schema"),
            captured_at=captured or dt.datetime.now(dt.timezone.utc),
            source=_engine_sql(source["meta"]),
            target=EngineInfo(
                str(target["meta"]["version"]), str(target["meta"]["server_tz"])
            ),
            tables=tables,
            database_findings=tuple(database_findings),
            resources=normalize_resources(resources),
        )
    except (KeyError, TypeError, AttributeError) as error:
        raise SkillOutputError(f"Formato inesperado na pasta {folder}: {error!r}.")


MOVED_TITLE = "Tabela movimentada entre database"
ONLY_IN_TARGET = "só no Aurora"
DEFAULT_SIBLING_NOTE = "Veio do banco {name}"


def sibling_tables(folder: Path, name: str) -> Dict[str, TableReport]:
    """The tables another database of the same cluster compared against the Aurora,
    by the name they have there (lowercase)."""
    run = load_run(folder, name)
    return {t.target_name.lower(): t for t in run.tables if t.target_name}


def _explained(
    table: TableReport, owner: str, source: TableReport, template: str
) -> TableReport:
    """An Aurora-only table whose comparison was made by a sibling database: it takes
    that comparison (checks, findings, columns) and a note saying where it came from."""
    return dataclasses.replace(
        table,
        target_name=source.target_name,
        checks=source.checks,
        findings=source.findings,
        columns=source.columns,
        note=template.format(name=owner),
    )


def _only_in_target(table: TableReport) -> bool:
    return any(f.check == "C1" and ONLY_IN_TARGET in f.detail for f in table.findings)


def annotate_siblings(
    run: ValidationRun,
    siblings: Mapping[str, Mapping[str, TableReport]],
    template: str = DEFAULT_SIBLING_NOTE,
) -> ValidationRun:
    """Tables that exist only in the Aurora but were compared by a sibling database
    take the sibling's comparison and get a note."""
    tables = []
    for table in run.tables:
        owner = next(
            (n for n, found in siblings.items() if table.name.lower() in found), None
        )
        if owner and _only_in_target(table):
            table = _explained(
                table, owner, siblings[owner][table.name.lower()], template
            )
        tables.append(table)
    return dataclasses.replace(run, tables=tuple(tables))


def build_document(
    folder: Path,
    database: str,
    resources: Optional[Mapping] = None,
    siblings: Optional[Mapping[str, Mapping[str, TableReport]]] = None,
    sibling_note: str = DEFAULT_SIBLING_NOTE,
) -> dict:
    run = load_run(folder, database, resources)
    if siblings:
        run = annotate_siblings(run, siblings, sibling_note)
    return to_document(run)


def read_resources(path: Path, database: str) -> Optional[Mapping]:
    data = _read_json(path)
    if not isinstance(data, dict):
        raise SkillOutputError("recursos.json deve ser um objeto.")
    entry = data.get(database)
    return entry if isinstance(entry, dict) else None


def read_databases(path: Path) -> List[dict]:
    """databases.csv -> the list the databases endpoint takes."""
    try:
        with open(path, newline="", encoding="utf-8-sig") as handle:
            rows = list(csv.DictReader(handle))
    except FileNotFoundError:
        raise SkillOutputError(f"Arquivo não encontrado: {path}.")
    except OSError as error:
        raise SkillOutputError(f"Não foi possível ler {path.name}: {error}")
    if rows and "database" not in rows[0]:
        raise SkillOutputError("O CSV precisa da coluna 'database'.")
    return [
        {
            "database": (row.get("database") or "").strip(),
            "host_sql": (row.get("host_sql") or "").strip(),
            "host_postgresql": (row.get("host_postgresql") or "").strip(),
            "observacao": (row.get("observacao") or "").strip(),
        }
        for row in rows
        if (row.get("database") or "").strip()
    ]

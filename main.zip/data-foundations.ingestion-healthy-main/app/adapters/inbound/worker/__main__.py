"""Worker pod entrypoint: `python -m app.adapters.inbound.worker`."""

from __future__ import annotations

import os

from app.bootstrap.container import Container
from app.config.settings import Settings


def main() -> None:
    container = Container(settings=Settings())
    container.worker_job().run(
        os.environ["RUN_ID"],
        os.environ["WORKER_ID"],
        os.environ["WORKER_HOST"],
        os.environ["WORKER_SECRET"],
        os.environ.get("POD_ATTEMPT", "1"),
    )


if __name__ == "__main__":
    main()

"""What the HTTP adapter needs from the application, in one place."""

from __future__ import annotations

from dataclasses import dataclass

from app.application.use_cases.migration_commands import (
    GetMigrationValidation,
    ImportMigrationDatabases,
    ListMigrationOverview,
    RegisterValidation,
)
from app.application.use_cases.registry_commands import (
    CreateTable,
    DeleteTable,
    EditTable,
    GetSourceDefinition,
    ListAudit,
    ListResults,
    ListTags,
)
from app.application.use_cases.run_commands import CancelRun, GetRunStatus, StartRun


@dataclass(frozen=True)
class HttpServices:
    start_run: StartRun
    cancel_run: CancelRun
    run_status: GetRunStatus
    list_results: ListResults
    list_tags: ListTags
    list_audit: ListAudit
    source_definition: GetSourceDefinition
    create_table: CreateTable
    edit_table: EditTable
    delete_table: DeleteTable
    import_migration_databases: ImportMigrationDatabases
    register_validation: RegisterValidation
    migration_overview: ListMigrationOverview
    migration_validation: GetMigrationValidation

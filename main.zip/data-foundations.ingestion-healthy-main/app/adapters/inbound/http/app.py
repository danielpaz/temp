"""FastAPI application factory."""

from __future__ import annotations

from fastapi import FastAPI

from app.adapters.inbound.http.errors import install_error_handlers
from app.adapters.inbound.http.routers.migration import migration_router
from app.adapters.inbound.http.routers.pages import pages_router
from app.adapters.inbound.http.routers.runs import runs_router
from app.adapters.inbound.http.routers.tables import edits_router, reads_router
from app.adapters.inbound.http.services import HttpServices


def create_app(services: HttpServices) -> FastAPI:
    app = FastAPI(title="Ingestion Healthy", docs_url=None, redoc_url=None)
    install_error_handlers(app)
    app.include_router(pages_router())
    app.include_router(runs_router(services))
    app.include_router(reads_router(services))
    app.include_router(edits_router(services))
    app.include_router(migration_router(services))
    return app

"""Maps domain errors to the status codes and messages of the HTTP contract."""

from __future__ import annotations

import sys

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.domain.exceptions import (
    Conflict,
    DomainError,
    Duplicate,
    InvalidRequest,
    NotFound,
    Unavailable,
)

STATUS_OF = (
    (Duplicate, 409),
    (Conflict, 409),
    (InvalidRequest, 400),
    (NotFound, 404),
    (Unavailable, 503),
)


class HttpFailure(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.message = message


def status_of(error: DomainError) -> int:
    return next((code for kind, code in STATUS_OF if isinstance(error, kind)), 502)


def _reply(status: int, message: str) -> JSONResponse:
    return JSONResponse({"error": message}, status_code=status)


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(HttpFailure)
    async def failure(_request: Request, error: HttpFailure):
        return _reply(error.status, error.message)

    @app.exception_handler(DomainError)
    async def domain(_request: Request, error: DomainError):
        return _reply(status_of(error), str(error))

    @app.exception_handler(Exception)
    async def unexpected(request: Request, error: Exception):
        print(
            f"{request.url.path} error: {type(error).__name__}: {error}",
            file=sys.stderr,
            flush=True,
        )
        return _reply(502, "Não foi possível concluir a operação.")

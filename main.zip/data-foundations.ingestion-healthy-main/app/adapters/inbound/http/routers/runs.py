from __future__ import annotations

import sys
from typing import Any

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from app.adapters.inbound.http.payloads import (
    RUN_BODY_LIMIT,
    json_body,
    table_list,
)
from app.adapters.inbound.http.services import HttpServices


def runs_router(services: HttpServices) -> APIRouter:
    router = APIRouter()
    body_of = Depends(json_body(RUN_BODY_LIMIT))

    @router.get("/api/run")
    def status() -> Any:
        try:
            return services.run_status.execute()
        except Exception as error:
            print(
                f"run status error: {type(error).__name__}: {error}",
                file=sys.stderr,
                flush=True,
            )
            return {
                "status": "unavailable",
                "message": "Não foi possível consultar o estado das execuções.",
            }

    @router.post("/api/run")
    def start(body: dict = body_of) -> Any:
        tables = table_list(body)
        run_id = services.start_run.execute(
            body.get("from"), body.get("to"), tables, body.get("actor")
        )
        return JSONResponse({"run_id": run_id}, status_code=202)

    @router.post("/api/run/cancel")
    def cancel(body: dict = body_of) -> Any:
        return {"cancelled": services.cancel_run.execute(table_list(body))}

    return router

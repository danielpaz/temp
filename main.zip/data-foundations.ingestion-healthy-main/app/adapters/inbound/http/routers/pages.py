from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Response

STATIC = Path(__file__).resolve().parent.parent / "static"


def pages_router() -> APIRouter:
    router = APIRouter()

    def page() -> Response:
        html = (STATIC / "index.html").read_bytes()
        return Response(html, media_type="text/html; charset=utf-8")

    def migration_page() -> Response:
        html = (STATIC / "migration.html").read_bytes()
        return Response(html, media_type="text/html; charset=utf-8")

    router.add_api_route("/", page, methods=["GET"], include_in_schema=False)
    router.add_api_route("/index.html", page, methods=["GET"], include_in_schema=False)

    router.add_api_route(
        "/migration", migration_page, methods=["GET"], include_in_schema=False
    )

    @router.get("/healthz", include_in_schema=False)
    def health() -> Response:
        return Response(b"ok", media_type="text/plain")

    return router

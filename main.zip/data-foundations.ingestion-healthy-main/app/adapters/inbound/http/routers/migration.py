from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from app.adapters.inbound.http import migration_presenters as presenters
from app.adapters.inbound.http.errors import HttpFailure
from app.adapters.inbound.http.payloads import json_body
from app.adapters.inbound.http.services import HttpServices

DATABASES_BODY_LIMIT = 256 * 1024
VALIDATION_BODY_LIMIT = 4 * 1024 * 1024


def migration_router(services: HttpServices) -> APIRouter:
    router = APIRouter()
    databases_body = Depends(json_body(DATABASES_BODY_LIMIT))
    validation_body = Depends(json_body(VALIDATION_BODY_LIMIT))

    @router.get("/api/migration/databases")
    def overview() -> Any:
        return presenters.overview_json(services.migration_overview.execute())

    @router.get("/api/migration/databases/{name}")
    def validation(name: str) -> Any:
        return presenters.validation_json(services.migration_validation.execute(name))

    @router.post("/api/migration/databases")
    def import_databases(body: dict = databases_body) -> Any:
        count = services.import_migration_databases.execute(body.get("databases"))
        return {"imported": count}

    @router.post("/api/migration/validations")
    def register(body: dict = validation_body) -> Any:
        document = body.get("run")
        if not isinstance(document, dict):
            raise HttpFailure(400, "Informe a validação em 'run'.")
        run_id = services.register_validation.execute(document, body.get("actor"))
        return JSONResponse({"id": run_id}, status_code=201)

    return router

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends, Header, Query, Response
from fastapi.responses import JSONResponse

from app.adapters.inbound.http import presenters
from app.adapters.inbound.http.errors import HttpFailure
from app.adapters.inbound.http.payloads import TABLE_BODY_LIMIT, json_body
from app.adapters.inbound.http.results_cache import ResultsCache
from app.adapters.inbound.http.services import HttpServices


def reads_router(services: HttpServices) -> APIRouter:
    router = APIRouter()
    cache = ResultsCache(
        services.list_results.version,
        lambda: presenters.results_json(services.list_results.execute()),
    )

    @router.get("/api/results")
    def results(accept_encoding: str = Header("")) -> Response:
        plain, packed = cache.payload()
        return _negotiated(plain, packed, accept_encoding)

    @router.get("/api/tags")
    def tags() -> Any:
        return presenters.tags_json(services.list_tags.execute())

    @router.get("/api/audit")
    def audit(table: Optional[str] = Query(None), limit: str = "10") -> Any:
        return presenters.audit_json(services.list_audit.execute(table, limit))

    @router.get("/api/ddl")
    def ddl(table: str = "") -> Any:
        return presenters.definition_json(services.source_definition.execute(table))

    return router


def edits_router(services: HttpServices) -> APIRouter:
    router = APIRouter()
    body_of = Depends(json_body(TABLE_BODY_LIMIT))

    @router.post("/api/table")
    def edit(body: dict = body_of) -> Any:
        changes = body.get("changes")
        if not isinstance(changes, dict) or not changes:
            raise HttpFailure(400, "Informe as alterações em 'changes'.")
        done = services.edit_table.execute(
            str(body.get("table")), changes, body.get("actor")
        )
        return {"changed": done}

    @router.post("/api/table/create")
    def create(body: dict = body_of) -> Any:
        fields = body.get("fields")
        if not isinstance(fields, dict):
            raise HttpFailure(400, "Informe os dados da tabela em 'fields'.")
        table_id, key = services.create_table.execute(fields, body.get("actor"))
        return JSONResponse({"id": table_id, "table": str(key)}, status_code=201)

    @router.post("/api/table/delete")
    def delete(body: dict = body_of) -> Any:
        key = services.delete_table.execute(str(body.get("table")), body.get("actor"))
        return {"deleted": str(key)}

    return router


def _negotiated(plain: bytes, packed: bytes, accept_encoding: str) -> Response:
    headers = {"Vary": "Accept-Encoding", "Cache-Control": "no-store"}
    if "gzip" in accept_encoding:
        headers["Content-Encoding"] = "gzip"
        return Response(packed, media_type="application/json", headers=headers)
    return Response(plain, media_type="application/json", headers=headers)

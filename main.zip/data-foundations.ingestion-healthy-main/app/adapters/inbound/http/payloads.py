"""Reads and validates JSON request bodies, with the limits of the contract."""

from __future__ import annotations

import json
from typing import Awaitable, Callable

from fastapi import Request

from app.adapters.inbound.http.errors import HttpFailure

RUN_BODY_LIMIT = 512 * 1024
TABLE_BODY_LIMIT = 4096


def _check_declared_size(request: Request, limit: int) -> None:
    declared = request.headers.get("content-length", "0")
    if not declared.isdigit() or int(declared) > limit:
        raise HttpFailure(413, "Requisição grande demais.")


def _parse(raw: bytes) -> dict:
    try:
        body = json.loads(raw or b"{}")
    except ValueError:
        raise HttpFailure(400, "JSON inválido")
    if not isinstance(body, dict):
        raise HttpFailure(400, "JSON inválido")
    return body


def json_body(limit: int) -> Callable[[Request], Awaitable[dict]]:
    async def read(request: Request) -> dict:
        if not request.headers.get("content-type", "").startswith("application/json"):
            raise HttpFailure(415, "Content-Type deve ser application/json")
        _check_declared_size(request, limit)
        raw = await request.body()
        if len(raw) > limit:
            raise HttpFailure(413, "Requisição grande demais.")
        return _parse(raw)

    return read


def table_list(body: dict):
    tables = body.get("tables")
    ok = tables is None or (
        isinstance(tables, list) and all(isinstance(t, str) for t in tables)
    )
    if not ok:
        raise HttpFailure(400, "tables deve ser uma lista de 'database.schema.tabela'")
    return tables

"""Migration domain objects as the JSON of the HTTP contract."""

from __future__ import annotations

import datetime as dt
import re
from typing import Any, Dict, List, Optional

from app.application.read_models import MigrationDatabaseView, MigrationOverviewRow
from app.domain.migration import (
    ColumnReport,
    Finding,
    Severity,
    SideMeasure,
    StatusCounts,
    TableReport,
    ValidationRun,
)

SEVERITY_ORDER = {
    Severity.RED: 0,
    Severity.YELLOW: 1,
    Severity.INFO: 2,
    Severity.SKIP: 3,
    Severity.OK: 4,
}
PENDING_KINDS = (Severity.RED, Severity.YELLOW, Severity.INFO, Severity.SKIP)


def _iso(moment: Optional[dt.datetime]) -> Optional[str]:
    return moment.strftime("%Y-%m-%dT%H:%M:%SZ") if moment else None


def _counts(counts: StatusCounts) -> Dict[str, int]:
    return {
        "attention": counts.attention,
        "review": counts.review,
        "ok": counts.ok,
    }


def normalized_host(host: str) -> str:
    """The host without port or corporate domain, upper-cased unless it is an IP."""
    host = re.sub(r":\d+$", "", (host or "").strip())
    host = re.sub(r"\.neonprd\.corp$", "", host, flags=re.IGNORECASE)
    is_address = re.match(r"^[\d.]+$", host) or "amazonaws" in host
    return host if is_address else host.upper()


def overview_json(rows: List[MigrationOverviewRow]) -> Dict[str, Any]:
    return {"databases": [_overview_row(row) for row in rows]}


def _overview_row(row: MigrationOverviewRow) -> Dict[str, Any]:
    return {
        "name": row.name,
        "host_sql": row.host_sql,
        "host_pg": row.host_postgresql,
        "obs": row.note,
        "validated": row.validated,
        "status": row.counts.status.value if row.counts else "none",
        "counts": _counts(row.counts) if row.counts else None,
        "tables": row.counts.total if row.counts else 0,
        "captured": _iso(row.captured_at),
        "group": row.teleport_sql or normalized_host(row.host_sql),
        "res": {
            "teleport_sql": row.teleport_sql,
            "teleport_sql_uri": row.teleport_sql_uri,
            "teleport_aurora": row.teleport_aurora,
        },
    }


def validation_json(view: MigrationDatabaseView) -> Dict[str, Any]:
    database = view.database
    return {
        "database": {
            "name": database.name,
            "host_sql": database.host_sql,
            "host_pg": database.host_postgresql,
            "obs": database.note,
        },
        "run": _run(view.run) if view.run else None,
    }


def _run(run: ValidationRun) -> Dict[str, Any]:
    return {
        "src_db": run.source_db,
        "tgt_db": run.target_db,
        "tgt_schema": run.target_schema,
        "captured": _iso(run.captured_at),
        "src_meta": {"engine": run.source.engine, "tz": run.source.timezone},
        "tgt_meta": {"engine": run.target.engine, "tz": run.target.timezone},
        "tables": [_table(t) for t in run.ordered_tables()],
        "verifs": [
            {
                "title": v.title,
                "total": v.total,
                "ok": v.ok,
                "yellow": v.yellow,
                "red": v.red,
                "skip": v.skip,
            }
            for v in run.verifications()
        ],
        "db_findings": [
            {
                "check": f.check,
                "sev": f.severity.value,
                "title": f.title,
                "detail": f.detail,
            }
            for f in run.database_findings
        ],
        "counts": _counts(run.counts),
        "status": run.status.value,
        "res": dict(run.resources),
    }


def _table(table: TableReport) -> Dict[str, Any]:
    findings = sorted(table.findings, key=lambda f: SEVERITY_ORDER[f.severity])
    return {
        "name": table.name,
        "tgt_name": table.target_name,
        "status": table.status.value,
        "n": {kind.value: table.pending(kind) for kind in PENDING_KINDS},
        "checks": [
            {"id": c.id, "title": c.title, "sev": c.severity.value, "detail": c.detail}
            for c in table.checks
        ],
        "findings": [_finding(f) for f in findings],
        "columns": [_column(c) for c in table.columns],
        "src": _measure(table.source),
        "tgt": _measure(table.target),
        "count_caveat": table.count_caveat,
        "note": table.note,
    }


def _finding(finding: Finding) -> Dict[str, Any]:
    return {
        "check": finding.check,
        "sev": finding.severity.value,
        "column": finding.column,
        "src": finding.source,
        "tgt": finding.target,
        "detail": finding.detail,
        "expected": finding.expected,
    }


def _column(column: ColumnReport) -> Dict[str, Any]:
    return {
        "name": column.name,
        "src": column.source_type,
        "tgt_name": column.target_name,
        "tgt": column.target_type,
        "exp": column.expected_type,
        "nsrc": column.source_nullable,
        "ntgt": column.target_nullable,
        "status": column.status,
        "detail": column.detail,
    }


def _measure(side: Optional[SideMeasure]) -> Optional[Dict[str, Any]]:
    if side is None:
        return None
    return {
        "approx": side.approx_rows,
        "size": side.size_bytes,
        "wm_col": side.watermark_column,
        "wm_min": side.watermark_min,
        "wm_max": side.watermark_max,
        "exact": side.exact_rows,
        "cutoff": side.cutoff,
    }

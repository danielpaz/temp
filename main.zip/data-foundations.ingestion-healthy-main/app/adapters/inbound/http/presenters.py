"""Turns read models into the JSON the page consumes."""

from __future__ import annotations

import datetime as dt
from typing import List, Optional

from app.application.read_models import (
    AuditEntry,
    SourceDefinitionView,
    TableOverview,
    TagCount,
)
from app.domain.comparison import DayCount
from app.domain.engines import engine_label


def _iso(value: Optional[dt.datetime]) -> Optional[str]:
    return value.isoformat() if value else None


def _day(day: DayCount) -> dict:
    return {
        "day": day.day.isoformat(),
        "source": day.origin,
        "trino": day.lake,
        "diff": day.diff,
        "status": day.status.value,
    }


def _definition(table: TableOverview) -> dict:
    known = table.origin_definition
    return {
        "has": known.known,
        "columns": known.columns,
        "indexes": known.indexes if known.known else None,
        "pk": known.primary_key,
        "field_indexed": known.filter_column_indexed,
    }


def table_json(table: TableOverview) -> dict:
    key = table.key
    period = table.period
    return {
        "id": table.id,
        "key": str(key),
        "host": table.host,
        "secret": table.secret,
        "engine": engine_label(table.secret),
        "date_field": table.filter_column or "",
        "source_table": key.source_name,
        "trino_table": key.target_name,
        "source": [key.source_database, key.source_schema, key.source_table],
        "target": [key.target_catalog, key.target_schema, key.target_table],
        "status": table.status.value,
        "diff": table.diff,
        "source_total": table.origin_total,
        "trino_total": table.lake_total,
        "error": table.error,
        "day_mode": table.day_mode.value,
        "day_mode_source": table.day_mode_source or "",
        "trino_col_type": table.lake_column_type or "",
        "computed_at": _iso(table.computed_at),
        "result_day_mode": table.result_basis or "",
        "filter_kind": table.filter_kind.value,
        "last_id": table.last_id,
        "source_def": _definition(table),
        "object_type": table.object_type.value if table.object_type else "",
        "object_ddl": table.object_ddl or "",
        "object_checked_at": _iso(table.object_checked_at),
        "source_size_bytes": table.origin_size_bytes,
        "period": [period.start.isoformat(), period.end.isoformat()]
        if period
        else None,
        "enabled": table.enabled,
        "config_pending": table.config_pending,
        "tags": list(table.tags),
        "days": [_day(d) for d in table.days],
    }


def results_json(tables: List[TableOverview]) -> dict:
    rows = [table_json(t) for t in tables]
    days = sorted({d["day"] for row in rows for d in row["days"]})
    return {"range": [days[0], days[-1]] if days else None, "tables": rows}


def tags_json(tags: List[TagCount]) -> dict:
    return {"tags": [{"tag": t.tag, "tables": t.tables} for t in tags]}


def audit_json(entries: List[AuditEntry]) -> dict:
    return {
        "audit": [
            {
                "at": e.at.isoformat(),
                "actor": e.actor,
                "action": e.action,
                "field": e.field,
                "old": e.old,
                "new": e.new,
                "table": e.table,
            }
            for e in entries
        ]
    }


def definition_json(view: SourceDefinitionView) -> dict:
    return {
        "table": view.table,
        "ddl": view.ddl,
        "indexes": view.indexes,
        "columns": view.columns,
        "checked_at": _iso(view.checked_at),
        "filter_column": view.filter_column,
    }

"""Serialising and compressing tens of thousands of rows is expensive: it is
done once per data version, not once per request."""

from __future__ import annotations

import gzip
import json
import threading
from typing import Callable, Optional, Tuple


class ResultsCache:
    def __init__(self, version: Callable[[], tuple], build: Callable[[], dict]) -> None:
        self.version = version
        self.build = build
        self._key: Optional[tuple] = None
        self._body = b""
        self._gz = b""
        self._lock = threading.Lock()

    def payload(self) -> Tuple[bytes, bytes]:
        key = self.version()
        if self._key == key:
            return self._body, self._gz
        with self._lock:
            if self._key != key:
                body = json.dumps(self.build()).encode()
                self._body = body
                self._gz = gzip.compress(body, compresslevel=5)
                self._key = key
            return self._body, self._gz

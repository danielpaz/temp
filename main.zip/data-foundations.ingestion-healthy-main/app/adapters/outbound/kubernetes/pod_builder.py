"""Builds the manifest of a worker pod. Pure: no cluster involved."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping

from app.application.ports.cluster import WorkerLaunch

WORKER_LABEL = "ingestion-healthy-worker"
WORKER_COMMAND = ["python", "-m", "app.adapters.inbound.worker"]


@dataclass(frozen=True)
class WorkerPodSpec:
    """What every worker pod shares: it runs the same image as the web app."""

    image: str
    service_account: str = "ingestion-healthy"
    memory_request: str = "512Mi"
    memory_limit: str = "4Gi"
    cpu_request: str = "100m"
    deadline_seconds: int = 13000
    run_as_user: int = 100
    run_as_group: int = 101
    forwarded_env: Mapping[str, str] = field(default_factory=dict)


class WorkerPodBuilder:
    def __init__(self, spec: WorkerPodSpec) -> None:
        self._spec = spec

    def build(self, launch: WorkerLaunch) -> Dict[str, Any]:
        return {
            "apiVersion": "v1",
            "kind": "Pod",
            "metadata": self._metadata(launch),
            "spec": self._pod_spec(launch),
        }

    def _metadata(self, launch: WorkerLaunch) -> Dict[str, Any]:
        return {
            "name": launch.pod_name,
            "labels": {
                "app": WORKER_LABEL,
                "run-id": launch.run_id,
                "worker": launch.worker_id,
            },
            # node consolidation must not kill a run in progress
            "annotations": {"karpenter.sh/do-not-disrupt": "true"},
        }

    def _pod_spec(self, launch: WorkerLaunch) -> Dict[str, Any]:
        spec = self._spec
        return {
            "serviceAccountName": spec.service_account,
            "restartPolicy": "Never",
            "nodeSelector": {"kubernetes.io/arch": "amd64"},
            "activeDeadlineSeconds": spec.deadline_seconds,
            "securityContext": {
                "runAsNonRoot": True,
                "runAsUser": spec.run_as_user,
                "runAsGroup": spec.run_as_group,
            },
            "containers": [self._container(launch)],
        }

    def _container(self, launch: WorkerLaunch) -> Dict[str, Any]:
        spec = self._spec
        return {
            "name": "worker",
            "image": spec.image,
            "command": list(WORKER_COMMAND),
            "env": self._env(launch),
            "resources": {
                "requests": {"cpu": spec.cpu_request, "memory": spec.memory_request},
                "limits": {"memory": spec.memory_limit},
            },
        }

    def _env(self, launch: WorkerLaunch) -> List[Dict[str, str]]:
        values = {
            "PYTHONUNBUFFERED": "1",
            **self._spec.forwarded_env,
            "RUN_ID": launch.run_id,
            "WORKER_ID": launch.worker_id,
            "WORKER_HOST": launch.host,
            "WORKER_SECRET": launch.secret,
            "POD_ATTEMPT": str(launch.attempt),
        }
        return [{"name": k, "value": v} for k, v in values.items()]

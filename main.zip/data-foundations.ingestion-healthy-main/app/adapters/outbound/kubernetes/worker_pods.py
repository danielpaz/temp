"""WorkerPods on Kubernetes."""

from __future__ import annotations

from typing import List

from app.adapters.outbound.kubernetes.kube_api import KubeApi
from app.adapters.outbound.kubernetes.pod_builder import (
    WORKER_LABEL,
    WorkerPodBuilder,
    WorkerPodSpec,
)
from app.application.ports.cluster import WorkerLaunch, WorkerPods
from app.domain.run import PodInfo


class KubernetesWorkerPods(WorkerPods):
    def __init__(self, api: KubeApi, spec: WorkerPodSpec) -> None:
        self._api = api
        self._builder = WorkerPodBuilder(spec)

    def launch(self, launch: WorkerLaunch) -> None:
        self._api.create_pod(self._builder.build(launch))

    def delete(self, pod_name: str) -> None:
        self._api.delete_pod(pod_name)

    def list(self, run_id: str) -> List[PodInfo]:
        selector = f"app={WORKER_LABEL},run-id={run_id}"
        return self._api.list_pods(selector)

    def delete_run(self, run_id: str) -> None:
        for pod in self.list(run_id):
            self._api.delete_pod(pod.name)

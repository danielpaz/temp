"""RunStateStore on ConfigMaps: ih-state-<run_id>, data key state.json."""

from __future__ import annotations

import json
from typing import Dict, List

from app.adapters.outbound.kubernetes.kube_api import KubeApi
from app.application.ports.cluster import RunStateStore
from app.domain.run import RunState

STATE_LABELS = {"app": "ingestion-healthy-state"}
STATE_SELECTOR = "app=ingestion-healthy-state"
STATE_KEY = "state.json"


def config_map_name(run_id: str) -> str:
    return f"ih-state-{run_id}"


def to_data(state: RunState) -> Dict[str, str]:
    return {STATE_KEY: json.dumps(state.snapshot())}


def from_data(data: Dict[str, str]) -> RunState:
    return RunState.from_snapshot(json.loads(data[STATE_KEY]))


class ConfigMapRunStateStore(RunStateStore):
    def __init__(self, api: KubeApi) -> None:
        self._api = api

    def list(self) -> List[RunState]:
        found = self._api.list_config_maps(STATE_SELECTOR)
        return [from_data(data) for data in found if data.get(STATE_KEY)]

    def create(self, state: RunState) -> None:
        name = config_map_name(state.run_id)
        self._api.create_config_map(name, dict(STATE_LABELS), to_data(state))

    def replace(self, state: RunState) -> None:
        name = config_map_name(state.run_id)
        self._api.replace_config_map(name, dict(STATE_LABELS), to_data(state))

    def delete(self, run_id: str) -> None:
        self._api.delete_config_map(config_map_name(run_id))

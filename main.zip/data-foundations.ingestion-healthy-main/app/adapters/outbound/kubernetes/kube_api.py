"""The thin boundary to the kubernetes client. Everything above it is testable
with a fake; this file is the only one that imports the client."""

from __future__ import annotations

import time
from typing import Any, Dict, List, Protocol

from app.domain.exceptions import Conflict
from app.domain.run import PodInfo


class KubeApi(Protocol):
    def create_pod(self, manifest: Dict[str, Any]) -> None:
        """Starts a pod."""

    def delete_pod(self, name: str) -> None:
        """A pod that is already gone is not an error."""

    def list_pods(self, selector: str) -> List[PodInfo]:
        """The pods matching a label selector."""

    def list_config_maps(self, selector: str) -> List[Dict[str, str]]:
        """The data of every matching ConfigMap."""

    def create_config_map(
        self, name: str, labels: Dict[str, str], data: Dict[str, str]
    ) -> None:
        """Raises Conflict when it already exists."""

    def replace_config_map(
        self, name: str, labels: Dict[str, str], data: Dict[str, str]
    ) -> None:
        """Overwrites a ConfigMap."""

    def delete_config_map(self, name: str) -> None:
        """A ConfigMap that is already gone is not an error."""


def pod_reason(pod: Any) -> str:
    """Why a pod is where it is: unschedulable, waiting or terminated."""
    reason = pod.status.reason or ""
    for cond in pod.status.conditions or []:
        if cond.reason == "Unschedulable":
            reason = "Unschedulable"
    for status in pod.status.container_statuses or []:
        reason = _container_reason(status.state) or reason
    return reason


def _container_reason(state: Any) -> str:
    if state.terminated:
        done = state.terminated
        return f"{done.reason or 'Terminated'} (exit {done.exit_code})"
    if state.waiting and state.waiting.reason:
        return str(state.waiting.reason)
    return ""


def pod_info(pod: Any) -> PodInfo:
    stamp = pod.metadata.creation_timestamp
    return PodInfo(
        name=pod.metadata.name,
        phase=pod.status.phase,
        reason=pod_reason(pod),
        created=stamp.timestamp() if stamp else time.time(),
    )


class OfficialKubeApi:
    """KubeApi on the official client, in one namespace."""

    def __init__(self, namespace: str) -> None:
        from kubernetes import client, config

        try:
            config.load_incluster_config()
        except config.ConfigException:
            config.load_kube_config()
        self._ns = namespace
        self._client = client
        cfg = client.Configuration.get_default_copy()
        api = client.ApiClient(cfg)
        relax_strict_x509(api, cfg)
        self._core = client.CoreV1Api(api)
        self._error = client.exceptions.ApiException

    def create_pod(self, manifest: Dict[str, Any]) -> None:
        self._core.create_namespaced_pod(self._ns, manifest)

    def delete_pod(self, name: str) -> None:
        self._ignoring_missing(
            lambda: self._core.delete_namespaced_pod(
                name, self._ns, grace_period_seconds=0
            )
        )

    def list_pods(self, selector: str) -> List[PodInfo]:
        pods = self._core.list_namespaced_pod(self._ns, label_selector=selector)
        return [pod_info(p) for p in pods.items]

    def list_config_maps(self, selector: str) -> List[Dict[str, str]]:
        found = self._core.list_namespaced_config_map(self._ns, label_selector=selector)
        return [dict(cm.data or {}) for cm in found.items]

    def create_config_map(
        self, name: str, labels: Dict[str, str], data: Dict[str, str]
    ) -> None:
        try:
            self._core.create_namespaced_config_map(
                self._ns, self._body(name, labels, data)
            )
        except self._error as error:
            if error.status == 409:
                raise Conflict("O estado da execução já existe.") from error
            raise

    def replace_config_map(
        self, name: str, labels: Dict[str, str], data: Dict[str, str]
    ) -> None:
        self._core.replace_namespaced_config_map(
            name, self._ns, self._body(name, labels, data)
        )

    def delete_config_map(self, name: str) -> None:
        self._ignoring_missing(
            lambda: self._core.delete_namespaced_config_map(name, self._ns)
        )

    def _body(self, name: str, labels: Dict[str, str], data: Dict[str, str]) -> Any:
        c = self._client
        return c.V1ConfigMap(
            metadata=c.V1ObjectMeta(name=name, labels=labels), data=data
        )

    def _ignoring_missing(self, call: Any) -> None:
        try:
            call()
        except self._error as error:
            if error.status != 404:
                raise


def relax_strict_x509(api: Any, cfg: Any) -> None:
    """Python 3.13 rejects the EKS cluster CA (it has no Authority Key
    Identifier). Drops only that strict flag for this client; the chain and the
    hostname are still verified."""
    import ssl

    import urllib3

    if not hasattr(ssl, "VERIFY_X509_STRICT"):
        return
    cafile = cfg.ssl_ca_cert or None
    ctx = ssl.create_default_context(cafile=cafile)
    ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
    api.rest_client.pool_manager = urllib3.PoolManager(
        num_pools=4, maxsize=8, ssl_context=ctx
    )

"""Trino implementation of the lake ports."""

from __future__ import annotations

import datetime as dt
from contextlib import contextmanager
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple

from app.adapters.outbound.trino import sql
from app.adapters.outbound.trino.connection import TrinoSettings, open_cursor
from app.application.ports.lake import LakeReader, LakeReaderFactory
from app.domain.comparison import LakeObject
from app.domain.values import DayMode, ObjectType, Period, TableKey

CursorFactory = Callable[[], Any]


class TrinoLakeReader(LakeReader):
    """One lazy session; it is dropped after any failure and reopened on demand."""

    def __init__(self, cursor_factory: CursorFactory) -> None:
        self._open = cursor_factory
        self._cursor: Any = None

    @contextmanager
    def _translating(self) -> Iterator[None]:
        try:
            yield
        except Exception as error:
            self._cursor = None
            raise sql.classify_error(error) from error

    def _rows(self, statement: str) -> List[tuple]:
        if self._cursor is None:
            self._cursor = self._open()
        self._cursor.execute(statement)
        return list(self._cursor.fetchall())

    def inspect_object(self, key: TableKey) -> Optional[LakeObject]:
        try:
            rows = self._rows(sql.object_type_sql(key))
            if not rows:
                return None
            if rows[0][0] != "VIEW":
                return LakeObject(ObjectType.TABLE)
            return LakeObject(ObjectType.VIEW, self._rows(sql.show_view_sql(key))[0][0])
        except Exception:
            self._cursor = None
            return None

    def column_type(self, key: TableKey, column: str) -> str:
        with self._translating():
            for name, kind, *_ in self._rows(sql.show_columns_sql(key)):
                if name.lower() == column.lower():
                    return str(kind)
            raise sql.missing_column(key, column)

    def count_by_day(
        self,
        key: TableKey,
        column: str,
        column_type: str,
        mode: DayMode,
        period: Period,
    ) -> Dict[dt.date, int]:
        with self._translating():
            statement = sql.day_count_sql(
                key, column, column_type, mode, period.start, period.end_exclusive
            )
            return {day: int(n) for day, n in self._rows(statement)}

    def count_rows(self, key: TableKey) -> int:
        with self._translating():
            return int(self._rows(sql.total_sql(key))[0][0])

    def last_id(self, key: TableKey, column: str) -> Tuple[Optional[int], int]:
        sql.ensure_id_type(column, self.column_type(key, column))
        with self._translating():
            last = self._rows(sql.max_id_sql(key, column))[0][0]
            if last is None:
                return None, 0
            counted = self._rows(sql.count_up_to_sql(key, column, int(last)))
            return int(last), int(counted[0][0])


class TrinoLakeReaderFactory(LakeReaderFactory):
    def __init__(
        self,
        settings: TrinoSettings,
        cursor_factory: Callable[[TrinoSettings], Any] = open_cursor,
    ) -> None:
        self._settings = settings
        self._cursor_factory = cursor_factory

    def open(self) -> LakeReader:
        return TrinoLakeReader(lambda: self._cursor_factory(self._settings))

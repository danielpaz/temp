"""Builds the Trino connection settings from the credentials secret."""

from __future__ import annotations

import json
from typing import Any

from app.adapters.outbound.trino.connection import TrinoSettings


def load_trino_settings(
    secrets_client: Any,
    secret_name: str,
    timezone: str,
    host_override: str = "",
    request_timeout: int = 600,
) -> TrinoSettings:
    raw = secrets_client.get_secret_value(SecretId=secret_name)["SecretString"]
    data = json.loads(raw)
    return TrinoSettings(
        host=host_override or data["host"],
        port=int(data["port"]),
        user=data["username"],
        password=data["password"],
        timezone=timezone or "America/Sao_Paulo",
        request_timeout=request_timeout,
    )

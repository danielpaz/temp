"""SQL and classification rules of the lake (Trino). Pure: no I/O."""

from __future__ import annotations

import datetime as dt
from typing import Callable, Dict

from app.domain.exceptions import DomainError, LakeError, PermanentError
from app.domain.values import DayMode, TableKey

SAO_PAULO = "America/Sao_Paulo"
ID_TYPES = ("tinyint", "smallint", "integer", "bigint")
# Trino errors that retrying cannot fix: the analytical table is simply not there.
PERMANENT_CODES = (
    "SCHEMA_NOT_FOUND",
    "TABLE_NOT_FOUND",
    "COLUMN_NOT_FOUND",
    "CATALOG_NOT_FOUND",
    "TRINO_SESSION_TIMEZONE_MISMATCH",
    "TRINO_DAY_MODE_UNDEFINED",
    "TRINO_COLUMN_NOT_FOUND",
)


def quote(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def literal(text: str) -> str:
    return "'" + text.replace("'", "''") + "'"


def qualified(key: TableKey) -> str:
    return ".".join(
        quote(n) for n in (key.target_catalog, key.target_schema, key.target_table)
    )


def classify_error(error: Exception) -> DomainError:
    if isinstance(error, DomainError):
        return error
    message = f"trino query failed: {_short(error)}"
    if any(code in message for code in PERMANENT_CODES):
        return PermanentError(message)
    return LakeError(message)


def _short(error: Exception) -> str:
    return f"{type(error).__name__}: {' '.join(str(error).split())[:300]}"


def ensure_session_timezone(got: str, expected: str) -> None:
    if got != expected:
        raise PermanentError(
            f"TRINO_SESSION_TIMEZONE_MISMATCH: sessão com {got}, esperado {expected}"
        )


def ensure_id_type(column: str, column_type: str) -> None:
    if column_type not in ID_TYPES:
        raise PermanentError(
            f"TRINO_DAY_MODE_UNDEFINED: a coluna {column} é do tipo {column_type}; "
            "para comparar por ID a coluna precisa ser inteira"
        )


def missing_column(key: TableKey, column: str) -> PermanentError:
    return PermanentError(
        f"TRINO_COLUMN_NOT_FOUND: a coluna {column} não existe em {key.target_name}"
    )


def show_columns_sql(key: TableKey) -> str:
    return f"SHOW COLUMNS FROM {qualified(key)}"


def object_type_sql(key: TableKey) -> str:
    return (
        f"SELECT table_type FROM {quote(key.target_catalog)}.information_schema.tables "
        f"WHERE table_schema = {literal(key.target_schema)} "
        f"AND table_name = {literal(key.target_table)}"
    )


def show_view_sql(key: TableKey) -> str:
    return f"SHOW CREATE VIEW {qualified(key)}"


def total_sql(key: TableKey) -> str:
    return f"SELECT count(*) FROM {qualified(key)}"


def max_id_sql(key: TableKey, column: str) -> str:
    return f"SELECT max({quote(column)}) FROM {qualified(key)}"


def count_up_to_sql(key: TableKey, column: str, last: int) -> str:
    return f"SELECT count(*) FROM {qualified(key)} WHERE {quote(column)} <= {last}"


def _stamp(day: dt.date, zone: str = "") -> str:
    return f"TIMESTAMP '{day} 00:00:00{' ' + zone if zone else ''}'"


def _date_sql(fq: str, c: str, mode: DayMode, a: dt.date, b: dt.date) -> str:
    """A date has no time of day: it is its own day in both modes."""
    return (
        f"SELECT {c}, count(*) FROM {fq} "
        f"WHERE {c} >= DATE '{a}' AND {c} < DATE '{b}' GROUP BY 1"
    )


def _naive_sql(fq: str, c: str, mode: DayMode, a: dt.date, b: dt.date) -> str:
    """Without a zone the value is São Paulo wall-clock time (the session zone)."""
    if mode is DayMode.SAO_PAULO:
        return (
            f"SELECT CAST({c} AS date), count(*) FROM {fq} "
            f"WHERE {c} >= {_stamp(a)} AND {c} < {_stamp(b)} GROUP BY 1"
        )
    one = dt.timedelta(days=1)
    wall = f"with_timezone({c}, '{SAO_PAULO}')"
    # a coarse bound on the bare column so the table can prune, then the exact one
    return (
        f"SELECT date({wall} AT TIME ZONE 'UTC'), count(*) FROM {fq} "
        f"WHERE {c} >= {_stamp(a - one)} AND {c} < {_stamp(b + one)} "
        f"AND {wall} >= {_stamp(a, 'UTC')} AND {wall} < {_stamp(b, 'UTC')} GROUP BY 1"
    )


def _zoned_sql(fq: str, c: str, mode: DayMode, a: dt.date, b: dt.date) -> str:
    """No cast on the column: it would strip the zone and shift the day."""
    zone = SAO_PAULO if mode is DayMode.SAO_PAULO else "UTC"
    return (
        f"SELECT date({c} AT TIME ZONE '{zone}'), count(*) FROM {fq} "
        f"WHERE {c} >= {_stamp(a, zone)} AND {c} < {_stamp(b, zone)} GROUP BY 1"
    )


_BUILDERS: Dict[str, Callable[[str, str, DayMode, dt.date, dt.date], str]] = {
    "date": _date_sql,
    "naive": _naive_sql,
    "zoned": _zoned_sql,
}


def type_kind(column: str, column_type: str) -> str:
    ty = column_type.lower()
    if ty == "date":
        return "date"
    if ty.startswith("timestamp"):
        return "zoned" if "with time zone" in ty else "naive"
    raise PermanentError(
        f"TRINO_DAY_MODE_UNDEFINED: a coluna {column} é do tipo {column_type}, "
        "que não é uma data nem um timestamp"
    )


def day_count_sql(
    key: TableKey,
    column: str,
    column_type: str,
    mode: DayMode,
    start: dt.date,
    end_exclusive: dt.date,
) -> str:
    build = _BUILDERS[type_kind(column, column_type)]
    return build(qualified(key), quote(column), mode, start, end_exclusive)

"""Opens a Trino session. The only place that talks to the trino client."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import trino
from trino.auth import BasicAuthentication

from app.adapters.outbound.trino.sql import SAO_PAULO, ensure_session_timezone


@dataclass(frozen=True)
class TrinoSettings:
    host: str
    port: int
    user: str = field(repr=False)
    password: str = field(repr=False)
    timezone: str = SAO_PAULO
    query_max_run_time: str = "10m"
    request_timeout: int = 600
    http_scheme: str = "https"


def open_cursor(settings: TrinoSettings) -> Any:
    """The session is opened with an explicit time zone (the client would send the
    pod's, UTC) and refused when the server does not apply it: the day buckets of
    time-zone columns depend on it."""
    conn = trino.dbapi.connect(
        host=settings.host,
        port=settings.port,
        user=settings.user,
        http_scheme=settings.http_scheme,
        auth=BasicAuthentication(settings.user, settings.password),
        source="ingestion-healthy",
        session_properties={"query_max_run_time": settings.query_max_run_time},
        request_timeout=settings.request_timeout,
        timezone=settings.timezone,
    )
    cursor = conn.cursor()
    cursor.execute("SELECT current_timezone()")
    ensure_session_timezone(cursor.fetchone()[0], settings.timezone)
    return cursor

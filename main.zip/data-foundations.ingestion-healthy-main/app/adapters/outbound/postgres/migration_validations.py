"""MigrationValidations on the app database (migration_database/_validation)."""

from __future__ import annotations

from typing import List, Optional, Sequence

from psycopg2.extras import Json

from app.adapters.outbound.postgres.connections import PostgresConnections
from app.application.ports.migration import MigrationValidations
from app.application.read_models import MigrationOverviewRow
from app.domain.migration import MigrationDatabase, StatusCounts, ValidationRun
from app.domain.migration_document import from_document, to_document

UPSERT_DATABASE = (
    "INSERT INTO migration_database (name, host_sql, host_postgresql, note) "
    "VALUES (%s, %s, %s, %s) "
    "ON CONFLICT (name) DO UPDATE SET host_sql = EXCLUDED.host_sql, "
    "host_postgresql = EXCLUDED.host_postgresql, note = EXCLUDED.note, "
    "updated_at = now()"
)
SELECT_DATABASE = (
    "SELECT name, host_sql, host_postgresql, note "
    "FROM migration_database WHERE name = %s"
)
INSERT_RUN = (
    "INSERT INTO migration_validation (database_name, captured_at, source_db, "
    "target_db, target_schema, attention, review, ok, tables, resources, report, "
    "registered_by) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
    "RETURNING id"
)
SELECT_LATEST = (
    "SELECT report FROM migration_validation WHERE database_name = %s "
    "ORDER BY registered_at DESC, id DESC LIMIT 1"
)
SELECT_OVERVIEW = (
    "SELECT d.name, d.host_sql, d.host_postgresql, d.note, v.attention, v.review, "
    "v.ok, v.captured_at, v.resources->>'teleport_sql' AS teleport_sql, "
    "v.resources->>'teleport_sql_uri' AS teleport_sql_uri, "
    "v.resources->>'teleport_aurora' AS teleport_aurora "
    "FROM migration_database d LEFT JOIN LATERAL ("
    "SELECT attention, review, ok, captured_at, resources "
    "FROM migration_validation WHERE database_name = d.name "
    "ORDER BY registered_at DESC, id DESC LIMIT 1) v ON true "
    "ORDER BY d.name"
)


class PostgresMigrationValidations(MigrationValidations):
    def __init__(self, connections: PostgresConnections) -> None:
        self._connections = connections

    def upsert_databases(self, databases: Sequence[MigrationDatabase]) -> int:
        with self._connections.transaction() as cur:
            for item in databases:
                args = (item.name, item.host_sql, item.host_postgresql, item.note)
                cur.execute(UPSERT_DATABASE, args)
        return len(databases)

    def database(self, name: str) -> Optional[MigrationDatabase]:
        with self._connections.transaction() as cur:
            cur.execute(SELECT_DATABASE, (name,))
            row = cur.fetchone()
        if row is None:
            return None
        return MigrationDatabase(
            row["name"], row["host_sql"], row["host_postgresql"], row["note"]
        )

    def save_run(self, run: ValidationRun, actor: str) -> int:
        counts = run.counts
        args = (
            run.database,
            run.captured_at,
            run.source_db,
            run.target_db,
            run.target_schema,
            counts.attention,
            counts.review,
            counts.ok,
            counts.total,
            Json(dict(run.resources)),
            Json(to_document(run)),
            actor,
        )
        with self._connections.transaction() as cur:
            cur.execute(INSERT_RUN, args)
            return cur.fetchone()["id"]

    def latest_run(self, name: str) -> Optional[ValidationRun]:
        with self._connections.transaction() as cur:
            cur.execute(SELECT_LATEST, (name,))
            row = cur.fetchone()
        return None if row is None else from_document(row["report"])

    def overview(self) -> List[MigrationOverviewRow]:
        with self._connections.transaction() as cur:
            cur.execute(SELECT_OVERVIEW)
            return [_overview_row(row) for row in cur.fetchall()]


def _overview_row(row) -> MigrationOverviewRow:
    counts = None
    if row["captured_at"] is not None:
        counts = StatusCounts(row["attention"], row["review"], row["ok"])
    return MigrationOverviewRow(
        row["name"],
        row["host_sql"],
        row["host_postgresql"],
        row["note"],
        counts,
        row["captured_at"],
        row["teleport_sql"] or "",
        row["teleport_sql_uri"] or "",
        row["teleport_aurora"] or "",
    )

"""SQL fragments shared by the registry adapters."""

from __future__ import annotations

from typing import Tuple

from app.domain.registry_rules import KEY_FIELDS, SOURCE_FIELDS, TARGET_FIELDS
from app.domain.values import TableKey


def key_match(alias: str = "") -> str:
    """WHERE fragment matching one row by its origin and Trino names, ignoring
    case. Takes the six parameters of `key_params`."""
    prefix = f"{alias}." if alias else ""
    return " AND ".join(f"lower({prefix}{f}) = lower(%s)" for f in KEY_FIELDS)


def key_params(key: TableKey) -> Tuple[str, ...]:
    return tuple(getattr(key, f) for f in KEY_FIELDS)


def key_text(alias: str = "") -> str:
    """SQL expression building 'db.schema.table@catalog.schema.table'."""
    prefix = f"{alias}." if alias else ""
    source = "||'.'||".join(f"{prefix}{f}" for f in SOURCE_FIELDS)
    target = "||'.'||".join(f"{prefix}{f}" for f in TARGET_FIELDS)
    return f"{source}||'@'||{target}"

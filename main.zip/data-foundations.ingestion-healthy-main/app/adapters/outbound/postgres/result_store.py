"""ResultStore on PostgreSQL: publishes what a run compared."""

from __future__ import annotations

import json
from typing import Any, List, Optional, Sequence, Tuple

from psycopg2.extras import execute_values

from app.adapters.outbound.postgres.connections import PostgresConnections
from app.application.ports.registry import ResultStore
from app.domain.comparison import ComparisonResult
from app.domain.entities import MonitoredTable

COLUMNS = (
    "table_id, run_id, period_from, period_to, status, date_field, day_mode, "
    "mode_source, days, days_different, source_total, trino_total, diff, "
    "error, last_id, computed_at"
)
UPDATES = (
    ", ".join(
        f"{c}=EXCLUDED.{c}"
        for c in (
            "run_id, period_from, period_to, status, date_field, day_mode, "
            "mode_source, days, days_different, source_total, trino_total, diff, "
            "error, last_id"
        ).split(", ")
    )
    + ", computed_at=now()"
)
VALUES = (
    "(%s, %s, %s, %s, %s, %s, %s, "
    "(SELECT mode_source FROM monitored_table WHERE id = %s), "
    "%s, %s, %s, %s, %s, %s, %s, now())"
)


def table_id(table: MonitoredTable) -> int:
    if table.id is None:
        raise ValueError(f"A tabela {table.key} não tem id.")
    return table.id


def result_params(
    run_id: str, table: MonitoredTable, result: ComparisonResult
) -> tuple:
    """Parameters of the result row; the table id appears twice (mode_source)."""
    tid = table_id(table)
    days = result.days
    return (
        tid,
        run_id,
        result.period.start,
        result.period.end,
        result.status.value,
        result.filter_column,
        result.basis.value if result.basis else None,
        tid,
        len(days) if days else None,
        result.days_different if days else None,
        result.origin_total,
        result.lake_total,
        result.diff,
        result.error,
        result.last_id,
    )


def day_rows(tid: int, result: ComparisonResult) -> List[tuple]:
    return [(tid, d.day, d.origin, d.lake, d.diff, d.status.value) for d in result.days]


class PostgresResultStore(ResultStore):
    def __init__(self, connections: PostgresConnections) -> None:
        self._connections = connections

    def publish(
        self,
        run_id: str,
        items: Sequence[Tuple[MonitoredTable, ComparisonResult]],
    ) -> None:
        with self._connections.transaction() as cur:
            for table, result in items:
                self._publish_one(cur, run_id, table, result)

    def _publish_one(
        self, cur: Any, run_id: str, table: MonitoredTable, result: ComparisonResult
    ) -> None:
        params = result_params(run_id, table, result)
        self._upsert(cur, "table_result", "(table_id)", params)
        self._upsert(cur, "table_result_history", "(run_id, table_id)", params)
        self._replace_days(cur, params[0], result)
        self._update_facts(cur, params[0], result)

    def _upsert(self, cur: Any, target: str, conflict: str, params: tuple) -> None:
        cur.execute(
            f"INSERT INTO {target} ({COLUMNS}) VALUES {VALUES} "
            f"ON CONFLICT {conflict} DO UPDATE SET {UPDATES}",
            params,
        )

    def _replace_days(self, cur: Any, tid: int, result: ComparisonResult) -> None:
        cur.execute("DELETE FROM table_result_day WHERE table_id = %s", (tid,))
        if result.days:
            execute_values(
                cur,
                "INSERT INTO table_result_day "
                "(table_id, day, source_count, trino_count, diff, status) "
                "VALUES %s",
                day_rows(tid, result),
                page_size=2000,
            )

    def _update_facts(self, cur: Any, tid: int, result: ComparisonResult) -> None:
        facts = result.facts
        self._origin_definition(cur, tid, facts.origin_definition)
        if facts.origin_size_bytes is not None:
            cur.execute(
                "UPDATE monitored_table SET source_size_bytes=%s, "
                "source_size_checked_at=now() WHERE id=%s",
                (facts.origin_size_bytes, tid),
            )
        self._lake_object(cur, tid, facts.lake_object)
        if facts.lake_column_type:
            cur.execute(
                "UPDATE monitored_table SET trino_col_type=%s WHERE id=%s",
                (facts.lake_column_type, tid),
            )

    def _origin_definition(self, cur: Any, tid: int, found: Optional[Any]) -> None:
        if found is None or not found.ddl:
            return
        cur.execute(
            "UPDATE monitored_table SET source_ddl=%s, source_indexes=%s::jsonb, "
            "source_col_count=%s, source_ddl_checked_at=now() WHERE id=%s",
            (found.ddl, json.dumps(found.indexes), found.column_count, tid),
        )

    def _lake_object(self, cur: Any, tid: int, found: Optional[Any]) -> None:
        if found is None:
            return
        cur.execute(
            "UPDATE monitored_table SET trino_object_type=%s, trino_object_ddl=%s, "
            "trino_object_checked_at=now() WHERE id=%s",
            (found.type.value, found.ddl or None, tid),
        )

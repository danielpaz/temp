"""RunHistory on PostgreSQL: when a run started and how it ended."""

from __future__ import annotations

from typing import Any, List, Optional, Sequence

from psycopg2.extras import execute_values

from app.adapters.outbound.postgres.connections import PostgresConnections
from app.adapters.outbound.postgres.result_store import table_id
from app.adapters.outbound.postgres.sql import key_match, key_params
from app.application.ports.registry import RunHistory
from app.domain.entities import MonitoredTable
from app.domain.run import RunState
from app.domain.values import Period, TableKey

ACTOR_LIMIT = 80


def requested_by(actor: Optional[str]) -> Optional[str]:
    return str(actor)[:ACTOR_LIMIT] if actor else None


def pending_rows(run_id: str, tables: Sequence[MonitoredTable]) -> List[tuple]:
    return [(run_id, table_id(t), "pending") for t in tables]


class PostgresRunHistory(RunHistory):
    def __init__(self, connections: PostgresConnections) -> None:
        self._connections = connections

    def started(
        self,
        run_id: str,
        period: Period,
        merge: bool,
        tables: Sequence[MonitoredTable],
        actor: Optional[str],
    ) -> None:
        with self._connections.transaction() as cur:
            cur.execute(
                "INSERT INTO run (run_id, status, full_run, period_from, "
                "period_to, requested_by, tables_total) "
                "VALUES (%s,'running',%s,%s,%s,%s,%s)",
                (
                    run_id,
                    not merge,
                    period.start,
                    period.end,
                    requested_by(actor),
                    len(tables),
                ),
            )
            execute_values(
                cur,
                "INSERT INTO run_table (run_id, table_id, state) VALUES %s",
                pending_rows(run_id, tables),
            )

    def finished(self, run_id: str, state: RunState) -> None:
        with self._connections.transaction() as cur:
            self._close_run(cur, run_id, state)
            for key, run in state.tables.items():
                self._close_table(cur, run_id, key, run)

    def _close_run(self, cur: Any, run_id: str, state: RunState) -> None:
        counts = state.counts
        cur.execute(
            "UPDATE run SET status=%s, finished_at=now(), message=%s, "
            "tables_total=%s, tables_done=%s, tables_error=%s WHERE run_id=%s",
            (
                state.status.value,
                state.message,
                counts.total,
                counts.done,
                counts.error,
                run_id,
            ),
        )

    def _close_table(self, cur: Any, run_id: str, key: str, run: Any) -> None:
        cur.execute(
            "UPDATE run_table SET state=%s, attempts=%s, error=%s "
            "WHERE run_id=%s AND table_id = "
            f"(SELECT id FROM monitored_table WHERE {key_match()})",
            (
                run.state.value,
                run.attempts,
                run.error or None,
                run_id,
                *key_params(TableKey.parse(key)),
            ),
        )

"""What an edit of a registered table writes: pure, so it needs no database."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Mapping, Optional, Set, Tuple

from app.domain.registry_rules import (
    COLUMN_FIELD,
    NAME_RULES,
    SECRET_FIELD,
    TableChanges,
    invalidated_by,
)

Edit = Tuple[str, Optional[str], Optional[str]]
OLD_COLUMNS = tuple(sorted(set(NAME_RULES) | {"trino_day_mode", "filter_kind"}))
ORIGIN_RESET = (
    "source_size_bytes=NULL",
    "source_size_checked_at=NULL",
    "source_ddl=NULL",
    "source_indexes=NULL",
    "source_col_count=NULL",
    "source_ddl_checked_at=NULL",
)
LAKE_OBJECT_RESET = (
    "trino_object_type=NULL",
    "trino_object_ddl=NULL",
    "trino_object_checked_at=NULL",
)


@dataclass
class UpdatePlan:
    values: Dict[str, object] = field(default_factory=dict)
    literals: List[str] = field(default_factory=list)
    edits: List[Edit] = field(default_factory=list)

    def change(self, name: str, old: object, new: object) -> None:
        """Assigns a column and records the edit under the same name."""
        self.values[name] = new
        self.log(name, old, new)

    def log(self, name: str, old: object, new: object) -> None:
        self.edits.append((name, _text(old), _text(new)))

    @property
    def changed(self) -> Set[str]:
        return {name for name, _, _ in self.edits}

    @property
    def has_sets(self) -> bool:
        return bool(self.values or self.literals)

    def set_clause(self) -> str:
        parts = [f"{column}=%s" for column in self.values] + self.literals
        return ", ".join(parts)


def _text(value: object) -> Optional[str]:
    return None if value is None else str(value)


def plan_update(
    old: Mapping,
    old_host: Optional[str],
    changes: TableChanges,
    resolve_host: Callable[[str], str],
) -> UpdatePlan:
    """`old` maps OLD_COLUMNS and "enabled" to the stored values."""
    plan = UpdatePlan()
    _plan_names(plan, old, old_host, changes.names, resolve_host)
    _plan_day_mode(plan, old, changes)
    _plan_filter_kind(plan, old, changes)
    _plan_invalidations(plan)
    _plan_enabled(plan, old, changes)
    return plan


def _plan_names(
    plan: UpdatePlan,
    old: Mapping,
    old_host: Optional[str],
    names: Mapping[str, Optional[str]],
    resolve_host: Callable[[str], str],
) -> None:
    for name in NAME_RULES:
        if name not in names or (names[name] or "") == (old[name] or ""):
            continue
        new = names[name]
        plan.change(name, old[name], new)
        if name == SECRET_FIELD:
            _plan_host(plan, old_host, resolve_host(new or ""))
        if name == COLUMN_FIELD:
            plan.values["has_date_field"] = new is not None


def _plan_host(plan: UpdatePlan, old_host: Optional[str], host: str) -> None:
    plan.values["used_host"] = host
    if host != old_host:
        plan.log("used_host", old_host, host)


def _plan_day_mode(plan: UpdatePlan, old: Mapping, changes: TableChanges) -> None:
    if changes.day_mode is None or changes.day_mode.value == old["trino_day_mode"]:
        return
    plan.change("trino_day_mode", old["trino_day_mode"], changes.day_mode.value)
    plan.literals.append("mode_source='manual'")


def _plan_filter_kind(plan: UpdatePlan, old: Mapping, changes: TableChanges) -> None:
    if changes.filter_kind is None or changes.filter_kind.value == old["filter_kind"]:
        return
    plan.change("filter_kind", old["filter_kind"], changes.filter_kind.value)


def _plan_invalidations(plan: UpdatePlan) -> None:
    stale = invalidated_by(plan.changed)
    if stale.origin_facts:
        plan.literals.extend(ORIGIN_RESET)
    if stale.lake_object:
        plan.literals.extend(LAKE_OBJECT_RESET)
    if stale.lake_column_type:
        plan.literals.append("trino_col_type=NULL")
    if stale.result_stale:
        plan.literals.append("config_changed_at=now()")


def _plan_enabled(plan: UpdatePlan, old: Mapping, changes: TableChanges) -> None:
    if changes.enabled is None or changes.enabled == old["enabled"]:
        return
    plan.values["enabled"] = changes.enabled
    plan.log("enabled", str(old["enabled"]).lower(), str(changes.enabled).lower())


def tag_diff(have: Set[str], wanted: List[str]) -> Tuple[List[str], List[str]]:
    """(to add, to drop), both sorted."""
    return sorted(set(wanted) - have), sorted(have - set(wanted))

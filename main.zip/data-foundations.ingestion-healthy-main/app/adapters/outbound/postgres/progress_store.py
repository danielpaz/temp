"""ProgressStore on the app database (run_plan, run_worker_progress, ...)."""

from __future__ import annotations

from typing import Optional, Set

from psycopg2.extras import Json

from app.adapters.outbound.postgres import progress_codec as codec
from app.adapters.outbound.postgres.connections import PostgresConnections
from app.application.ports.progress import ProgressStore
from app.domain.exceptions import NotFound
from app.domain.progress import RunPlan, WorkerProgress

RETENTION = "7 days"

INSERT_PLAN = (
    "INSERT INTO run_plan (run_id, body) VALUES (%s, %s) "
    "ON CONFLICT (run_id) DO UPDATE SET body = EXCLUDED.body"
)
PURGE_OLD = "DELETE FROM run_plan WHERE created_at < now() - interval '%s'" % RETENTION
SELECT_PLAN = "SELECT body FROM run_plan WHERE run_id = %s"
SELECT_WORKER = (
    "SELECT body FROM run_worker_progress WHERE run_id = %s AND worker_id = %s"
)
UPSERT_WORKER = (
    "INSERT INTO run_worker_progress (run_id, worker_id, body) VALUES (%s, %s, %s) "
    "ON CONFLICT (run_id, worker_id) DO UPDATE "
    "SET body = EXCLUDED.body, updated_at = now()"
)
INSERT_CANCEL = (
    "INSERT INTO run_cancel_request (run_id, table_key) VALUES (%s, %s) "
    "ON CONFLICT DO NOTHING"
)
SELECT_CANCEL = "SELECT table_key FROM run_cancel_request WHERE run_id = %s"


class PostgresProgressStore(ProgressStore):
    def __init__(self, connections: PostgresConnections) -> None:
        self._connections = connections

    def save_plan(self, plan: RunPlan) -> None:
        with self._connections.transaction() as cur:
            cur.execute(PURGE_OLD)
            cur.execute(INSERT_PLAN, (plan.run_id, Json(codec.plan_to(plan))))

    def load_plan(self, run_id: str) -> RunPlan:
        row = self._one(SELECT_PLAN, (run_id,))
        if row is None:
            raise NotFound(f"A execução {run_id} não tem plano.")
        return codec.plan_from(row["body"])

    def load_worker(self, run_id: str, worker_id: str) -> Optional[WorkerProgress]:
        row = self._one(SELECT_WORKER, (run_id, worker_id))
        return None if row is None else codec.worker_from(row["body"])

    def save_worker(self, run_id: str, progress: WorkerProgress) -> None:
        body = Json(codec.worker_to(progress))
        with self._connections.transaction() as cur:
            cur.execute(UPSERT_WORKER, (run_id, progress.worker_id, body))

    def request_cancel(self, run_id: str, keys: Set[str]) -> None:
        with self._connections.transaction() as cur:
            for key in sorted(keys):
                cur.execute(INSERT_CANCEL, (run_id, key))

    def cancelled(self, run_id: str) -> Set[str]:
        with self._connections.transaction() as cur:
            cur.execute(SELECT_CANCEL, (run_id,))
            return {row["table_key"] for row in cur.fetchall()}

    def _one(self, sql: str, args: tuple):
        with self._connections.transaction() as cur:
            cur.execute(sql, args)
            return cur.fetchone()

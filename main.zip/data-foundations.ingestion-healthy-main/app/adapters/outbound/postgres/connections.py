"""Connections to the app database (PostgreSQL, schema ingestion_healthy)."""

from __future__ import annotations

import contextlib
from typing import Any, Callable, Iterator, Optional

import psycopg2
from psycopg2.extras import RealDictCursor

from app.application.ports.secrets import ConnectionSecret, SecretsProvider

SCHEMA = "ingestion_healthy"
CONNECT_TIMEOUT = 10


class PostgresConnections:
    """Opens connections with the credentials of one secret, read once.
    Every `transaction` commits on success and rolls back on any error."""

    def __init__(
        self,
        secrets: SecretsProvider,
        secret_name: str,
        schema: str = SCHEMA,
        connect: Callable[..., Any] = psycopg2.connect,
    ) -> None:
        self._secrets = secrets
        self._secret_name = secret_name
        self._schema = schema
        self._connect = connect
        self._credentials: Optional[ConnectionSecret] = None

    def credentials(self) -> ConnectionSecret:
        if self._credentials is None:
            self._credentials = self._secrets.connection(self._secret_name)
        return self._credentials

    def connect_args(self) -> dict:
        secret = self.credentials()
        return {
            "host": secret.host,
            "port": secret.port,
            "user": secret.user,
            "password": secret.password,
            "dbname": secret.database,
            "connect_timeout": CONNECT_TIMEOUT,
            "options": f"-c search_path={self._schema}",
        }

    def open(self) -> Any:
        return self._connect(**self.connect_args())

    @contextlib.contextmanager
    def transaction(self) -> Iterator[Any]:
        conn = self.open()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                yield cur
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

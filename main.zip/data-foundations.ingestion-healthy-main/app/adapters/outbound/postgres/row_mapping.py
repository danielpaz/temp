"""Rows of the app database to read models: pure, so it needs no database."""

from __future__ import annotations

import json
from typing import Dict, List, Mapping, Optional

from app.application.read_models import (
    AuditEntry,
    OriginDefinitionSummary,
    SourceDefinitionView,
    TableOverview,
)
from app.domain.comparison import DayCount
from app.domain.registry_rules import KEY_FIELDS
from app.domain.values import (
    DayMode,
    FilterKind,
    ObjectType,
    Period,
    ResultStatus,
    TableKey,
)

DAY_MODES = ("sp", "utc")
NOT_COMPUTED = "Ainda não calculada."
DISABLED = "Tabela desativada."


def table_key(row: Mapping) -> TableKey:
    return TableKey(*(row[f] for f in KEY_FIELDS))


def _mode_changed(row: Mapping) -> bool:
    """The result was counted in a time zone other than the one configured."""
    result_mode = row["result_day_mode"]
    return (
        row["result_field"] is not None
        and row["filter_kind"] != "id"
        and result_mode in DAY_MODES
        and result_mode != row["trino_day_mode"]
    )


def _column_changed(row: Mapping) -> bool:
    result_field = row["result_field"]
    if result_field is None:
        return False
    return result_field.lower() != (row["date_field"] or "").lower()


def _kind_changed(row: Mapping) -> bool:
    result_mode = row["result_day_mode"]
    if result_mode in (None, "", "total"):
        return False
    return (result_mode == "id") != (row["filter_kind"] == "id")


def _edited_after(row: Mapping) -> bool:
    changed_at = row["config_changed_at"]
    return changed_at is not None and row["computed_at"] < changed_at


def is_config_pending(row: Mapping) -> bool:
    """The configuration changed after the stored result was computed."""
    if row["computed_at"] is None:
        return False
    return (
        _edited_after(row)
        or _column_changed(row)
        or _mode_changed(row)
        or _kind_changed(row)
    )


def _status_and_error(row: Mapping) -> tuple:
    if row["status"] is not None:
        return ResultStatus(row["status"]), row["error"] or ""
    return ResultStatus.ERROR, (NOT_COMPUTED if row["enabled"] else DISABLED)


def _period(row: Mapping) -> Optional[Period]:
    if not row["period_from"]:
        return None
    return Period(row["period_from"], row["period_to"])


def _definition(row: Mapping) -> OriginDefinitionSummary:
    known = bool(row["has_ddl"])
    return OriginDefinitionSummary(
        known=known,
        columns=row["col_count"],
        indexes=row["index_count"] if known else None,
        primary_key=row["pk_columns"] or [],
        filter_column_indexed=row["field_indexed"],
    )


def _object_type(row: Mapping) -> Optional[ObjectType]:
    return ObjectType(row["object_type"]) if row["object_type"] else None


def to_overview(row: Mapping, days: List[DayCount]) -> TableOverview:
    status, error = _status_and_error(row)
    return TableOverview(
        id=row["id"],
        key=table_key(row),
        host=row["host"] or "",
        secret=row["secret"] or "",
        filter_column=row["date_field"] or None,
        filter_kind=FilterKind(row["filter_kind"] or "date"),
        day_mode=DayMode(row["trino_day_mode"] or "sp"),
        day_mode_source=row["mode_source"] or None,
        enabled=bool(row["enabled"]),
        status=status,
        error=error,
        config_pending=is_config_pending(row),
        tags=list(row["tags"] or []),
        lake_column_type=row["trino_col_type"] or None,
        period=_period(row),
        origin_total=row["source_total"],
        lake_total=row["trino_total"],
        diff=row["diff"],
        computed_at=row["computed_at"],
        result_basis=row["result_day_mode"] or None,
        last_id=row["last_id"],
        object_type=_object_type(row),
        object_ddl=row["object_ddl"] or None,
        object_checked_at=row["object_checked_at"],
        origin_size_bytes=row["source_size_bytes"],
        origin_definition=_definition(row),
        days=days,
    )


def group_days(rows: List[Mapping]) -> Dict[int, List[DayCount]]:
    days: Dict[int, List[DayCount]] = {}
    for r in rows:
        count = DayCount(r["day"], r["source_count"], r["trino_count"])
        days.setdefault(r["table_id"], []).append(count)
    return days


def to_source_definition(row: Mapping) -> Optional[SourceDefinitionView]:
    if row["source_ddl"] is None:
        return None
    return SourceDefinitionView(
        table=row["source_name"],
        ddl=row["source_ddl"],
        indexes=row["source_indexes"] or [],
        columns=row["source_col_count"],
        checked_at=row["source_ddl_checked_at"],
        filter_column=row["date_field"],
    )


def deleted_table_name(old_value: Optional[str]) -> Optional[str]:
    """The key of a deleted table, from the snapshot its audit entry keeps."""
    try:
        return str(table_key(json.loads(old_value or "")))
    except (ValueError, KeyError, TypeError):
        return None


def _audit_table(row: Mapping) -> Optional[str]:
    if row["table_key"] or row["action"] != "delete" or not row["old_value"]:
        return row["table_key"]
    return deleted_table_name(row["old_value"])


def to_audit_entry(row: Mapping) -> AuditEntry:
    return AuditEntry(
        at=row["at"],
        actor=row["actor"],
        action=row["action"],
        field=row["field"],
        old=row["old_value"],
        new=row["new_value"],
        table=_audit_table(row),
    )

"""Pure JSON codec of what the supervisor and the workers share.

The keys of the progress file the old worker wrote (worker_id, host,
pod_attempt, state, updated, tables, partial) are kept; ``results`` replaces
the CSV-shaped ``summary`` and ``detail``.
"""

from __future__ import annotations

import datetime as dt
from typing import Any, Dict, List, Mapping, Optional, Set

from app.domain.comparison import (
    ComparisonResult,
    DayCount,
    LakeObject,
    OriginDefinition,
    TableFacts,
)
from app.domain.entities import MonitoredTable
from app.domain.progress import (
    Chunks,
    RunPlan,
    TableProgress,
    TableState,
    WorkerProgress,
)
from app.domain.values import (
    Basis,
    DayMode,
    FilterKind,
    ObjectType,
    Period,
    ResultStatus,
    TableKey,
)

Json = Dict[str, Any]


def _period_to(period: Period) -> List[str]:
    return period.iso()


def _period_from(data: List[str]) -> Period:
    return Period(dt.date.fromisoformat(data[0]), dt.date.fromisoformat(data[1]))


def key_to(key: TableKey) -> Json:
    return {
        "source_database": key.source_database,
        "source_schema": key.source_schema,
        "source_table": key.source_table,
        "target_catalog": key.target_catalog,
        "target_schema": key.target_schema,
        "target_table": key.target_table,
    }


def key_from(data: Mapping) -> TableKey:
    return TableKey(**{k: data[k] for k in key_to_fields()})


def key_to_fields() -> List[str]:
    return [
        "source_database",
        "source_schema",
        "source_table",
        "target_catalog",
        "target_schema",
        "target_table",
    ]


def table_to(table: MonitoredTable) -> Json:
    return {
        "key": key_to(table.key),
        "secret": table.secret,
        "host": table.host,
        "filter_column": table.filter_column,
        "filter_kind": table.filter_kind.value,
        "day_mode": table.day_mode.value,
        "enabled": table.enabled,
        "id": table.id,
    }


def table_from(data: Mapping) -> MonitoredTable:
    return MonitoredTable(
        key=key_from(data["key"]),
        secret=data["secret"],
        host=data["host"],
        filter_column=data.get("filter_column"),
        filter_kind=FilterKind(data.get("filter_kind", "date")),
        day_mode=DayMode(data.get("day_mode", "sp")),
        enabled=bool(data.get("enabled", True)),
        id=data.get("id"),
    )


def plan_to(plan: RunPlan) -> Json:
    return {
        "run_id": plan.run_id,
        "period": _period_to(plan.period),
        "merge": plan.merge,
        "tables": [table_to(t) for t in plan.tables],
    }


def plan_from(data: Mapping) -> RunPlan:
    return RunPlan(
        run_id=data["run_id"],
        period=_period_from(data["period"]),
        tables=[table_from(t) for t in data.get("tables", [])],
        merge=bool(data.get("merge", False)),
    )


def _lake_object_to(obj: Optional[LakeObject]) -> Optional[Json]:
    return None if obj is None else {"type": obj.type.value, "ddl": obj.ddl}


def _lake_object_from(data: Optional[Mapping]) -> Optional[LakeObject]:
    if data is None:
        return None
    return LakeObject(ObjectType(data["type"]), data.get("ddl"))


def _definition_to(definition: Optional[OriginDefinition]) -> Optional[Json]:
    if definition is None:
        return None
    return {
        "ddl": definition.ddl,
        "indexes": definition.indexes,
        "column_count": definition.column_count,
    }


def _definition_from(data: Optional[Mapping]) -> Optional[OriginDefinition]:
    if data is None:
        return None
    return OriginDefinition(
        data["ddl"], list(data.get("indexes") or []), data["column_count"]
    )


def facts_to(facts: TableFacts) -> Json:
    return {
        "lake_object": _lake_object_to(facts.lake_object),
        "lake_column_type": facts.lake_column_type,
        "origin_size_bytes": facts.origin_size_bytes,
        "origin_definition": _definition_to(facts.origin_definition),
        "origin_read": facts.origin_read,
    }


def facts_from(data: Mapping) -> TableFacts:
    return TableFacts(
        lake_object=_lake_object_from(data.get("lake_object")),
        lake_column_type=data.get("lake_column_type"),
        origin_size_bytes=data.get("origin_size_bytes"),
        origin_definition=_definition_from(data.get("origin_definition")),
        origin_read=bool(data.get("origin_read", False)),
    )


def _day_to(day: DayCount) -> Json:
    return {"day": day.day.isoformat(), "origin": day.origin, "lake": day.lake}


def _day_from(data: Mapping) -> DayCount:
    return DayCount(dt.date.fromisoformat(data["day"]), data["origin"], data["lake"])


def result_to(result: ComparisonResult) -> Json:
    return {
        "key": key_to(result.key),
        "status": result.status.value,
        "period": _period_to(result.period),
        "basis": result.basis.value if result.basis else None,
        "filter_column": result.filter_column,
        "days": [_day_to(d) for d in result.days],
        "origin_total": result.origin_total,
        "lake_total": result.lake_total,
        "last_id": result.last_id,
        "error": result.error,
        "facts": facts_to(result.facts),
    }


def result_from(data: Mapping) -> ComparisonResult:
    basis = data.get("basis")
    return ComparisonResult(
        key=key_from(data["key"]),
        status=ResultStatus(data["status"]),
        period=_period_from(data["period"]),
        basis=Basis(basis) if basis else None,
        filter_column=data.get("filter_column"),
        days=[_day_from(d) for d in data.get("days", [])],
        origin_total=data.get("origin_total"),
        lake_total=data.get("lake_total"),
        last_id=data.get("last_id"),
        error=data.get("error"),
        facts=facts_from(data.get("facts") or {}),
    )


def _progress_to(progress: TableProgress) -> Json:
    out: Json = {
        "state": progress.state.value,
        "attempts": progress.attempts,
        "error": progress.error,
    }
    if progress.chunks:
        out["chunks"] = {"done": progress.chunks.done, "total": progress.chunks.total}
    return out


def _progress_from(data: Mapping) -> TableProgress:
    chunks = data.get("chunks")
    return TableProgress(
        state=TableState(data.get("state", "pending")),
        attempts=data.get("attempts", 0),
        error=data.get("error", ""),
        chunks=Chunks(chunks["done"], chunks["total"]) if chunks else None,
    )


def worker_to(progress: WorkerProgress) -> Json:
    return {
        "worker_id": progress.worker_id,
        "host": progress.host,
        "pod_attempt": progress.pod_attempt,
        "state": progress.state,
        "updated": progress.updated,
        "tables": {k: _progress_to(t) for k, t in progress.tables.items()},
        "results": {k: result_to(r) for k, r in progress.results.items()},
        "partial": progress.partial,
    }


def worker_from(data: Mapping) -> WorkerProgress:
    return WorkerProgress(
        worker_id=data["worker_id"],
        host=data.get("host", ""),
        pod_attempt=data.get("pod_attempt", ""),
        state=data.get("state", "running"),
        updated=data.get("updated", 0.0),
        tables={k: _progress_from(t) for k, t in (data.get("tables") or {}).items()},
        results={k: result_from(r) for k, r in (data.get("results") or {}).items()},
        partial=dict(data.get("partial") or {}),
    )


def cancel_to(keys: Set[str]) -> List[str]:
    return sorted(keys)


def cancel_from(data: List[str]) -> Set[str]:
    return set(data)

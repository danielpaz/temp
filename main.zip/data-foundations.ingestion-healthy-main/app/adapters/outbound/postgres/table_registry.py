"""TableRegistry on PostgreSQL: registers, edits and removes monitored tables."""

from __future__ import annotations

import json
from typing import Any, Callable, List, Optional, Set

import psycopg2.errors

from app.adapters.outbound.postgres.connections import PostgresConnections
from app.adapters.outbound.postgres.row_mapping import table_key
from app.adapters.outbound.postgres.sql import key_match, key_params
from app.adapters.outbound.postgres.update_plan import (
    OLD_COLUMNS,
    UpdatePlan,
    plan_update,
    tag_diff,
)
from app.application.ports.registry import TableRegistry
from app.domain.entities import MonitoredTable
from app.domain.exceptions import Duplicate, NotFound
from app.domain.registry_rules import (
    KEY_FIELDS,
    NewTable,
    TableChanges,
    normalize_actor,
)
from app.domain.values import DayMode, FilterKind, TableKey

DUPLICATE = "Já existe uma linha com essa origem e essa tabela do Trino."
UNKNOWN = "Tabela desconhecida."
SNAPSHOT_COLUMNS = (
    "id, source_database, source_schema, source_table, source_host, used_host, "
    "used_secret, target_catalog, target_schema, target_table, date_field, "
    "trino_col_type, trino_day_mode, mode_source, enabled"
)


class PostgresTableRegistry(TableRegistry):
    def __init__(self, connections: PostgresConnections) -> None:
        self._connections = connections

    def active_tables(self) -> List[MonitoredTable]:
        with self._connections.transaction() as cur:
            cur.execute(
                "SELECT id, " + ", ".join(KEY_FIELDS) + ", used_secret, used_host, "
                "source_host, date_field, filter_kind, trino_day_mode "
                "FROM monitored_table WHERE enabled ORDER BY id"
            )
            return [_to_table(row) for row in cur.fetchall()]

    def create(self, new: NewTable, host: str, actor: str) -> int:
        actor = normalize_actor(actor)
        with self._connections.transaction() as cur:
            table_id = self._insert(cur, new, host, actor)
            self._add_tags(cur, table_id, new.tags, actor)
            _audit(cur, actor, "create", table_id, "table", None, str(new.key))
        return table_id

    def update(
        self,
        key: TableKey,
        changes: TableChanges,
        resolve_host: Callable[[str], str],
        actor: str,
    ) -> List[str]:
        actor = normalize_actor(actor)
        with self._connections.transaction() as cur:
            row = self._lock(cur, key)
            plan = plan_update(row, row["used_host"], changes, resolve_host)
            for edit in plan.edits:
                _audit(cur, actor, "edit", row["id"], *edit)
            tags = self._apply_tags(cur, row["id"], changes.tags, actor)
            self._apply(cur, row["id"], plan, actor)
        return [name for name, _, _ in plan.edits] + tags

    def delete(self, key: TableKey, actor: str) -> None:
        actor = normalize_actor(actor)
        with self._connections.transaction() as cur:
            snapshot = self._snapshot(cur, key)
            old = json.dumps(snapshot, default=str)
            _audit(cur, actor, "delete", snapshot["id"], "table", old, None)
            cur.execute("DELETE FROM monitored_table WHERE id=%s", (snapshot["id"],))

    def _insert(self, cur: Any, new: NewTable, host: str, actor: str) -> int:
        key = new.key
        try:
            cur.execute(
                "INSERT INTO monitored_table (source_database, source_schema, "
                "source_table, source_host, used_host, used_secret, "
                "target_catalog, target_schema, target_table, has_date_field, "
                "date_field, filter_kind, updated_by, config_changed_at) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NULL) RETURNING id",
                (
                    *key_params(key)[:3],
                    host,
                    host,
                    new.secret,
                    *key_params(key)[3:],
                    new.filter_column is not None,
                    new.filter_column,
                    new.filter_kind.value,
                    actor,
                ),
            )
        except psycopg2.errors.UniqueViolation as error:
            raise Duplicate(DUPLICATE) from error
        return int(cur.fetchone()["id"])

    def _lock(self, cur: Any, key: TableKey) -> dict:
        cur.execute(
            "SELECT id, used_host, enabled, " + ", ".join(OLD_COLUMNS) + " "
            f"FROM monitored_table WHERE {key_match()} FOR UPDATE",
            key_params(key),
        )
        row = cur.fetchone()
        if not row:
            raise NotFound(UNKNOWN)
        return dict(row)

    def _snapshot(self, cur: Any, key: TableKey) -> dict:
        cur.execute(
            f"SELECT {SNAPSHOT_COLUMNS} FROM monitored_table "
            f"WHERE {key_match()} FOR UPDATE",
            key_params(key),
        )
        row = cur.fetchone()
        if not row:
            raise NotFound(UNKNOWN)
        snapshot = dict(row)
        cur.execute(
            "SELECT tag FROM table_tag WHERE table_id=%s ORDER BY tag",
            (snapshot["id"],),
        )
        snapshot["tags"] = [r["tag"] for r in cur.fetchall()]
        return snapshot

    def _apply_tags(
        self, cur: Any, table_id: int, wanted: Optional[List[str]], actor: str
    ) -> List[str]:
        if wanted is None:
            return []
        cur.execute("SELECT tag FROM table_tag WHERE table_id=%s", (table_id,))
        have: Set[str] = {r["tag"] for r in cur.fetchall()}
        add, drop = tag_diff(have, wanted)
        for tag in drop:
            cur.execute(
                "DELETE FROM table_tag WHERE table_id=%s AND tag=%s", (table_id, tag)
            )
        self._add_tags(cur, table_id, add, actor)
        if not (add or drop):
            return []
        old, new = ",".join(sorted(have)), ",".join(wanted)
        _audit(cur, actor, "edit", table_id, "tags", old, new)
        return ["tags"]

    def _add_tags(self, cur: Any, table_id: int, tags: List[str], actor: str) -> None:
        for tag in tags:
            cur.execute(
                "INSERT INTO table_tag (table_id, tag, created_by) VALUES (%s,%s,%s)",
                (table_id, tag, actor),
            )

    def _apply(self, cur: Any, table_id: int, plan: UpdatePlan, actor: str) -> None:
        if not plan.has_sets:
            return
        try:
            cur.execute(
                f"UPDATE monitored_table SET {plan.set_clause()}, updated_by=%s "
                "WHERE id=%s",
                [*plan.values.values(), actor, table_id],
            )
        except psycopg2.errors.UniqueViolation as error:
            raise Duplicate(DUPLICATE) from error


def _audit(
    cur: Any,
    actor: str,
    action: str,
    table_id: int,
    field: str,
    old: Optional[str],
    new: Optional[str],
) -> None:
    cur.execute(
        "INSERT INTO audit_log (actor, action, table_id, field, old_value, "
        "new_value) VALUES (%s,%s,%s,%s,%s,%s)",
        (actor, action, table_id, field, old, new),
    )


def _to_table(row: dict) -> MonitoredTable:
    return MonitoredTable(
        key=table_key(row),
        secret=row["used_secret"] or "",
        host=row["used_host"] or row["source_host"] or "",
        filter_column=row["date_field"] or None,
        filter_kind=FilterKind(row["filter_kind"] or "date"),
        day_mode=DayMode(row["trino_day_mode"] or "sp"),
        enabled=True,
        id=row["id"],
    )

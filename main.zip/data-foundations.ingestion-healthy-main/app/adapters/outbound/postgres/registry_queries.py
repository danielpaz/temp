"""RegistryQueries on PostgreSQL: what the screens read."""

from __future__ import annotations

from typing import Any, List, Optional

from app.adapters.outbound.postgres.connections import PostgresConnections
from app.adapters.outbound.postgres.row_mapping import (
    group_days,
    to_audit_entry,
    to_overview,
    to_source_definition,
)
from app.adapters.outbound.postgres.sql import key_match, key_params, key_text
from app.application.ports.registry import RegistryQueries
from app.application.read_models import (
    AuditEntry,
    SourceDefinitionView,
    TableOverview,
    TagCount,
)
from app.domain.exceptions import NotFound
from app.domain.values import TableKey

MAX_AUDIT = 50
INDEXES = "coalesce(t.source_indexes, '[]'::jsonb)"

VERSION_SQL = """
SELECT
  (SELECT max(computed_at) FROM table_result) AS a,
  (SELECT count(*) FROM table_result) AS b,
  (SELECT max(updated_at) FROM monitored_table) AS c,
  (SELECT count(*) FROM monitored_table) AS d,
  (SELECT count(*) FROM table_tag) AS e,
  (SELECT max(id) FROM audit_log) AS f
"""

OVERVIEW_SQL = f"""
SELECT t.id, t.source_database, t.source_schema, t.source_table,
  t.target_catalog, t.target_schema, t.target_table,
  t.used_host AS host, t.used_secret AS secret, t.date_field,
  t.trino_col_type, t.trino_day_mode, t.mode_source, t.enabled,
  t.config_changed_at, t.trino_object_type AS object_type,
  t.trino_object_ddl AS object_ddl,
  t.trino_object_checked_at AS object_checked_at,
  t.source_size_bytes, t.filter_kind, r.last_id,
  t.source_ddl IS NOT NULL AS has_ddl,
  t.source_col_count AS col_count,
  jsonb_array_length({INDEXES}) AS index_count,
  (SELECT e->'columns' FROM jsonb_array_elements({INDEXES}) e
    WHERE (e->>'primary')::boolean LIMIT 1) AS pk_columns,
  CASE WHEN t.source_ddl IS NULL OR t.date_field IS NULL THEN NULL
    ELSE EXISTS (SELECT 1 FROM jsonb_array_elements({INDEXES}) e
      WHERE lower(e->'columns'->>0) = lower(t.date_field)) END
    AS field_indexed,
  r.status, r.period_from, r.period_to, r.date_field AS result_field,
  r.day_mode AS result_day_mode, r.source_total, r.trino_total, r.diff,
  r.error, r.computed_at,
  coalesce((SELECT array_agg(g.tag ORDER BY g.tag) FROM table_tag g
    WHERE g.table_id = t.id), '{{}}') AS tags
FROM monitored_table t LEFT JOIN table_result r ON r.table_id = t.id
ORDER BY t.id
"""

DAYS_SQL = (
    "SELECT table_id, day, source_count, trino_count FROM table_result_day "
    "ORDER BY table_id, day"
)

AUDIT_COLUMNS = (
    "SELECT a.at, a.actor, a.action, a.field, a.old_value, a.new_value, "
    f"{key_text('t')} AS table_key FROM audit_log a "
)


class PostgresRegistryQueries(RegistryQueries):
    def __init__(self, connections: PostgresConnections) -> None:
        self._connections = connections

    def overview(self) -> List[TableOverview]:
        with self._connections.transaction() as cur:
            cur.execute(OVERVIEW_SQL)
            rows = cur.fetchall()
            cur.execute(DAYS_SQL)
            days = group_days(cur.fetchall())
        return [to_overview(row, days.get(row["id"], [])) for row in rows]

    def version(self) -> tuple:
        with self._connections.transaction() as cur:
            cur.execute(VERSION_SQL)
            return tuple(str(x) for x in cur.fetchone().values())

    def known_tags(self) -> List[TagCount]:
        with self._connections.transaction() as cur:
            cur.execute(
                "SELECT tag, count(*) AS tables FROM table_tag "
                "GROUP BY tag ORDER BY tag"
            )
            return [TagCount(r["tag"], r["tables"]) for r in cur.fetchall()]

    def audit(self, key: Optional[TableKey], limit: int) -> List[AuditEntry]:
        limit = max(1, min(int(limit), MAX_AUDIT))
        with self._connections.transaction() as cur:
            self._run_audit(cur, key, limit)
            return [to_audit_entry(row) for row in cur.fetchall()]

    def source_definition(self, key: TableKey) -> Optional[SourceDefinitionView]:
        with self._connections.transaction() as cur:
            cur.execute(
                "SELECT source_ddl, source_indexes, source_col_count, "
                "source_ddl_checked_at, date_field, "
                "source_database||'.'||source_schema||'.'||source_table "
                f"AS source_name FROM monitored_table WHERE {key_match()}",
                key_params(key),
            )
            row = cur.fetchone()
        if not row:
            raise NotFound("Tabela desconhecida.")
        return to_source_definition(row)

    def _run_audit(self, cur: Any, key: Optional[TableKey], limit: int) -> None:
        if key is None:
            cur.execute(
                AUDIT_COLUMNS + "LEFT JOIN monitored_table t ON t.id = a.table_id "
                "ORDER BY a.id DESC LIMIT %s",
                (limit,),
            )
            return
        cur.execute(
            AUDIT_COLUMNS + "JOIN monitored_table t ON t.id = a.table_id "
            f"WHERE {key_match('t')} ORDER BY a.id DESC LIMIT %s",
            (*key_params(key), limit),
        )

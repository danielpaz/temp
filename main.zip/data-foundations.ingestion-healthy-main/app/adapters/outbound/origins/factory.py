"""Chooses the origin reader of an engine. A new engine is a new entry in the
registry, not an edit of the existing readers."""

from __future__ import annotations

from dataclasses import replace
from typing import Callable, Mapping, Optional

from app.adapters.outbound.origins.base import OriginSettings
from app.adapters.outbound.origins.postgres import PostgresOrigin
from app.adapters.outbound.origins.sqlserver import SqlServerOrigin
from app.application.ports.origin import OriginReader, OriginReaderFactory
from app.application.ports.secrets import ConnectionSecret, SecretsProvider
from app.domain.engines import Engine
from app.domain.exceptions import PermanentError

OriginBuilder = Callable[[ConnectionSecret, OriginSettings], OriginReader]

DEFAULT_BUILDERS: Mapping[Engine, OriginBuilder] = {
    Engine.POSTGRESQL: PostgresOrigin,
    Engine.SQLSERVER: SqlServerOrigin,
}


class RegistryOriginReaderFactory(OriginReaderFactory):
    def __init__(
        self,
        secrets: SecretsProvider,
        settings: Optional[OriginSettings] = None,
        builders: Mapping[Engine, OriginBuilder] = DEFAULT_BUILDERS,
    ) -> None:
        self._secrets = secrets
        self._settings = settings or OriginSettings()
        self._builders = builders

    def open(self, secret: str, host: str) -> OriginReader:
        connection = self._secrets.connection(secret)
        if host:
            connection = replace(connection, host=host)
        builder = self._builders.get(connection.engine)
        if builder is None:
            raise PermanentError(f"unsupported engine: {connection.engine}")
        return builder(connection, self._settings)

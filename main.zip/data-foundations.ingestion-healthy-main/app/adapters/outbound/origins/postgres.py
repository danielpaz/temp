"""PostgreSQL origin."""

from __future__ import annotations

import datetime as dt
from typing import Any, Optional

import psycopg2

from app.adapters.outbound.origins import ddl, sql
from app.adapters.outbound.origins.base import SqlOrigin
from app.application.ports.origin import OriginTable
from app.domain.comparison import OriginDefinition


class PostgresOrigin(SqlOrigin):
    def _connect(self, timeout: int) -> Any:
        s = self._secret
        conn = psycopg2.connect(
            host=s.host,
            port=int(s.port),
            user=s.user,
            password=s.password,
            dbname=s.database,
            connect_timeout=self._settings.connect_timeout,
        )
        conn.autocommit = True
        with conn.cursor() as cursor:
            if s.init_statement:
                cursor.execute(s.init_statement)
            cursor.execute(f"SET statement_timeout = '{int(timeout)}s'")
            cursor.execute("SET default_transaction_read_only = on")
        return conn

    def _set_timeout(self, seconds: int) -> None:
        self._execute(f"SET statement_timeout = '{int(seconds)}s'")

    def _execute(self, statement: str) -> None:
        with self._ensure().cursor() as cursor:
            cursor.execute(statement)

    def _catalog_sql(self) -> str:
        return sql.PG_CATALOG

    def _stats_query(self, table: OriginTable, column: str) -> sql.Query:
        return sql.PG_STATS, (column, table.schema, table.table)

    def _size_query(self, table: OriginTable) -> sql.Query:
        return sql.PG_SIZE, (table.schema, table.table)

    def _read_definition(self, table: OriginTable) -> OriginDefinition:
        args = (table.schema, table.table)
        columns = self._rows(sql.PG_COLUMNS, args)
        constraints = self._rows(sql.PG_CONSTRAINTS, args)
        indexes = ddl.pg_indexes(self._rows(sql.PG_INDEXES, args))
        text = ddl.pg_definition(table.schema, table.table, columns, constraints)
        return OriginDefinition(text, indexes, len(columns))

    def _day_query(
        self, table: OriginTable, column: str, start: dt.date, end: dt.date
    ) -> sql.Query:
        return sql.pg_day_query(table.schema, table.table, column, start, end)

    def _count_query(
        self, table: OriginTable, id_column: Optional[str], up_to: Optional[int]
    ) -> sql.Query:
        return sql.pg_count_query(table.schema, table.table, id_column, up_to)

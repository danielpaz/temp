"""What PostgreSQL and SQL Server origins share: a lazy connection, the catalog,
the table lookup and the translation of driver errors."""

from __future__ import annotations

import datetime as dt
from abc import abstractmethod
from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from app.adapters.outbound.origins.sql import Query, is_timeout
from app.application.ports.origin import OriginReader, OriginStats, OriginTable
from app.application.ports.secrets import ConnectionSecret
from app.domain.comparison import OriginDefinition
from app.domain.exceptions import (
    DomainError,
    OriginError,
    PermanentError,
    WindowTimeout,
    describe,
)

Catalog = Dict[Tuple[str, str], OriginTable]


@dataclass(frozen=True)
class OriginSettings:
    query_timeout: int = 180
    connect_timeout: int = 15


class SqlOrigin(OriginReader):
    """Template: subclasses give the engine's driver and SQL."""

    def __init__(self, secret: ConnectionSecret, settings: OriginSettings) -> None:
        self._secret = secret
        self._settings = settings
        self._timeout = settings.query_timeout
        self._conn: Any = None
        self._catalog: Optional[Catalog] = None

    # engine hooks
    @abstractmethod
    def _connect(self, timeout: int) -> Any:
        """Engine hook."""

    @abstractmethod
    def _set_timeout(self, seconds: int) -> None:
        """Engine hook."""

    @abstractmethod
    def _catalog_sql(self) -> str:
        """Engine hook."""

    @abstractmethod
    def _stats_query(self, table: OriginTable, column: str) -> Query:
        """Engine hook."""

    @abstractmethod
    def _size_query(self, table: OriginTable) -> Query:
        """Engine hook."""

    @abstractmethod
    def _read_definition(self, table: OriginTable) -> OriginDefinition:
        """Engine hook."""

    @abstractmethod
    def _day_query(
        self, table: OriginTable, column: str, start: dt.date, end: dt.date
    ) -> Query:
        """Engine hook."""

    @abstractmethod
    def _count_query(
        self, table: OriginTable, id_column: Optional[str], up_to: Optional[int]
    ) -> Query:
        """Engine hook."""

    def _after_timeout(self) -> None:
        """A connection that timed out may be unusable; the default keeps it."""

    # connection
    def _ensure(self) -> Any:
        if self._conn is None:
            try:
                self._conn = self._connect(self._timeout)
            except Exception as error:
                raise OriginError(f"origin connection failed: {describe(error)}")
        return self._conn

    def close(self) -> None:
        try:
            if self._conn is not None:
                self._conn.close()
        except Exception:
            pass
        self._conn = None

    def _rows(self, sql: str, params: tuple = ()) -> List[tuple]:
        cursor = self._ensure().cursor()
        try:
            cursor.execute(sql, params or None)
            return list(cursor.fetchall())
        finally:
            cursor.close()

    def _recover(self) -> None:
        try:
            self._conn.rollback()
        except Exception:
            pass

    # catalog
    def _tables(self) -> Catalog:
        if self._catalog is None:
            columns: Dict[Tuple[str, str], List[Tuple[str, str]]] = defaultdict(list)
            for schema, table, name, kind in self._rows(self._catalog_sql()):
                columns[(schema, table)].append((name, kind))
            self._catalog = {
                (s.lower(), t.lower()): OriginTable(s, t, tuple(cols))
                for (s, t), cols in columns.items()
            }
        return self._catalog

    def find_table(self, schema: str, table: str) -> Optional[OriginTable]:
        tables = self._tables()
        found = tables.get((schema.lower(), table.lower()))
        if found is not None:
            return found
        same_name = [t for (_, name), t in tables.items() if name == table.lower()]
        return same_name[0] if len(same_name) == 1 else None

    # best-effort reads
    def stats(self, table: OriginTable, column: str) -> OriginStats:
        try:
            rows, leading = self._rows(*self._stats_query(table, column))[0]
            return OriginStats(max(int(rows or 0), 0), bool(leading))
        except Exception:
            self._recover()
            return OriginStats(0, False)

    def size_bytes(self, table: OriginTable) -> Optional[int]:
        try:
            size = self._rows(*self._size_query(table))[0][0]
            return int(size) if size is not None else None
        except Exception:
            self._recover()
            return None

    def definition(self, table: OriginTable) -> Optional[OriginDefinition]:
        try:
            return self._read_definition(table)
        except Exception:
            self._recover()
            return None

    # counts
    def count_by_day(
        self,
        table: OriginTable,
        column: str,
        start: dt.date,
        end_exclusive: dt.date,
        timeout_seconds: int,
    ) -> Dict[dt.date, int]:
        try:
            self._set_timeout(timeout_seconds)
            query = self._day_query(table, column, start, end_exclusive)
            return {day: int(n) for day, n in self._rows(*query)}
        except Exception as error:
            raise self._window_error(error, start, end_exclusive, timeout_seconds)

    def count_rows(
        self,
        table: OriginTable,
        id_column: Optional[str] = None,
        up_to: Optional[int] = None,
    ) -> int:
        try:
            self._set_timeout(self._settings.query_timeout)
            query = self._count_query(table, id_column, up_to)
            return int(self._rows(*query)[0][0])
        except Exception as error:
            raise self._count_error(error)

    def _window_error(
        self, error: Exception, start: dt.date, end: dt.date, timeout: int
    ) -> DomainError:
        if isinstance(error, DomainError):
            return error
        message = describe(error)
        if is_timeout(message):
            self._after_timeout()
            return WindowTimeout(
                f"origin query failed: tempo limite da consulta excedido "
                f"({timeout}s) em {start}..{end}. {message}"[:700]
            )
        return OriginError(f"origin query failed: {message}")

    def _count_error(self, error: Exception) -> DomainError:
        if isinstance(error, DomainError):
            return error
        message = describe(error)
        if is_timeout(message):
            self._after_timeout()
            return PermanentError(
                f"origin query failed: tempo limite da consulta excedido "
                f"({self._settings.query_timeout}s) ao contar a tabela. {message}"[:700]
            )
        return OriginError(f"origin query failed: {message}")

"""SQL of the origin catalogs and queries. Pure: strings and parameters, no I/O."""

from __future__ import annotations

import datetime as dt
from typing import Optional, Tuple

Query = Tuple[str, tuple]


def pg_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def ms_ident(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


def ms_object(schema: str, table: str) -> str:
    return f"{ms_ident(schema)}.{ms_ident(table)}"


def is_timeout(message: str) -> bool:
    return "statement timeout" in message or "timed out" in message.lower()


PG_CATALOG = (
    "SELECT n.nspname, c.relname, a.attname, "
    "pg_catalog.format_type(a.atttypid, NULL) "
    "FROM pg_catalog.pg_attribute a JOIN pg_catalog.pg_class c ON c.oid = a.attrelid "
    "JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace "
    "WHERE c.relkind IN ('r','p','v','m','f') AND a.attnum > 0 "
    "AND NOT a.attisdropped "
    "AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast') "
    "ORDER BY a.attnum"
)
MS_CATALOG = (
    "SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, DATA_TYPE "
    "FROM INFORMATION_SCHEMA.COLUMNS "
    "WHERE TABLE_SCHEMA NOT IN ('INFORMATION_SCHEMA','sys') ORDER BY ORDINAL_POSITION"
)

PG_STATS = """SELECT c.reltuples::bigint,
  EXISTS (SELECT 1 FROM pg_index i JOIN pg_attribute a
            ON a.attrelid = i.indrelid AND a.attnum = i.indkey[0]
          WHERE i.indrelid = c.oid AND i.indisvalid AND a.attname = %s)
FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = %s AND c.relname = %s"""
MS_STATS = """SELECT (SELECT SUM(p.rows) FROM sys.partitions p
    WHERE p.object_id = OBJECT_ID(%s) AND p.index_id IN (0, 1)),
  CASE WHEN EXISTS (SELECT 1 FROM sys.index_columns ic JOIN sys.columns c
                      ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                    WHERE ic.object_id = OBJECT_ID(%s) AND ic.key_ordinal = 1
                      AND c.name = %s) THEN 1 ELSE 0 END"""

# Raw data, indexes left out: heap + TOAST for PostgreSQL (every partition when
# partitioned); pages of the heap or clustered index for SQL Server.
PG_SIZE = """WITH r AS (
  SELECT (quote_ident(%s) || '.' || quote_ident(%s))::regclass AS oid)
SELECT COALESCE((SELECT SUM(pg_table_size(relid))
                 FROM pg_partition_tree((SELECT oid FROM r)) WHERE isleaf),
                pg_table_size((SELECT oid FROM r)))::bigint"""
MS_SIZE = """SELECT SUM(a.used_pages) * 8192 FROM sys.partitions p
JOIN sys.allocation_units a ON (a.type IN (1, 3) AND a.container_id = p.hobt_id)
  OR (a.type = 2 AND a.container_id = p.partition_id)
WHERE p.object_id = OBJECT_ID(%s) AND p.index_id IN (0, 1)"""

PG_COLUMNS = """SELECT a.attname, format_type(a.atttypid, a.atttypmod), a.attnotnull,
  pg_get_expr(d.adbin, d.adrelid), a.attidentity, a.attgenerated
FROM pg_attribute a LEFT JOIN pg_attrdef d
  ON d.adrelid = a.attrelid AND d.adnum = a.attnum
WHERE a.attrelid = (quote_ident(%s) || '.' || quote_ident(%s))::regclass
  AND a.attnum > 0 AND NOT a.attisdropped ORDER BY a.attnum"""
PG_CONSTRAINTS = """SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint
WHERE conrelid = (quote_ident(%s) || '.' || quote_ident(%s))::regclass
  AND contype IN ('p', 'u', 'c', 'f')
ORDER BY CASE contype WHEN 'p' THEN 0 WHEN 'u' THEN 1 WHEN 'f' THEN 2 ELSE 3 END,
  conname"""
PG_INDEXES = """SELECT c.relname, x.indisprimary, x.indisunique,
  pg_get_indexdef(x.indexrelid),
  (SELECT array_agg(pg_get_indexdef(x.indexrelid, k + 1, true) ORDER BY k)
   FROM generate_series(0, x.indnkeyatts - 1) k),
  (SELECT array_agg(pg_get_indexdef(x.indexrelid, k + 1, true) ORDER BY k)
   FROM generate_series(x.indnkeyatts, x.indnatts - 1) k),
  pg_get_expr(x.indpred, x.indrelid)
FROM pg_index x JOIN pg_class c ON c.oid = x.indexrelid
WHERE x.indrelid = (quote_ident(%s) || '.' || quote_ident(%s))::regclass
  AND x.indisvalid
ORDER BY x.indisprimary DESC, x.indisunique DESC, c.relname"""
# seed_value and increment_value are sql_variant: they need the cast to be read.
MS_COLUMNS = """SELECT c.name, TYPE_NAME(c.user_type_id), c.max_length, c.precision,
  c.scale, c.is_nullable, c.is_identity, CAST(ic.seed_value AS bigint),
  CAST(ic.increment_value AS bigint), dc.definition, cc.definition
FROM sys.columns c
LEFT JOIN sys.default_constraints dc
  ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
LEFT JOIN sys.computed_columns cc
  ON cc.object_id = c.object_id AND cc.column_id = c.column_id
LEFT JOIN sys.identity_columns ic
  ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE c.object_id = OBJECT_ID(%s) ORDER BY c.column_id"""
MS_INDEXES = """SELECT i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key,
  i.filter_definition, c.name, ic.is_included_column, ic.is_descending_key
FROM sys.indexes i JOIN sys.index_columns ic
  ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(%s) AND i.index_id > 0
ORDER BY i.is_primary_key DESC, i.index_id, ic.is_included_column, ic.key_ordinal"""


def pg_day_query(
    schema: str, table: str, column: str, start: dt.date, end: dt.date
) -> Query:
    c = pg_ident(column)
    sql = (
        f"SELECT ({c})::date, count(*) FROM {pg_ident(schema)}.{pg_ident(table)} "
        f"WHERE {c} >= %s AND {c} < %s GROUP BY 1"
    )
    return sql, (start.isoformat(), end.isoformat())


def ms_day_query(
    schema: str, table: str, column: str, start: dt.date, end: dt.date
) -> Query:
    c = ms_ident(column)
    sql = (
        f"SELECT CAST({c} AS date), COUNT(*) FROM {ms_object(schema, table)} "
        f"WHERE {c} >= %s AND {c} < %s GROUP BY CAST({c} AS date)"
    )
    return sql, (start.isoformat(), end.isoformat())


def pg_count_query(
    schema: str, table: str, id_column: Optional[str], up_to: Optional[int]
) -> Query:
    sql = f"SELECT count(*) FROM {pg_ident(schema)}.{pg_ident(table)}"
    if id_column is None or up_to is None:
        return sql, ()
    return f"{sql} WHERE {pg_ident(id_column)} <= %s", (up_to,)


def ms_count_query(
    schema: str, table: str, id_column: Optional[str], up_to: Optional[int]
) -> Query:
    sql = f"SELECT COUNT_BIG(*) FROM {ms_object(schema, table)}"
    if id_column is None or up_to is None:
        return sql, ()
    return f"{sql} WHERE {ms_ident(id_column)} <= %s", (up_to,)

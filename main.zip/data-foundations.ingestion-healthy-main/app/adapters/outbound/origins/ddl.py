"""Rebuilds the DDL and the indexes of an origin table from catalog rows. Pure."""

from __future__ import annotations

from typing import Any, Dict, List, Sequence

_MS_SIZED = ("char", "varchar", "binary", "varbinary")
_MS_WIDE = ("nchar", "nvarchar")
_MS_EXACT = ("decimal", "numeric")
_MS_SCALED = ("datetime2", "time", "datetimeoffset")


def _pg_column(row: Sequence[Any]) -> str:
    name, ty, notnull, default, identity, generated = row
    line = f'  "{name}" {ty}'
    if generated == "s":
        line += f" GENERATED ALWAYS AS ({default}) STORED"
    elif identity:
        kind = "ALWAYS" if identity == "a" else "BY DEFAULT"
        line += f" GENERATED {kind} AS IDENTITY"
    elif default is not None:
        line += f" DEFAULT {default}"
    return line + (" NOT NULL" if notnull else "")


def pg_definition(
    schema: str,
    table: str,
    columns: Sequence[Sequence[Any]],
    constraints: Sequence[Sequence[Any]],
) -> str:
    lines = [_pg_column(row) for row in columns]
    lines += [f'  CONSTRAINT "{n}" {d}' for n, d in constraints]
    return f'CREATE TABLE "{schema}"."{table}" (\n' + ",\n".join(lines) + "\n);"


def pg_indexes(rows: Sequence[Sequence[Any]]) -> List[Dict[str, Any]]:
    return [
        {
            "name": name,
            "primary": bool(primary),
            "unique": bool(unique),
            "columns": list(cols or []),
            "include": list(include or []),
            "filter": predicate,
            "definition": definition + ";",
        }
        for name, primary, unique, definition, cols, include, predicate in rows
    ]


def ms_type(name: str, max_length: int, precision: int, scale: int) -> str:
    lowered = name.lower()
    if lowered in _MS_SIZED:
        return f"{name}({'max' if max_length == -1 else max_length})"
    if lowered in _MS_WIDE:
        return f"{name}({'max' if max_length == -1 else max_length // 2})"
    if lowered in _MS_EXACT:
        return f"{name}({precision},{scale})"
    if lowered in _MS_SCALED:
        return f"{name}({scale})"
    return name


def _ms_column(row: Sequence[Any]) -> str:
    name, ty, length, precision, scale, nullable, identity, seed, inc, default, comp = (
        row
    )
    if comp is not None:
        return f"  [{name}] AS {comp}"
    line = f"  [{name}] {ms_type(ty, length, precision, scale)}"
    if identity:
        line += f" IDENTITY({seed},{inc})"
    line += " NULL" if nullable else " NOT NULL"
    if default is not None:
        line += f" DEFAULT {default}"
    return line


def ms_definition(
    schema: str,
    table: str,
    columns: Sequence[Sequence[Any]],
    pk_columns: Sequence[str],
) -> str:
    lines = [_ms_column(row) for row in columns]
    if pk_columns:
        lines.append("  PRIMARY KEY (" + ", ".join(f"[{c}]" for c in pk_columns) + ")")
    return f"CREATE TABLE [{schema}].[{table}] (\n" + ",\n".join(lines) + "\n);"


def _ms_group(rows: Sequence[Sequence[Any]]) -> Dict[Any, Dict[str, Any]]:
    by: Dict[Any, Dict[str, Any]] = {}
    for idx, name, kind, unique, primary, filt, col, included, desc in rows:
        index = by.setdefault(
            idx,
            {
                "name": name,
                "clustered": kind == "CLUSTERED",
                "primary": bool(primary),
                "unique": bool(unique),
                "filter": filt,
                "key": [],
                "include": [],
            },
        )
        if included:
            index["include"].append(col)
        else:
            index["key"].append((col, bool(desc)))
    return by


def _ms_statement(schema: str, table: str, i: Dict[str, Any]) -> str:
    unique = "UNIQUE " if i["unique"] else ""
    kind = "CLUSTERED" if i["clustered"] else "NONCLUSTERED"
    keys = ", ".join(f"[{c}]" + (" DESC" if d else "") for c, d in i["key"])
    text = f"CREATE {unique}{kind} INDEX [{i['name']}] ON [{schema}].[{table}] ({keys})"
    if i["include"]:
        text += " INCLUDE (" + ", ".join(f"[{c}]" for c in i["include"]) + ")"
    if i["filter"]:
        text += f" WHERE {i['filter']}"
    return text + ";"


def ms_indexes(
    schema: str, table: str, rows: Sequence[Sequence[Any]]
) -> List[Dict[str, Any]]:
    return [
        {
            "name": i["name"],
            "primary": i["primary"],
            "unique": i["unique"],
            "columns": [c for c, _ in i["key"]],
            "include": i["include"],
            "filter": i["filter"],
            "definition": _ms_statement(schema, table, i),
        }
        for i in _ms_group(rows).values()
    ]

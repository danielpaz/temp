"""SQL Server origin."""

from __future__ import annotations

import datetime as dt
from typing import Any, List, Optional

import pytds

from app.adapters.outbound.origins import ddl, sql
from app.adapters.outbound.origins.base import SqlOrigin
from app.application.ports.origin import OriginTable
from app.domain.comparison import OriginDefinition


class SqlServerOrigin(SqlOrigin):
    def _connect(self, timeout: int) -> Any:
        s = self._secret
        return pytds.connect(
            dsn=s.host,
            port=int(s.port),
            user=s.user,
            password=s.password,
            database=s.database,
            login_timeout=self._settings.connect_timeout,
            timeout=int(timeout),
            autocommit=True,
        )

    def _set_timeout(self, seconds: int) -> None:
        """the driver fixes the timeout at connection time: a new one reconnects."""
        if seconds != self._timeout:
            self.close()
            self._timeout = seconds

    def _after_timeout(self) -> None:
        self.close()  # a timed-out connection is not safe to reuse

    def _catalog_sql(self) -> str:
        return sql.MS_CATALOG

    def _stats_query(self, table: OriginTable, column: str) -> sql.Query:
        obj = sql.ms_object(table.schema, table.table)
        return sql.MS_STATS, (obj, obj, column)

    def _size_query(self, table: OriginTable) -> sql.Query:
        return sql.MS_SIZE, (sql.ms_object(table.schema, table.table),)

    def _read_definition(self, table: OriginTable) -> OriginDefinition:
        args = (sql.ms_object(table.schema, table.table),)
        columns = self._rows(sql.MS_COLUMNS, args)
        indexes = ddl.ms_indexes(
            table.schema, table.table, self._rows(sql.MS_INDEXES, args)
        )
        keys: List[str] = next((i["columns"] for i in indexes if i["primary"]), [])
        text = ddl.ms_definition(table.schema, table.table, columns, keys)
        return OriginDefinition(text, indexes, len(columns))

    def _day_query(
        self, table: OriginTable, column: str, start: dt.date, end: dt.date
    ) -> sql.Query:
        return sql.ms_day_query(table.schema, table.table, column, start, end)

    def _count_query(
        self, table: OriginTable, id_column: Optional[str], up_to: Optional[int]
    ) -> sql.Query:
        return sql.ms_count_query(table.schema, table.table, id_column, up_to)

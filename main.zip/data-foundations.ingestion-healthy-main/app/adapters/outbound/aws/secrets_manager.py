"""SecretsProvider on AWS Secrets Manager.

Secrets are JSON (some with upper-case keys and no engine) or Trino catalog
files: key=value lines with a jdbc connection-url."""

from __future__ import annotations

import json
import re
from typing import Any, Dict

from app.application.ports.secrets import ConnectionSecret, SecretsProvider
from app.domain.engines import Engine, guess_engine
from app.domain.exceptions import InvalidRequest

_JDBC = re.compile(
    r"jdbc:(sqlserver|postgresql)://([^:;/]+)(?::(\d+))?(?:/([^?;]+))?(.*)"
)
_DEFAULT_PORT = {"sqlserver": "1433", "postgresql": "5432"}


def parse_properties(text: str) -> Dict[str, str]:
    props: Dict[str, str] = {}
    for line in text.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            props[key.strip()] = value.strip()
    return props


def parse_secret_text(text: str) -> Dict[str, Any]:
    """JSON as it is; otherwise a Trino connector file."""
    try:
        data = json.loads(text)
    except ValueError:
        return _from_connector(parse_properties(text))
    if not isinstance(data, dict):
        raise ValueError("secret is not an object")
    return data


def _from_connector(props: Dict[str, str]) -> Dict[str, Any]:
    match = _JDBC.match(props.get("connection-url", ""))
    if not match:
        raise ValueError("secret is neither JSON nor a recognised connector file")
    kind, host, port, pg_db, rest = match.groups()
    named = re.search(r"databaseName=([^;]+)", rest or "")
    return {
        "engine": kind,
        "host": host,
        "port": port or _DEFAULT_PORT[kind],
        "dbname": (named.group(1) if named else pg_db) or "",
        "username": props.get("connection-user", ""),
        "password": props.get("connection-password", ""),
    }


def normalize(name: str, raw: Dict[str, Any]) -> Dict[str, Any]:
    """Lower-cases keys, maps user/database to username/dbname, fills the engine."""
    data = {k.lower(): v for k, v in raw.items()}
    if "host" not in data and "hostname" in data:
        data["host"] = data["hostname"]
    if "username" not in data and "user" in data:
        data["username"] = data["user"]
    if "dbname" not in data and "database" in data:
        data["dbname"] = data["database"]
    if not data.get("engine"):
        engine = guess_engine(name)
        data["engine"] = engine.value if engine else None
    return data


def to_connection(name: str, data: Dict[str, Any]) -> ConnectionSecret:
    engine = data.get("engine")
    if not engine:
        raise InvalidRequest(f"Não foi possível identificar o banco do segredo {name}.")
    return ConnectionSecret(
        engine=Engine(engine),
        host=str(data["host"]),
        port=int(data.get("port") or _DEFAULT_PORT[engine]),
        user=str(data.get("username", "")),
        password=str(data.get("password", "")),
        database=str(data.get("dbname") or ""),
    )


class SecretsManagerProvider(SecretsProvider):
    def __init__(self, client: Any) -> None:
        self._client = client

    def connection(self, name: str) -> ConnectionSecret:
        data = self._load(name)
        try:
            return to_connection(name, data)
        except (KeyError, ValueError) as error:
            raise InvalidRequest(f"O segredo {name} está incompleto.") from error

    def host_of(self, name: str) -> str:
        host = self._load(name).get("host")
        if not host:
            raise InvalidRequest(f"O segredo {name} não informa o host.")
        return str(host)

    def _load(self, name: str) -> Dict[str, Any]:
        try:
            text = self._client.get_secret_value(SecretId=name)["SecretString"]
            return normalize(name, parse_secret_text(text))
        except Exception as error:
            raise InvalidRequest(
                f"Não foi possível ler o segredo {name} ({type(error).__name__})."
            ) from error

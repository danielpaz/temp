"""Port: reading the analytical tables of the lake (Trino)."""

from __future__ import annotations

import datetime as dt
from abc import ABC, abstractmethod
from typing import Dict, Optional, Tuple

from app.domain.comparison import LakeObject
from app.domain.values import DayMode, Period, TableKey


class LakeReader(ABC):
    """One session with the lake. Reads only. Errors that retrying cannot fix
    (missing schema, table or column) are PermanentError; the rest are LakeError."""

    @abstractmethod
    def inspect_object(self, key: TableKey) -> Optional[LakeObject]:
        """Table or view (with the DDL of a view). Best effort: never raises."""

    @abstractmethod
    def column_type(self, key: TableKey, column: str) -> str:
        """The real type of a column of the analytical table."""

    @abstractmethod
    def count_by_day(
        self,
        key: TableKey,
        column: str,
        column_type: str,
        mode: DayMode,
        period: Period,
    ) -> Dict[dt.date, int]:
        """Rows per day of the period, the day counted in the time zone of `mode`."""

    @abstractmethod
    def count_rows(self, key: TableKey) -> int:
        """Rows of the whole analytical table."""

    @abstractmethod
    def last_id(self, key: TableKey, column: str) -> Tuple[Optional[int], int]:
        """The largest id of the table, and the rows with an id up to it."""


class LakeReaderFactory(ABC):
    @abstractmethod
    def open(self) -> LakeReader:
        """A new session with the lake."""

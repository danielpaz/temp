"""Port: what the supervisor and the worker pods share during a run."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional, Set

from app.domain.progress import RunPlan, WorkerProgress


class ProgressStore(ABC):
    @abstractmethod
    def save_plan(self, plan: RunPlan) -> None:
        """Written once by the supervisor, before the pods start."""

    @abstractmethod
    def load_plan(self, run_id: str) -> RunPlan:
        """Read by every worker pod. Raises NotFound when there is none."""

    @abstractmethod
    def load_worker(self, run_id: str, worker_id: str) -> Optional[WorkerProgress]:
        """None while the worker has not reported anything."""

    @abstractmethod
    def save_worker(self, run_id: str, progress: WorkerProgress) -> None:
        """Overwrites the progress file of a worker."""

    @abstractmethod
    def request_cancel(self, run_id: str, keys: Set[str]) -> None:
        """Records the tables the user asked to stop."""

    @abstractmethod
    def cancelled(self, run_id: str) -> Set[str]:
        """The tables the user asked to stop. Empty when none."""

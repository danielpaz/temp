"""Ports: running worker pods and keeping the state of the runs."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List

from app.domain.run import PodInfo, RunState


@dataclass(frozen=True)
class WorkerLaunch:
    run_id: str
    worker_id: str
    attempt: int
    pod_name: str
    host: str
    secret: str


class WorkerPods(ABC):
    @abstractmethod
    def launch(self, launch: WorkerLaunch) -> None:
        """Starts a worker pod."""

    @abstractmethod
    def delete(self, pod_name: str) -> None:
        """Removes a pod. A pod that is already gone is not an error."""

    @abstractmethod
    def list(self, run_id: str) -> List[PodInfo]:
        """The pods of a run."""

    @abstractmethod
    def delete_run(self, run_id: str) -> None:
        """Removes every pod of a run."""


class RunStateStore(ABC):
    """The state of the runs, visible to every replica of the app."""

    @abstractmethod
    def list(self) -> List[RunState]:
        """Every stored state."""

    @abstractmethod
    def create(self, state: RunState) -> None:
        """Raises Conflict when the run already has a state."""

    @abstractmethod
    def replace(self, state: RunState) -> None:
        """Overwrites the state of a run."""

    @abstractmethod
    def delete(self, run_id: str) -> None:
        """Forgets the state of a run."""

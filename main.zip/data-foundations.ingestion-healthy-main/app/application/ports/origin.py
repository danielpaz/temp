"""Port: reading a transactional (origin) database."""

from __future__ import annotations

import datetime as dt
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from app.domain.comparison import OriginDefinition


@dataclass(frozen=True)
class OriginTable:
    """A table found in the origin catalog, with the real casing of its names."""

    schema: str
    table: str
    columns: Tuple[Tuple[str, str], ...]

    def column_named(self, name: str) -> Optional[str]:
        wanted = name.lower()
        return next((c for c, _ in self.columns if c.lower() == wanted), None)


@dataclass(frozen=True)
class OriginStats:
    rows: int
    leading_index: bool


class OriginReader(ABC):
    """One connection to one origin instance. Reads only."""

    @abstractmethod
    def find_table(self, schema: str, table: str) -> Optional[OriginTable]:
        """None when the table is not in the origin.
        Raises OriginError when the origin cannot be reached."""

    @abstractmethod
    def stats(self, table: OriginTable, column: str) -> OriginStats:
        """Never raises: unknown statistics read as 'small, no index'."""

    @abstractmethod
    def size_bytes(self, table: OriginTable) -> Optional[int]:
        """Raw size of the data, indexes left out. None when unknown."""

    @abstractmethod
    def definition(self, table: OriginTable) -> Optional[OriginDefinition]:
        """DDL and indexes rebuilt from the catalog. None when unknown."""

    @abstractmethod
    def count_by_day(
        self,
        table: OriginTable,
        column: str,
        start: dt.date,
        end_exclusive: dt.date,
        timeout_seconds: int,
    ) -> Dict[dt.date, int]:
        """Raises WindowTimeout when the window is too slow, OriginError otherwise."""

    @abstractmethod
    def count_rows(
        self,
        table: OriginTable,
        id_column: Optional[str] = None,
        up_to: Optional[int] = None,
    ) -> int:
        """Rows of the table, or of the rows whose id is up to `up_to`.
        Raises PermanentError when the count is too slow, OriginError otherwise."""

    @abstractmethod
    def close(self) -> None:
        """Drops the connection; the next read opens a new one."""


class OriginReaderFactory(ABC):
    @abstractmethod
    def open(self, secret: str, host: str) -> OriginReader:
        """A reader for the origin instance a secret points at, on `host`."""

"""Port: where the migration list and the validation results are kept."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Optional, Sequence

from app.application.read_models import MigrationOverviewRow
from app.domain.migration import MigrationDatabase, ValidationRun


class MigrationValidations(ABC):
    @abstractmethod
    def upsert_databases(self, databases: Sequence[MigrationDatabase]) -> int:
        """Adds or updates the databases of the list. Returns how many were given."""

    @abstractmethod
    def database(self, name: str) -> Optional[MigrationDatabase]:
        """None for a database that is not in the list."""

    @abstractmethod
    def save_run(self, run: ValidationRun, actor: str) -> int:
        """Keeps the run next to the earlier ones of its database. Returns the id."""

    @abstractmethod
    def latest_run(self, name: str) -> Optional[ValidationRun]:
        """The most recently registered run of a database, None when it has none."""

    @abstractmethod
    def overview(self) -> List[MigrationOverviewRow]:
        """Every database of the list with the summary of its latest run."""

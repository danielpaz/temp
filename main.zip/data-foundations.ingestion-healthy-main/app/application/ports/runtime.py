"""Ports: time and background work."""

from __future__ import annotations

import threading
import time
from abc import ABC, abstractmethod
from typing import Callable


class Clock(ABC):
    @abstractmethod
    def now(self) -> float:
        """Seconds since the epoch."""

    @abstractmethod
    def sleep(self, seconds: float) -> None:
        """Waits."""


class SystemClock(Clock):
    def now(self) -> float:
        return time.time()

    def sleep(self, seconds: float) -> None:
        time.sleep(seconds)


class Spawner(ABC):
    @abstractmethod
    def spawn(self, name: str, work: Callable[[], None]) -> None:
        """Runs `work` in the background."""


class ThreadSpawner(Spawner):
    def spawn(self, name: str, work: Callable[[], None]) -> None:
        threading.Thread(target=work, daemon=True, name=name).start()

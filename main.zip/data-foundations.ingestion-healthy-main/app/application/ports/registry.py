"""Ports: the registry of monitored tables, their results and the run history."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable, List, Optional, Sequence, Tuple

from app.application.read_models import (
    AuditEntry,
    SourceDefinitionView,
    TableOverview,
    TagCount,
)
from app.domain.comparison import ComparisonResult
from app.domain.entities import MonitoredTable
from app.domain.registry_rules import NewTable, TableChanges
from app.domain.run import RunState
from app.domain.values import Period, TableKey


class TableRegistry(ABC):
    """Commands over the monitored tables."""

    @abstractmethod
    def active_tables(self) -> List[MonitoredTable]:
        """The tables a run compares: enabled ones."""

    @abstractmethod
    def create(self, new: NewTable, host: str, actor: str) -> int:
        """Registers a table and returns its id. Raises Duplicate."""

    @abstractmethod
    def update(
        self,
        key: TableKey,
        changes: TableChanges,
        resolve_host: Callable[[str], str],
        actor: str,
    ) -> List[str]:
        """Applies the changes and returns the fields that really changed.
        `resolve_host` is called only when the secret changes.
        Raises NotFound or Duplicate."""

    @abstractmethod
    def delete(self, key: TableKey, actor: str) -> None:
        """Removes a table with its results; the audit log keeps what it was.
        Raises NotFound."""


class RegistryQueries(ABC):
    """Questions the screens ask about the registry."""

    @abstractmethod
    def overview(self) -> List[TableOverview]:
        """Every table with its current result."""

    @abstractmethod
    def version(self) -> tuple:
        """A cheap fingerprint of everything `overview` shows."""

    @abstractmethod
    def known_tags(self) -> List[TagCount]:
        """Every tag in use and how many tables carry it."""

    @abstractmethod
    def audit(self, key: Optional[TableKey], limit: int) -> List[AuditEntry]:
        """Recent changes of one table, or of every table when `key` is None."""

    @abstractmethod
    def source_definition(self, key: TableKey) -> Optional[SourceDefinitionView]:
        """None when the transactional table has not been read yet.
        Raises NotFound for an unknown table."""


class ResultStore(ABC):
    @abstractmethod
    def publish(
        self,
        run_id: str,
        items: Sequence[Tuple[MonitoredTable, ComparisonResult]],
    ) -> None:
        """Replaces the current result of each table and adds a point to its history."""


class RunHistory(ABC):
    @abstractmethod
    def started(
        self,
        run_id: str,
        period: Period,
        merge: bool,
        tables: Sequence[MonitoredTable],
        actor: Optional[str],
    ) -> None:
        """Records that a run began."""

    @abstractmethod
    def finished(self, run_id: str, state: RunState) -> None:
        """Records how a run ended."""

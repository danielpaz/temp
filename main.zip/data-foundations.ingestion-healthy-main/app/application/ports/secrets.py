"""Ports: credentials and time."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional

from app.domain.engines import Engine


@dataclass(frozen=True)
class ConnectionSecret:
    engine: Engine
    host: str
    port: int
    user: str = field(repr=False)
    password: str = field(repr=False)
    database: str = ""
    init_statement: Optional[str] = None


class SecretsProvider(ABC):
    @abstractmethod
    def connection(self, name: str) -> ConnectionSecret:
        """Credentials of a transactional database."""

    @abstractmethod
    def host_of(self, name: str) -> str:
        """The host a secret points at, never its credentials.
        Raises InvalidRequest when the secret is missing or unreadable."""

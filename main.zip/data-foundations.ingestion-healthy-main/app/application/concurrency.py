"""Small concurrency helpers shared by the use cases."""

from __future__ import annotations

import threading
from typing import Any, Callable, Dict, Hashable, TypeVar, cast

T = TypeVar("T")


class _Slot:
    def __init__(self) -> None:
        self.event = threading.Event()
        self.result: Any = None
        self.error: BaseException | None = None


class SingleFlight:
    """Runs a piece of work once per key even when several threads ask at the
    same time, e.g. a view and its base table read the same physical table.
    A success is kept for the life of the process; a failure is not, so a
    retry runs again."""

    def __init__(self) -> None:
        self._slots: Dict[Hashable, _Slot] = {}
        self._lock = threading.Lock()

    def do(self, key: Hashable, work: Callable[[], T]) -> T:
        with self._lock:
            slot = self._slots.get(key)
            owner = slot is None
            if slot is None:
                slot = self._slots[key] = _Slot()
        return self._lead(key, slot, work) if owner else self._follow(slot)

    def _lead(self, key: Hashable, slot: _Slot, work: Callable[[], T]) -> T:
        try:
            slot.result = work()
        except BaseException as error:
            slot.error = error
        finally:
            slot.event.set()
        if slot.error is not None:
            with self._lock:
                self._slots.pop(key, None)
            raise slot.error
        return cast(T, slot.result)

    @staticmethod
    def _follow(slot: _Slot):
        slot.event.wait()
        if slot.error is not None:
            raise slot.error
        return slot.result

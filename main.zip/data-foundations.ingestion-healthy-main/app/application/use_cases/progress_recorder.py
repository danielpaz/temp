"""Keeps the progress of one worker and saves it as the work advances."""

from __future__ import annotations

import threading
from typing import Dict

from app.application.ports.progress import ProgressStore
from app.application.ports.runtime import Clock
from app.domain.comparison import ComparisonResult
from app.domain.progress import Chunks, TableProgress, TableState, WorkerProgress
from app.domain.values import ResultStatus


class ProgressRecorder:
    """Thread-safe: the tables of a worker may be compared at the same time."""

    def __init__(
        self,
        store: ProgressStore,
        run_id: str,
        progress: WorkerProgress,
        clock: Clock,
    ) -> None:
        self.store = store
        self.run_id = run_id
        self.progress = progress
        self.clock = clock
        self.lock = threading.RLock()

    def resume(self) -> None:
        """Reuses the tables a previous pod attempt of this worker finished."""
        previous = self.store.load_worker(self.run_id, self.progress.worker_id)
        if previous is not None:
            self.progress.reuse(previous)

    def table(self, key: str) -> TableProgress:
        with self.lock:
            return self.progress.table(key)

    def is_done(self, key: str) -> bool:
        return self.table(key).state is TableState.DONE

    def windows_of(self, key: str) -> Dict[str, dict]:
        with self.lock:
            return self.progress.partial.setdefault(key, {})

    def mark_cancelled(self, key: str) -> None:
        with self.lock:
            table = self.progress.table(key)
            table.state, table.error = TableState.CANCELLED, ""
            self.save()

    def attempt_started(self, key: str, attempt: int) -> None:
        with self.lock:
            table = self.progress.table(key)
            table.state, table.attempts = TableState.RUNNING, attempt
            table.error = "" if attempt == 1 else table.error
            self.save()

    def chunk_done(self, key: str, number: int, total: int) -> None:
        with self.lock:
            self.progress.table(key).chunks = Chunks(number, total)
            self.save()

    def attempt_failed(self, key: str, error: str) -> None:
        with self.lock:
            table = self.progress.table(key)
            table.state, table.error = TableState.RETRYING, error
            self.save()

    def finished(self, key: str, attempts: int, result: ComparisonResult) -> None:
        with self.lock:
            table = self.progress.table(key)
            table.attempts = attempts
            table.chunks = None
            failed = result.status is ResultStatus.ERROR
            table.state = TableState.ERROR if failed else TableState.DONE
            table.error = result.error or ""
            self.progress.partial.pop(key, None)
            self.progress.results[key] = result
            self.save()

    def save(self, state: str = "") -> None:
        with self.lock:
            if state:
                self.progress.state = state
            self.progress.updated = self.clock.now()
            self.store.save_worker(self.run_id, self.progress)

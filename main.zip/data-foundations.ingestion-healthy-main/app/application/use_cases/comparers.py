"""One way of comparing a table per criterion: by day, up to an id, whole volume.

Every comparer reads the lake first: when the analytical table is missing the
much heavier read of the origin is skipped."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Dict

from app.application.ports.lake import LakeReader
from app.application.ports.origin import OriginReader, OriginTable
from app.application.use_cases.origin_day_counter import (
    DayCountRequest,
    OriginDayCounter,
)
from app.domain.comparison import ComparisonResult, TableFacts
from app.domain.entities import MonitoredTable
from app.domain.exceptions import PermanentError
from app.domain.values import Period

INTEGER_TYPES = ("tinyint", "smallint", "integer", "bigint")


@dataclass
class ComparisonJob:
    """One table, the two sides it is read from, and what has been learned."""

    table: MonitoredTable
    period: Period
    origin: OriginReader
    lake: LakeReader
    facts: TableFacts
    windows_done: Dict[str, dict]
    on_chunk: Callable[[int, int], None]


class TableComparer(ABC):
    @abstractmethod
    def compare(self, job: ComparisonJob) -> ComparisonResult:
        """Reads both sides and compares them. Raises PermanentError,
        OriginError or LakeError."""


def note_lake_object(job: ComparisonJob) -> None:
    found = job.lake.inspect_object(job.table.key)
    if found is not None:
        job.facts.lake_object = found


def find_origin_table(job: ComparisonJob) -> OriginTable:
    key = job.table.key
    found = job.origin.find_table(key.source_schema, key.source_table)
    if found is None:
        raise PermanentError(
            "origin query failed: LookupError: table not found in origin"
        )
    if not job.facts.origin_read:
        job.facts.origin_size_bytes = job.origin.size_bytes(found)
        job.facts.origin_definition = job.origin.definition(found)
        job.facts.origin_read = True
    return found


def origin_column(origin_table: OriginTable, name: str, what: str) -> str:
    column = origin_table.column_named(name)
    if column is None:
        raise PermanentError(
            f"origin query failed: LookupError: {what} not found in origin"
        )
    return column


class DailyComparer(TableComparer):
    def __init__(self, counter: OriginDayCounter) -> None:
        self.counter = counter

    def compare(self, job: ComparisonJob) -> ComparisonResult:
        lake_counts = self._lake_counts(job)
        origin_table = find_origin_table(job)
        column = origin_column(
            origin_table, job.table.filter_column or "", "date column"
        )
        request = DayCountRequest(
            origin=job.origin,
            table=origin_table,
            column=column,
            period=job.period,
            stats=job.origin.stats(origin_table, column),
            instance=job.table.secret,
            windows_done=job.windows_done,
            on_chunk=job.on_chunk,
        )
        origin_counts = self.counter.count(request)
        return ComparisonResult.daily(
            job.table, job.period, origin_counts, lake_counts, job.facts
        )

    @staticmethod
    def _lake_counts(job: ComparisonJob):
        note_lake_object(job)
        column = job.table.filter_column or ""
        column_type = job.lake.column_type(job.table.key, column)
        if column_type != "date" and not column_type.startswith("timestamp"):
            raise PermanentError(
                f"a coluna {column} é do tipo {column_type}, "
                "que não é uma data nem um timestamp"
            )
        job.facts.lake_column_type = column_type
        return job.lake.count_by_day(
            job.table.key, column, column_type, job.table.day_mode, job.period
        )


class IdComparer(TableComparer):
    """Counts the lake up to its largest id, then the origin up to the same id."""

    def compare(self, job: ComparisonJob) -> ComparisonResult:
        column = job.table.filter_column or ""
        last_id, lake_rows = self._lake_side(job, column)
        origin_table = find_origin_table(job)
        id_column = None
        if last_id is not None:
            id_column = origin_column(origin_table, column, "id column")
        origin_rows = job.origin.count_rows(origin_table, id_column, last_id)
        return ComparisonResult.up_to_id(
            job.table, job.period, origin_rows, lake_rows, last_id, job.facts
        )

    @staticmethod
    def _lake_side(job: ComparisonJob, column: str):
        note_lake_object(job)
        column_type = job.lake.column_type(job.table.key, column)
        if column_type not in INTEGER_TYPES:
            raise PermanentError(
                f"a coluna {column} é do tipo {column_type}; "
                "para comparar por ID a coluna precisa ser inteira"
            )
        job.facts.lake_column_type = column_type
        return job.lake.last_id(job.table.key, column)


class WholeTableComparer(TableComparer):
    """A table without a column to filter by is compared by its whole volume."""

    def compare(self, job: ComparisonJob) -> ComparisonResult:
        note_lake_object(job)
        lake_rows = job.lake.count_rows(job.table.key)
        origin_table = find_origin_table(job)
        origin_rows = job.origin.count_rows(origin_table)
        return ComparisonResult.whole_table(
            job.table, job.period, origin_rows, lake_rows, job.facts
        )

"""Compares one table, with retries, and records every step."""

from __future__ import annotations

from typing import Callable, Mapping

from app.application.ports.lake import LakeReader
from app.application.ports.origin import OriginReader
from app.application.use_cases.comparers import ComparisonJob, TableComparer
from app.application.use_cases.progress_recorder import ProgressRecorder
from app.domain.comparison import ComparisonResult, TableFacts
from app.domain.entities import MonitoredTable
from app.domain.exceptions import OriginError, describe
from app.domain.policies import RetryPolicy, run_with_retry
from app.domain.values import Criterion, Period


class ProcessTable:
    def __init__(
        self,
        comparers: Mapping[Criterion, TableComparer],
        retry: RetryPolicy,
        sleep: Callable[[float], None],
    ) -> None:
        self.comparers = comparers
        self.retry = retry
        self.sleep = sleep

    def run(
        self,
        table: MonitoredTable,
        period: Period,
        origin: OriginReader,
        lake: LakeReader,
        recorder: ProgressRecorder,
    ) -> None:
        """Never raises: a table that cannot be compared ends as a failed result."""
        key = str(table.key)
        facts = TableFacts()
        comparer = self.comparers[table.criterion]

        def attempt(number: int) -> ComparisonResult:
            job = ComparisonJob(
                table=table,
                period=period,
                origin=origin,
                lake=lake,
                facts=facts,
                windows_done=recorder.windows_of(key),
                on_chunk=lambda n, total: recorder.chunk_done(key, n, total),
            )
            return comparer.compare(job)

        def failed(_number: int, error: Exception) -> None:
            if isinstance(error, OriginError):
                origin.close()
            recorder.attempt_failed(key, describe(error))

        outcome = run_with_retry(
            attempt,
            self.retry,
            on_attempt=lambda number: recorder.attempt_started(key, number),
            on_failure=failed,
            sleep=self.sleep,
        )
        result = outcome.result or ComparisonResult.failed(
            table, period, outcome.error or "", facts
        )
        recorder.finished(key, outcome.attempts_used, result)

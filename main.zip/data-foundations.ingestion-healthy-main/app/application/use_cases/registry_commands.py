"""Registering, editing and removing monitored tables, and reading the registry."""

from __future__ import annotations

from typing import List, Mapping, Optional, Tuple

from app.application.ports.registry import RegistryQueries, TableRegistry
from app.application.ports.secrets import SecretsProvider
from app.application.read_models import (
    AuditEntry,
    SourceDefinitionView,
    TableOverview,
    TagCount,
)
from app.application.use_cases.run_commands import BusyTables
from app.domain.exceptions import Conflict, InvalidRequest, NotFound
from app.domain.registry_rules import (
    normalize_actor,
    parse_changes,
    parse_new_table,
)
from app.domain.values import TableKey

MAX_AUDIT = 50


class CreateTable:
    def __init__(self, registry: TableRegistry, secrets: SecretsProvider) -> None:
        self.registry = registry
        self.secrets = secrets

    def execute(self, fields: Mapping, actor: object) -> Tuple[int, TableKey]:
        new = parse_new_table(fields)
        host = self.secrets.host_of(new.secret)
        table_id = self.registry.create(new, host, normalize_actor(actor))
        return table_id, new.key


class EditTable:
    def __init__(self, registry: TableRegistry, secrets: SecretsProvider) -> None:
        self.registry = registry
        self.secrets = secrets

    def execute(self, key: str, changes: Mapping, actor: object) -> List[str]:
        """Returns the fields that really changed."""
        table_key = TableKey.parse(key)
        parsed = parse_changes(changes)
        return self.registry.update(
            table_key, parsed, self.secrets.host_of, normalize_actor(actor)
        )


class DeleteTable:
    def __init__(self, registry: TableRegistry, busy: BusyTables) -> None:
        self.registry = registry
        self.busy = busy

    def execute(self, key: str, actor: object) -> TableKey:
        table_key = TableKey.parse(key)
        if str(table_key) in self.busy.execute():
            raise Conflict(
                "A tabela está em atualização. Espere terminar para excluí-la."
            )
        self.registry.delete(table_key, normalize_actor(actor))
        return table_key


class ListResults:
    def __init__(self, queries: RegistryQueries) -> None:
        self.queries = queries

    def version(self) -> tuple:
        return self.queries.version()

    def execute(self) -> List[TableOverview]:
        return self.queries.overview()


class ListTags:
    def __init__(self, queries: RegistryQueries) -> None:
        self.queries = queries

    def execute(self) -> List[TagCount]:
        return self.queries.known_tags()


class ListAudit:
    def __init__(self, queries: RegistryQueries) -> None:
        self.queries = queries

    def execute(self, key: Optional[str], limit: object = 10) -> List[AuditEntry]:
        try:
            size = max(1, min(int(limit), MAX_AUDIT))  # type: ignore[call-overload]
        except (TypeError, ValueError):
            raise InvalidRequest("O limite deve ser um número.")
        table_key = TableKey.parse(key) if key else None
        return self.queries.audit(table_key, size)


class GetSourceDefinition:
    def __init__(self, queries: RegistryQueries) -> None:
        self.queries = queries

    def execute(self, key: str) -> SourceDefinitionView:
        found = self.queries.source_definition(TableKey.parse(key))
        if found is None:
            raise NotFound("O DDL desta tabela ainda não foi lido. Atualize a tabela.")
        return found

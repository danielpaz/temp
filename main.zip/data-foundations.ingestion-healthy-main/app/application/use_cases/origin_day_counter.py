"""Counts the rows of an origin table per day, in windows when the table is big."""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import Callable, Dict, Optional

from app.application.concurrency import SingleFlight
from app.application.ports.origin import OriginReader, OriginStats, OriginTable
from app.domain.exceptions import PermanentError, WindowTimeout
from app.domain.policies import WindowPlanner, halves
from app.domain.values import Period

Counts = Dict[dt.date, int]
TIMEOUT_MARK = "__timeout__"


@dataclass
class DayCountRequest:
    origin: OriginReader
    table: OriginTable
    column: str
    period: Period
    stats: OriginStats
    instance: str
    windows_done: Dict[str, dict]
    on_chunk: Callable[[int, int], None]


class OriginDayCounter:
    """A window that times out is split in half and each half is tried again,
    down to a single day. Results of the windows are kept in `windows_done`, so a
    new pod resumes where the previous one died."""

    def __init__(
        self,
        planner: WindowPlanner,
        flight: SingleFlight,
        query_timeout: int,
        chunk_timeout: int,
    ) -> None:
        self.planner = planner
        self.flight = flight
        self.query_timeout = query_timeout
        self.chunk_timeout = chunk_timeout

    def count(self, request: DayCountRequest) -> Counts:
        stats = request.stats
        chunked = self.planner.should_chunk(
            stats.rows, stats.leading_index, request.period.size
        )
        windows = self.planner.windows(request.period, chunked)
        counts: Counts = {}
        for number, (start, end) in enumerate(windows, 1):
            counts.update(self._range(request, start, end, chunked))
            if chunked:
                request.on_chunk(number, len(windows))
        return counts

    def _range(
        self, request: DayCountRequest, start: dt.date, end: dt.date, chunked: bool
    ) -> Counts:
        label = f"{start.isoformat()}..{end.isoformat()}"
        known = request.windows_done.get(label)
        if known is not None and TIMEOUT_MARK not in known:
            return _restore(known)
        if known is None:
            counted = self._try_window(request, label, start, end, chunked)
            if counted is not None:
                return counted
        first, second = halves(start, end)
        counts = {
            **self._range(request, *first, True),
            **self._range(request, *second, True),
        }
        request.windows_done[label] = _store(counts)
        return counts

    def _try_window(
        self,
        request: DayCountRequest,
        label: str,
        start: dt.date,
        end: dt.date,
        chunked: bool,
    ) -> Optional[Counts]:
        key = (
            request.instance,
            request.table.schema,
            request.table.table,
            request.column,
            start,
            end,
        )
        try:
            counts = self.flight.do(
                key, lambda: self._query(request, start, end, chunked)
            )
        except WindowTimeout as error:
            if not chunked or (end - start).days <= 1:
                raise PermanentError(str(error))
            request.windows_done[label] = {TIMEOUT_MARK: 1}
            return None
        request.windows_done[label] = _store(counts)
        return counts

    def _query(
        self, request: DayCountRequest, start: dt.date, end: dt.date, chunked: bool
    ) -> Counts:
        timeout = self.chunk_timeout if chunked else self.query_timeout
        try:
            return request.origin.count_by_day(
                request.table, request.column, start, end, timeout
            )
        except WindowTimeout as error:
            text = self._timeout_text(request, start, end, error)
            raise WindowTimeout(text) from error

    def _timeout_text(self, request, start, end, error) -> str:
        stats = request.stats
        hint = ""
        if stats.rows >= self.planner.min_rows and not stats.leading_index:
            hint = (
                f" Tabela grande (~{stats.rows / 1e9:.1f} bi de linhas) sem índice "
                f"em {request.column}: a contagem por data varre a tabela inteira "
                "(dividir em janelas não ajuda)."
            )
        head, found, tail = str(error).partition(f"{start}..{end}.")
        text = f"{head}{found}{hint}{tail}" if found else f"{error}{hint}"
        return text[:700]


def _store(counts: Counts) -> Dict[str, int]:
    return {day.isoformat(): n for day, n in counts.items()}


def _restore(stored: dict) -> Counts:
    return {dt.date.fromisoformat(day): n for day, n in stored.items()}

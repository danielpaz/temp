"""The migration tab: the database list, registering validations and reading them."""

from __future__ import annotations

from typing import List, Mapping

from app.application.ports.migration import MigrationValidations
from app.application.read_models import MigrationDatabaseView, MigrationOverviewRow
from app.domain.exceptions import InvalidRequest, NotFound
from app.domain.migration import MigrationDatabase
from app.domain.migration_document import from_document
from app.domain.registry_rules import normalize_actor

MAX_DATABASES = 500


def _database(item: object) -> MigrationDatabase:
    if not isinstance(item, Mapping):
        raise InvalidRequest("Cada banco deve ser um objeto.")

    def text(key: str) -> str:
        return str(item.get(key) or "").strip()[:255]

    return MigrationDatabase(
        text("database"), text("host_sql"), text("host_postgresql"), text("observacao")
    )


class ImportMigrationDatabases:
    def __init__(self, repository: MigrationValidations) -> None:
        self.repository = repository

    def execute(self, items: object) -> int:
        if not isinstance(items, list) or not items or len(items) > MAX_DATABASES:
            raise InvalidRequest("Informe a lista de bancos em 'databases'.")
        return self.repository.upsert_databases([_database(i) for i in items])


class RegisterValidation:
    def __init__(self, repository: MigrationValidations) -> None:
        self.repository = repository

    def execute(self, document: Mapping, actor: object) -> int:
        run = from_document(document)
        if self.repository.database(run.database) is None:
            raise NotFound(
                f"O banco {run.database} não está na lista. Importe a lista antes."
            )
        return self.repository.save_run(run, normalize_actor(actor))


class ListMigrationOverview:
    def __init__(self, repository: MigrationValidations) -> None:
        self.repository = repository

    def execute(self) -> List[MigrationOverviewRow]:
        return self.repository.overview()


class GetMigrationValidation:
    def __init__(self, repository: MigrationValidations) -> None:
        self.repository = repository

    def execute(self, name: str) -> MigrationDatabaseView:
        database = self.repository.database(name)
        if database is None:
            raise NotFound("Banco desconhecido.")
        return MigrationDatabaseView(database, self.repository.latest_run(name))

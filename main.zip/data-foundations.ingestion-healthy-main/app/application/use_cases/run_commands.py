"""Starting and stopping runs, and asking what is running."""

from __future__ import annotations

import datetime as dt
import secrets
from typing import Callable, Optional, Sequence, Set

from app.application.ports.cluster import RunStateStore
from app.application.ports.progress import ProgressStore
from app.application.ports.registry import RunHistory, TableRegistry
from app.application.ports.runtime import Clock, Spawner
from app.application.use_cases.coordinator import RunCoordinator, RunReaper
from app.application.use_cases.supervisor import RunSupervisor
from app.domain.entities import MonitoredTable
from app.domain.exceptions import Conflict, InvalidRequest, Unavailable
from app.domain.progress import RunPlan
from app.domain.run import RunCounts, RunRules, RunState, RunStatus, TableRun
from app.domain.run_policies import admit, build_status, select_cancellations
from app.domain.values import Period


def new_run_id() -> str:
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
    return f"{stamp}-{secrets.token_hex(2)}"


class StartRun:
    def __init__(
        self,
        registry: TableRegistry,
        states: RunStateStore,
        history: RunHistory,
        reaper: RunReaper,
        coordinator: RunCoordinator,
        supervisor: RunSupervisor,
        spawner: Spawner,
        clock: Clock,
        rules: RunRules,
        run_ids: Callable[[], str] = new_run_id,
    ) -> None:
        self.registry = registry
        self.states = states
        self.history = history
        self.reaper = reaper
        self.coordinator = coordinator
        self.supervisor = supervisor
        self.spawner = spawner
        self.clock = clock
        self.rules = rules
        self.run_ids = run_ids

    def execute(
        self,
        date_from,
        date_to,
        tables: Optional[Sequence[str]] = None,
        actor: Optional[str] = None,
    ) -> str:
        """`tables` None runs everything. A list of keys re-runs only those and
        merges them into the published result. Runs of a few tables may go at
        the same time; a full run needs the cluster to itself."""
        period = Period.parse(date_from, date_to, self.rules.max_days)
        with self.coordinator.lock:
            active = self.reaper.active_states()
            chosen = admit(active, tables, self.registry.active_tables(), self.rules)
            state = self._new_state(period, chosen, merge=tables is not None)
            self._register(state, period, chosen, actor)
            self.coordinator.forget_status()
            plan = RunPlan(state.run_id, period, chosen, state.merge)
            self.spawner.spawn(
                f"run-{state.run_id}", lambda: self.supervisor.supervise(plan, state)
            )
        return state.run_id

    def _new_state(
        self, period: Period, chosen: Sequence[MonitoredTable], merge: bool
    ) -> RunState:
        now = self.clock.now()
        return RunState(
            run_id=self.run_ids(),
            period=period,
            started_at=now,
            heartbeat=now,
            merge=merge,
            tables={str(t.key): TableRun() for t in chosen},
            counts=RunCounts(total=len(chosen)),
        )

    def _register(self, state, period, chosen, actor) -> None:
        try:
            self.history.started(state.run_id, period, state.merge, chosen, actor)
        except Exception as error:
            raise Unavailable(
                f"Não foi possível registrar a execução: {type(error).__name__}"
            ) from error
        try:
            self.states.create(state)
        except Exception:
            state.status = RunStatus.FAILED
            state.message = "Não foi possível iniciar a execução."
            self._best_effort_finish(state)
            raise

    def _best_effort_finish(self, state: RunState) -> None:
        try:
            self.history.finished(state.run_id, state)
        except Exception:
            pass


class CancelRun:
    def __init__(
        self,
        progress: ProgressStore,
        reaper: RunReaper,
        coordinator: RunCoordinator,
    ) -> None:
        self.progress = progress
        self.reaper = reaper
        self.coordinator = coordinator

    def execute(self, tables: Optional[Sequence[str]] = None) -> int:
        """Stops the given tables of the runs in progress, or all of them. A
        table already published keeps its result; one that was still pending or
        running keeps whatever it had before the run. Returns how many tables
        were asked to stop."""
        with self.coordinator.lock:
            active = self.reaper.active_states()
            if not active:
                raise Conflict("Não há atualização em andamento.")
            wanted = None if tables is None else {str(k) for k in tables}
            chosen = select_cancellations(active, wanted)
            if not chosen:
                raise InvalidRequest("Nenhuma dessas tabelas está em atualização.")
            for run_id, keys in chosen.items():
                self.progress.request_cancel(run_id, keys)
            self.coordinator.forget_status()
            return sum(len(keys) for keys in chosen.values())


class GetRunStatus:
    def __init__(
        self,
        states: RunStateStore,
        coordinator: RunCoordinator,
        clock: Clock,
        rules: RunRules,
    ) -> None:
        self.states = states
        self.coordinator = coordinator
        self.clock = clock
        self.rules = rules

    def execute(self) -> dict:
        now = self.clock.now()
        cached = self.coordinator.cached_status(now)
        if cached is not None:
            return cached
        view = build_status(self.states.list(), now, self.rules)
        self.coordinator.remember_status(now, view)
        return view


class BusyTables:
    """The tables that belong to a run in progress."""

    def __init__(self, states: RunStateStore, clock: Clock, rules: RunRules) -> None:
        self.states = states
        self.clock = clock
        self.rules = rules

    def execute(self) -> Set[str]:
        now, ttl = self.clock.now(), self.rules.heartbeat_ttl
        return {
            key
            for state in self.states.list()
            if state.is_active(now, ttl)
            for key in state.busy_keys()
        }

"""Turns the decisions of the workers into pod operations."""

from __future__ import annotations

from typing import Dict, Mapping, Optional, Set

from app.application.ports.cluster import WorkerLaunch, WorkerPods
from app.application.ports.runtime import Clock
from app.domain.progress import WorkerProgress
from app.domain.run import (
    Action,
    CancelAction,
    Decision,
    PodInfo,
    RunRules,
    Worker,
    WorkerStatus,
)

Workers = Mapping[str, Worker]
Reported = Mapping[str, Optional[WorkerProgress]]


def pod_name(run_id: str, worker_id: str, attempt: int) -> str:
    return f"ih-{run_id}-{worker_id}-a{attempt}"


class WorkerFleet:
    def __init__(self, pods: WorkerPods, clock: Clock, rules: RunRules) -> None:
        self.pods = pods
        self.clock = clock
        self.rules = rules

    def pods_of(self, run_id: str) -> Dict[str, PodInfo]:
        return {pod.name: pod for pod in self.pods.list(run_id)}

    def advance_all(
        self,
        run_id: str,
        workers: Workers,
        pods: Mapping[str, PodInfo],
        reported: Reported,
    ) -> None:
        for worker_id, worker in workers.items():
            can_start = self._active(workers) < self.rules.max_parallel
            decision = worker.react(
                pods.get(worker.pod or ""),
                reported.get(worker_id),
                self.clock.now(),
                self.rules,
                can_start,
            )
            self._apply(run_id, worker, decision)

    def apply_cancellations(
        self, workers: Workers, reported: Reported, asked: Set[str]
    ) -> None:
        for worker_id, worker in workers.items():
            action, keys = worker.cancel_action(reported.get(worker_id), asked)
            if action is CancelAction.NONE:
                continue
            worker.handled += keys
            self.drop(worker)
            if action is CancelAction.FINISH:
                worker.status = WorkerStatus.DONE
            else:
                worker.cancels += 1
                worker.status = WorkerStatus.RETRYING
                worker.retry_at = self.clock.now()

    def drop(self, worker: Worker) -> None:
        try:
            if worker.pod:
                self.pods.delete(worker.pod)
        except Exception:
            pass

    @staticmethod
    def _active(workers: Workers) -> int:
        return sum(1 for w in workers.values() if w.status.active)

    def _apply(self, run_id: str, worker: Worker, decision: Decision) -> None:
        if decision.action is Action.LAUNCH:
            self._launch(run_id, worker)
        elif decision.action is Action.FINISH:
            worker.status = WorkerStatus.DONE
            self.drop(worker)
        elif decision.action is Action.FAIL:
            self._fail(worker, decision.reason)
        elif decision.action is Action.RUNNING:
            worker.status = WorkerStatus.RUNNING

    def _launch(self, run_id: str, worker: Worker) -> None:
        name = pod_name(run_id, worker.worker_id, worker.attempt + 1)
        worker.start_attempt(name, self.clock.now())
        try:
            self.pods.launch(
                WorkerLaunch(
                    run_id,
                    worker.worker_id,
                    worker.attempt,
                    name,
                    worker.host,
                    worker.secret,
                )
            )
            worker.status = WorkerStatus.STARTING
        except Exception as error:
            text = f"falha ao criar o pod: {type(error).__name__}: {error}"
            self._fail(worker, text[:200])

    def _fail(self, worker: Worker, reason: str) -> None:
        self.drop(worker)
        worker.register_failure(reason, self.clock.now(), self.rules)

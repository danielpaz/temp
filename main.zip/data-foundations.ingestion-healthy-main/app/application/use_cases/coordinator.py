"""State shared by the use cases that start, stop, show and reap runs."""

from __future__ import annotations

import threading
from typing import List, Optional, Tuple

from app.application.ports.cluster import RunStateStore, WorkerPods
from app.application.ports.registry import RunHistory
from app.application.ports.runtime import Clock
from app.domain.run import STOPPED_MESSAGE, RunRules, RunState, RunStatus


class RunCoordinator:
    """Starts and cancels are serialised: checking and creating must be atomic."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self._status: Tuple[float, Optional[dict]] = (0.0, None)

    def cached_status(self, now: float, max_age: float = 1.0) -> Optional[dict]:
        taken, view = self._status
        return view if view is not None and now - taken < max_age else None

    def remember_status(self, now: float, view: dict) -> None:
        self._status = (now, view)

    def forget_status(self) -> None:
        self._status = (0.0, None)


class RunReaper:
    """Frees the runs whose supervisor died and drops the oldest finished states."""

    def __init__(
        self,
        states: RunStateStore,
        pods: WorkerPods,
        history: RunHistory,
        clock: Clock,
        rules: RunRules,
    ) -> None:
        self.states = states
        self.pods = pods
        self.history = history
        self.clock = clock
        self.rules = rules

    def active_states(self) -> List[RunState]:
        """Every state, with the dead runs closed, then the runs still alive."""
        states = self.states.list()
        self.reap(states)
        return [
            s for s in states if s.is_active(self.clock.now(), self.rules.heartbeat_ttl)
        ]

    def reap(self, states: List[RunState]) -> None:
        now = self.clock.now()
        for state in states:
            running = state.status is RunStatus.RUNNING
            if running and not state.is_active(now, self.rules.heartbeat_ttl):
                self._interrupt(state, now)
        self._prune(states)

    def _interrupt(self, state: RunState, now: float) -> None:
        self._best_effort(self.pods.delete_run, state.run_id)
        state.status = RunStatus.INTERRUPTED
        state.finished_at = now
        state.message = STOPPED_MESSAGE
        self._best_effort(self.states.replace, state)
        self._best_effort(self.history.finished, state.run_id, state)

    def _prune(self, states: List[RunState]) -> None:
        finished = [s for s in states if s.status is not RunStatus.RUNNING]
        finished.sort(key=lambda s: s.started_at, reverse=True)
        for state in finished[self.rules.keep_finished :]:
            self._best_effort(self.states.delete, state.run_id)

    @staticmethod
    def _best_effort(action, *args) -> None:
        try:
            action(*args)
        except Exception:
            pass

"""Hands what the workers produced to the result store."""

from __future__ import annotations

from typing import Dict, List, Mapping, Optional, Set, Tuple

from app.application.ports.registry import ResultStore
from app.domain.comparison import ComparisonResult, TableFacts
from app.domain.entities import MonitoredTable
from app.domain.progress import RunPlan, TableState, WorkerProgress
from app.domain.run import RunState, Worker

Reported = Mapping[str, Optional[WorkerProgress]]


class ResultPublisher:
    """A full run is published once, at the end: publishing as tables finish
    would replace the page with a half-filled one. A run of some tables only
    replaces the results of its own tables."""

    def __init__(self, results: ResultStore) -> None:
        self.results = results

    def publish(
        self,
        plan: RunPlan,
        state: RunState,
        workers: Mapping[str, Worker],
        reported: Reported,
        final: bool,
    ) -> Set[str]:
        """Returns the keys of the tables whose result was stored."""
        items = self._items(plan, state, workers, reported, final)
        self.results.publish(plan.run_id, items)
        return {str(table.key) for table, _ in items}

    def _items(
        self, plan, state, workers, reported, final
    ) -> List[Tuple[MonitoredTable, ComparisonResult]]:
        by_key = _worker_of_key(workers)
        items = []
        for table in plan.tables:
            key = str(table.key)
            if state.tables[key].state is TableState.CANCELLED:
                continue
            progress = reported.get(by_key[key])
            result = progress.results.get(key) if progress else None
            if result is None and final:
                result = _missing(table, plan, state)
            if result is not None:
                items.append((table, result))
        return items


def _worker_of_key(workers: Mapping[str, Worker]) -> Dict[str, str]:
    return {key: wid for wid, worker in workers.items() for key in worker.keys}


def _missing(table: MonitoredTable, plan: RunPlan, state: RunState) -> ComparisonResult:
    """A table whose worker never reported ends as a failed result."""
    message = state.tables[str(table.key)].error
    return ComparisonResult.failed(table, plan.period, message, TableFacts())

"""Supervises one run: starts the pods, follows their progress and publishes."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Set, Tuple

from app.application.ports.cluster import RunStateStore, WorkerPods
from app.application.ports.progress import ProgressStore
from app.application.ports.registry import RunHistory
from app.application.ports.runtime import Clock
from app.application.use_cases.fleet import WorkerFleet
from app.application.use_cases.publisher import ResultPublisher
from app.domain.exceptions import DomainError
from app.domain.progress import RunPlan, TableState, WorkerProgress
from app.domain.run import (
    RunRules,
    RunState,
    RunStatus,
    Worker,
    WorkerStatus,
    fold_tables,
)
from app.domain.run_policies import assign_workers, conclude


@dataclass
class RunContext:
    plan: RunPlan
    state: RunState
    workers: Dict[str, Worker]
    deadline: float
    reported: Dict[str, Optional[WorkerProgress]] = field(default_factory=dict)
    asked: Set[str] = field(default_factory=set)
    published_keys: Set[str] = field(default_factory=set)
    last_publish: Tuple[float, int] = (0.0, -1)


class RunSupervisor:
    def __init__(
        self,
        states: RunStateStore,
        progress: ProgressStore,
        pods: WorkerPods,
        fleet: WorkerFleet,
        publisher: ResultPublisher,
        history: RunHistory,
        clock: Clock,
        rules: RunRules,
    ) -> None:
        self.states = states
        self.progress = progress
        self.pods = pods
        self.fleet = fleet
        self.publisher = publisher
        self.history = history
        self.clock = clock
        self.rules = rules

    def supervise(self, plan: RunPlan, state: RunState) -> None:
        """Runs in the background. Whatever happens, the run ends with a state."""
        try:
            self._execute(plan, state)
        except Exception as error:
            self._crash(plan.run_id, state, error)

    def _execute(self, plan: RunPlan, state: RunState) -> None:
        self.progress.save_plan(plan)
        context = RunContext(
            plan,
            state,
            assign_workers(plan.tables),
            deadline=self.clock.now() + self.rules.run_timeout,
        )
        while not self._step(context):
            self.clock.sleep(self.rules.poll)
        self._finish(context)

    def _step(self, ctx: RunContext) -> bool:
        """One look at the run. True when it is over."""
        run_id = ctx.plan.run_id
        pods = self.fleet.pods_of(run_id)
        self._collect(ctx)
        self.fleet.advance_all(run_id, ctx.workers, pods, ctx.reported)
        self.fleet.apply_cancellations(ctx.workers, ctx.reported, ctx.asked)
        self._fold(ctx, ctx.asked)
        self._maybe_publish(ctx)
        self._save(ctx.state)
        if all(w.status.over for w in ctx.workers.values()):
            return True
        if self.clock.now() > ctx.deadline:
            self._time_out(ctx)
            return True
        return False

    def _collect(self, ctx: RunContext) -> None:
        run_id = ctx.plan.run_id
        for worker_id in ctx.workers:
            try:
                reported = self.progress.load_worker(run_id, worker_id)
                ctx.reported[worker_id] = reported or ctx.reported.get(worker_id)
            except Exception:
                pass
        try:
            ctx.asked |= self.progress.cancelled(run_id)
        except Exception:
            pass

    def _fold(self, ctx: RunContext, asked: Set[str]) -> None:
        tables = fold_tables(ctx.workers, ctx.reported, asked)
        ctx.state.update_tables(tables, ctx.workers)
        self._flag_published(ctx)

    @staticmethod
    def _flag_published(ctx: RunContext) -> None:
        for key in ctx.published_keys:
            table = ctx.state.tables.get(key)
            if table and table.state in (TableState.DONE, TableState.ERROR):
                table.published = True

    def _maybe_publish(self, ctx: RunContext) -> None:
        state, now = ctx.state, self.clock.now()
        settled = state.counts.settled
        last_time, last_count = ctx.last_publish
        due = state.merge and settled and settled != last_count
        if not due or now - last_time < self.rules.publish_every:
            return
        try:
            keys = self.publisher.publish(
                ctx.plan, state, ctx.workers, ctx.reported, final=False
            )
        except Exception:
            return
        ctx.published_keys |= keys
        ctx.last_publish = (now, settled)
        state.published = settled
        self._flag_published(ctx)

    def _time_out(self, ctx: RunContext) -> None:
        for worker in ctx.workers.values():
            if not worker.status.over:
                worker.status = WorkerStatus.FAILED
                worker.error = "tempo limite da atualização excedido"
        self._fold(ctx, set())

    def _finish(self, ctx: RunContext) -> None:
        plan, state = ctx.plan, ctx.state
        self.publisher.publish(plan, state, ctx.workers, ctx.reported, final=True)
        status, message = conclude(state.counts, len(plan.tables))
        state.status, state.message = status, message
        state.finished_at = self.clock.now()
        self._save(state)
        self._record_end(state)
        self._cleanup(plan.run_id)

    def _crash(self, run_id: str, state: RunState, error: Exception) -> None:
        reason = (
            str(error)
            if isinstance(error, DomainError)
            else (f"Falha no orquestrador: {type(error).__name__}: {error}")
        )
        state.status = RunStatus.FAILED
        state.finished_at = self.clock.now()
        state.message = reason[:400]
        self._save(state)
        self._record_end(state)
        self._cleanup(run_id)

    def _save(self, state: RunState) -> None:
        state.heartbeat = self.clock.now()
        try:
            self.states.replace(state)
        except Exception:
            pass

    def _record_end(self, state: RunState) -> None:
        try:
            self.history.finished(state.run_id, state)
        except Exception:
            pass

    def _cleanup(self, run_id: str) -> None:
        try:
            self.pods.delete_run(run_id)
        except Exception:
            pass

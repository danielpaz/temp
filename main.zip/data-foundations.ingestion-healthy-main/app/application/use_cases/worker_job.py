"""What a worker pod does: compare the tables of one origin instance."""

from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Dict, List, Tuple

from app.application.ports.lake import LakeReader, LakeReaderFactory
from app.application.ports.origin import OriginReader, OriginReaderFactory
from app.application.ports.progress import ProgressStore
from app.application.ports.runtime import Clock
from app.application.use_cases.process_table import ProcessTable
from app.application.use_cases.progress_recorder import ProgressRecorder
from app.domain.entities import MonitoredTable
from app.domain.progress import RunPlan, WorkerProgress


class ReaderPool:
    """Database connections are not thread-safe: each thread keeps its own."""

    def __init__(self, origins: OriginReaderFactory, lakes: LakeReaderFactory) -> None:
        self.origins = origins
        self.lakes = lakes
        self._local = threading.local()
        self._opened: List[object] = []
        self._lock = threading.Lock()

    def lake(self) -> LakeReader:
        if not hasattr(self._local, "lake"):
            self._local.lake = self._remember(self.lakes.open())
        return self._local.lake

    def origin(self, secret: str, host: str) -> OriginReader:
        readers: Dict[Tuple[str, str], OriginReader] = self._local.__dict__.setdefault(
            "origins", {}
        )
        if (secret, host) not in readers:
            readers[(secret, host)] = self._remember(self.origins.open(secret, host))
        return readers[(secret, host)]

    def close_all(self) -> None:
        for reader in self._opened:
            close = getattr(reader, "close", None)
            if close:
                close()

    def _remember(self, reader):
        with self._lock:
            self._opened.append(reader)
        return reader


class RunWorkerJob:
    def __init__(
        self,
        store: ProgressStore,
        origins: OriginReaderFactory,
        lakes: LakeReaderFactory,
        process: ProcessTable,
        clock: Clock,
        concurrency: int = 1,
        log: Callable[[str], None] = print,
    ) -> None:
        self.store = store
        self.origins = origins
        self.lakes = lakes
        self.process = process
        self.clock = clock
        self.concurrency = max(1, concurrency)
        self.log = log

    def run(
        self, run_id: str, worker_id: str, host: str, secret: str, attempt: str
    ) -> None:
        plan = self.store.load_plan(run_id)
        tables = plan.tables_of(secret, host)
        self.log(
            f"worker {worker_id}: {len(tables)} tables on {host} ({secret}), "
            f"period {plan.period.start}..{plan.period.end}"
        )
        recorder = ProgressRecorder(
            self.store, run_id, WorkerProgress(worker_id, host, attempt), self.clock
        )
        recorder.resume()
        for table in tables:
            recorder.table(str(table.key))
        recorder.save()
        self._compare_all(plan, tables, recorder)
        recorder.save("done")
        self.log("worker finished")

    def _compare_all(
        self, plan: RunPlan, tables: List[MonitoredTable], recorder: ProgressRecorder
    ) -> None:
        pool = ReaderPool(self.origins, self.lakes)
        self.log(f"processing {len(tables)} tables, {self.concurrency} at a time")
        try:
            with ThreadPoolExecutor(max_workers=self.concurrency) as executor:
                list(
                    executor.map(
                        lambda table: self._work(plan, table, recorder, pool), tables
                    )
                )
        finally:
            pool.close_all()

    def _work(
        self,
        plan: RunPlan,
        table: MonitoredTable,
        recorder: ProgressRecorder,
        pool: ReaderPool,
    ) -> None:
        key = str(table.key)
        if recorder.is_done(key):
            return
        if key in self.store.cancelled(plan.run_id):
            recorder.mark_cancelled(key)
            return
        origin = pool.origin(table.secret, table.host)
        self.process.run(table, plan.period, origin, pool.lake(), recorder)
        done = recorder.table(key)
        state = done.state.value.upper()
        self.log(f"[{state}] {key} attempts={done.attempts} {done.error[:160]}")

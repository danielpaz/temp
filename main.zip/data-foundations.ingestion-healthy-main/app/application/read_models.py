"""Read models: what the screens need to see, already shaped for reading."""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import List, Optional

from app.domain.comparison import DayCount
from app.domain.migration import MigrationDatabase, StatusCounts, ValidationRun
from app.domain.values import (
    DayMode,
    FilterKind,
    ObjectType,
    Period,
    ResultStatus,
    TableKey,
)


@dataclass(frozen=True)
class OriginDefinitionSummary:
    """What the table list shows about the DDL of the transactional table."""

    known: bool = False
    columns: Optional[int] = None
    indexes: Optional[int] = None
    primary_key: List[str] = field(default_factory=list)
    filter_column_indexed: Optional[bool] = None


@dataclass
class TableOverview:
    """One row of the table list: the registry data and its current result."""

    id: int
    key: TableKey
    host: str
    secret: str
    filter_column: Optional[str]
    filter_kind: FilterKind
    day_mode: DayMode
    day_mode_source: Optional[str]
    enabled: bool
    status: ResultStatus
    error: str
    config_pending: bool
    tags: List[str]
    lake_column_type: Optional[str] = None
    period: Optional[Period] = None
    origin_total: Optional[int] = None
    lake_total: Optional[int] = None
    diff: Optional[int] = None
    computed_at: Optional[dt.datetime] = None
    result_basis: Optional[str] = None
    last_id: Optional[int] = None
    object_type: Optional[ObjectType] = None
    object_ddl: Optional[str] = None
    object_checked_at: Optional[dt.datetime] = None
    origin_size_bytes: Optional[int] = None
    origin_definition: OriginDefinitionSummary = field(
        default_factory=OriginDefinitionSummary
    )
    days: List[DayCount] = field(default_factory=list)


@dataclass(frozen=True)
class SourceDefinitionView:
    table: str
    ddl: str
    indexes: List[dict]
    columns: Optional[int]
    checked_at: Optional[dt.datetime]
    filter_column: Optional[str]


@dataclass(frozen=True)
class TagCount:
    tag: str
    tables: int


@dataclass(frozen=True)
class AuditEntry:
    at: dt.datetime
    actor: str
    action: str
    field: Optional[str]
    old: Optional[str]
    new: Optional[str]
    table: Optional[str]


@dataclass(frozen=True)
class MigrationOverviewRow:
    """A database of the migration list and, if any, its latest validation."""

    name: str
    host_sql: str
    host_postgresql: str
    note: str
    counts: Optional["StatusCounts"] = None
    captured_at: Optional[dt.datetime] = None
    teleport_sql: str = ""
    teleport_sql_uri: str = ""
    teleport_aurora: str = ""

    @property
    def validated(self) -> bool:
        return self.counts is not None


@dataclass(frozen=True)
class MigrationDatabaseView:
    database: "MigrationDatabase"
    run: Optional["ValidationRun"] = None

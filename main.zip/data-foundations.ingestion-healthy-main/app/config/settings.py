"""Every tunable of the service, read once from the environment."""

from __future__ import annotations

from typing import Tuple

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    host: str = "0.0.0.0"
    port: int = 8000
    namespace: str = "ingestion-healthy"
    service_account: str = "ingestion-healthy"
    db_secret: str = ""
    aws_region: str = "sa-east-1"
    worker_image: str = ""
    worker_run_as_user: int = 100
    worker_run_as_group: int = 101
    worker_memory_request: str = "512Mi"
    worker_memory_limit: str = "4Gi"
    trino_secret: str = "prod/engenhariadedados/service/svcpresto"
    trino_host: str = ""
    trino_timezone: str = ""

    max_days: int = 90
    max_runs: int = 5
    run_timeout: float = 14400
    publish_every: float = 30
    table_concurrency: int = Field(default=1, ge=1)
    table_attempts: int = Field(default=3, ge=1)
    table_backoff: str = "5,15"
    query_timeout: int = 600
    chunk_days: int = Field(default=15, ge=1)
    chunk_min_rows: int = 100_000_000
    chunk_timeout: int = 300

    @property
    def backoff(self) -> Tuple[float, ...]:
        return tuple(float(x) for x in self.table_backoff.split(","))

    def forwarded_env(self) -> dict:
        """What a worker pod needs besides its identity."""
        values = {
            "DB_SECRET": self.db_secret,
            "AWS_REGION": self.aws_region,
            "TRINO_SECRET": self.trino_secret,
            "TRINO_HOST": self.trino_host,
            "TRINO_TIMEZONE": self.trino_timezone,
            "TABLE_CONCURRENCY": str(self.table_concurrency),
            "TABLE_ATTEMPTS": str(self.table_attempts),
            "TABLE_BACKOFF": self.table_backoff,
            "QUERY_TIMEOUT": str(self.query_timeout),
            "CHUNK_DAYS": str(self.chunk_days),
            "CHUNK_MIN_ROWS": str(self.chunk_min_rows),
            "CHUNK_TIMEOUT": str(self.chunk_timeout),
        }
        return {k: v for k, v in values.items() if v}

import pytest

from tests.support.http_theme import Rig

T3 = "DB2.dbo.t3@trusted_zone.trusted_db2.dbo_t3"
PERIOD = ("2026-09-10", "2026-09-11")


@pytest.fixture
def rig():
    rig = Rig()
    rig.hold_runs()
    return rig


def finish(rig, run_id):
    rig.world.run_to_end(run_id)


def test_cancel_without_a_run_is_conflict(rig):
    reply = rig.client.post("/api/run/cancel", json={})
    assert reply.status_code == 409 and "error" in reply.json()


def test_cancel_all_returns_how_many(rig):
    run_id = rig.world.start.execute(*PERIOD)
    reply = rig.client.post("/api/run/cancel", json={})
    assert (reply.status_code, reply.json()) == (200, {"cancelled": 4})
    finish(rig, run_id)


def test_cancel_some_tables_returns_how_many(rig):
    run_id = rig.world.start.execute(*PERIOD)
    reply = rig.client.post("/api/run/cancel", json={"tables": [T3]})
    assert (reply.status_code, reply.json()) == (200, {"cancelled": 1})
    rig.world.cancel.execute()
    finish(rig, run_id)


def test_cancel_with_tables_that_are_not_a_list_is_400(rig):
    reply = rig.client.post("/api/run/cancel", json={"tables": "a.b.c"})
    assert reply.status_code == 400


def test_cancel_of_tables_not_in_a_run_is_400(rig):
    run_id = rig.world.start.execute(*PERIOD, [T3])
    reply = rig.client.post("/api/run/cancel", json={"tables": ["x"]})
    assert reply.status_code == 400
    rig.world.cancel.execute()
    finish(rig, run_id)

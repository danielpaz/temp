import csv
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest

from app.adapters.inbound.cli import migration_import, skill_output
from app.domain.migration_document import from_document

TABLE_DETAIL = "Tabela dbo.ORDERS recriada como public.orders"


def make_folder(root: Path) -> Path:
    folder = root / "FAKE_DB"
    folder.mkdir()
    summary = lambda t, c, s, d: {  # noqa: E731
        "check": c,
        "severity": s,
        "table": t,
        "column": None,
        "src": None,
        "tgt": None,
        "detail": d,
        "expected": False,
        "kind": "summary",
        "title": "Tabela",
    }
    finding = lambda t, s, e: {  # noqa: E731
        "check": "C6",
        "severity": s,
        "table": t,
        "column": "ID",
        "src": "a",
        "tgt": "b",
        "detail": "x",
        "expected": e,
    }
    diff = [
        {**summary("(database)", "C0", "yellow", "sem SCT"), "title": "SCT"},
        summary("dbo.ORDERS", "C1", "ok", TABLE_DETAIL),
        finding("dbo.ORDERS", "red", False),
        finding("dbo.ORDERS", "info", False),
        summary("dbo.ITEMS", "C1", "ok", "Tabela dbo.ITEMS recriada como public.items"),
        finding("dbo.ITEMS", "yellow", False),
        finding("dbo.ITEMS", "red", True),
        summary("dbo.LOGS", "C1", "ok", "Tabela dbo.LOGS recriada como public.logs"),
    ]
    (folder / "diff.json").write_text(json.dumps(diff))
    side = {
        "approx_rows": 100,
        "size_bytes": 10,
        "watermark": {"column": "D", "min": "1", "max": "2"},
        "exact_count": {"value": 150, "cutoff": "2"},
        "tz_samples": [{"secret_row": "PRIVATE-VALUE"}],
    }
    names = ("dbo.ORDERS", "dbo.ITEMS", "dbo.LOGS")
    mssql = {
        "meta": {
            "version": "Microsoft SQL Server 2019 - 15.0\nmore",
            "server_tz": "UTC",
        },
        "tables": {n: dict(side) for n in names},
    }
    pg = {
        "meta": {
            "version": "PostgreSQL 16",
            "server_tz": "UTC",
            "captured_at": "2026-10-13 15:10:00.123456789+00",
        },
        "tables": {n.replace("dbo.", "public.").lower(): dict(side) for n in names},
    }
    (folder / "snapshot_mssql.json").write_text(json.dumps(mssql))
    (folder / "snapshot_pg.json").write_text(json.dumps(pg))
    (folder / "run.json").write_text(
        json.dumps({"db": "FAKE_DB", "tgt_db": "fake_db", "tgt_schema": "public"})
    )
    with open(folder / "colunas.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(
            "database_name,table_name,column_name,src_type,tgt_column,tgt_type,"
            "expected_type,src_nullable,tgt_nullable,status,detail".split(",")
        )
        w.writerow(
            [
                "FAKE_DB",
                "dbo.ORDERS",
                "ID",
                "int",
                "id",
                "int4",
                "int4",
                "não",
                "não",
                "Divergente",
                "",
            ]
        )
    return folder


def test_document_is_accepted_and_status_matches_findings(tmp_path):
    folder = make_folder(tmp_path)
    doc = skill_output.build_document(folder, "FAKE_DB", {"pasta": "x"})
    run = from_document(doc)
    status = {t.name: t.status.value for t in run.tables}
    assert status == {
        "dbo.ORDERS": "attention",
        "dbo.ITEMS": "review",
        "dbo.LOGS": "ok",
    }
    assert (run.counts.attention, run.counts.review, run.counts.ok) == (1, 1, 1)
    assert [t.name for t in run.ordered_tables()][0] == "dbo.ORDERS"
    orders = next(t for t in run.tables if t.name == "dbo.ORDERS")
    assert orders.target_name == "public.orders"
    assert orders.columns[0].status == "red"
    assert [f.severity.value for f in orders.findings] == ["red", "info"]
    assert orders.source is None and orders.target is None and not orders.count_caveat
    assert run.source.engine == "Microsoft SQL Server 2019"
    assert doc["captured"] == "2026-10-13T15:10:00Z"
    assert doc["db_findings"][0]["title"] == "SCT"
    assert "PRIVATE-VALUE" not in json.dumps(doc)
    assert doc["res"] == {}


def test_resources_are_renamed_and_filtered():
    res = skill_output.normalize_resources(
        {"pasta": "p", "teleport_sql": "t", "sct_resposta": "s", "x": "y"}
    )
    assert res == {"teleport_sql": "t", "sct_answer": "s"}


def test_missing_file_is_a_clear_error(tmp_path):
    folder = make_folder(tmp_path)
    (folder / "diff.json").unlink()
    with pytest.raises(skill_output.SkillOutputError, match="diff.json"):
        skill_output.build_document(folder, "FAKE_DB")


def test_read_databases(tmp_path):
    path = tmp_path / "databases.csv"
    path.write_text(
        "database,host_postgresql,host_sql,observacao\nA, pg1 ,sql1,nota\n,x,y,\n",
        encoding="utf-8",
    )
    assert skill_output.read_databases(path) == [
        {
            "database": "A",
            "host_sql": "sql1",
            "host_postgresql": "pg1",
            "observacao": "nota",
        }
    ]


class Capture(BaseHTTPRequestHandler):
    received: list = []

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        Capture.received.append((self.path, body))
        code, out = (
            (201, {"id": 7}) if "validations" in self.path else (200, {"imported": 1})
        )
        if body.get("actor") == "boom":
            code, out = 404, {"error": "Banco desconhecido"}
        data = json.dumps(out).encode()
        self.send_response(code)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass


@pytest.fixture
def server():
    Capture.received = []
    httpd = HTTPServer(("127.0.0.1", 0), Capture)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{httpd.server_port}"
    httpd.shutdown()
    httpd.server_close()


def test_validation_posts_document(tmp_path, server, capsys):
    folder = make_folder(tmp_path)
    code = migration_import.main(
        [
            "--url",
            server,
            "--actor",
            "bruno",
            "validation",
            str(folder),
            "--database",
            "FAKE_DB",
        ]
    )
    assert code == 0
    path, body = Capture.received[0]
    assert path == "/api/migration/validations"
    assert body["actor"] == "bruno"
    from_document(body["run"])
    assert "id 7" in capsys.readouterr().out


def test_databases_posts_list(tmp_path, server, capsys):
    path = tmp_path / "d.csv"
    path.write_text("database,host_postgresql,host_sql,observacao\nA,p,s,\n")
    assert migration_import.main(["--url", server, "databases", str(path)]) == 0
    assert Capture.received[0][1]["databases"][0]["database"] == "A"
    assert "1 bancos" in capsys.readouterr().out


def test_server_error_exits_nonzero(tmp_path, server, capsys):
    folder = make_folder(tmp_path)
    code = migration_import.main(
        [
            "--url",
            server,
            "--actor",
            "boom",
            "validation",
            str(folder),
            "--database",
            "FAKE_DB",
        ]
    )
    assert code == 1
    assert "Banco desconhecido" in capsys.readouterr().err


def test_dry_run_sends_nothing(tmp_path, monkeypatch, capsys):
    def fail(*a, **k):
        raise AssertionError("no request expected")

    monkeypatch.setattr(migration_import.urllib.request, "urlopen", fail)
    monkeypatch.delenv("MIGRATION_URL", raising=False)
    folder = make_folder(tmp_path)
    code = migration_import.main(
        ["--dry-run", "validation", str(folder), "--database", "FAKE_DB"]
    )
    out = capsys.readouterr().out
    assert code == 0
    assert "atenção: 1" in out and "dbo.ORDERS" in out


def test_missing_url_is_reported(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("MIGRATION_URL", raising=False)
    path = tmp_path / "d.csv"
    path.write_text("database,host_postgresql,host_sql,observacao\nA,p,s,\n")
    assert migration_import.main(["databases", str(path)]) == 1
    assert "MIGRATION_URL" in capsys.readouterr().err


def make_sibling_folder(root: Path) -> Path:
    """A complete result folder of another database of the same cluster."""
    root.mkdir()
    return make_folder(root)


def _with_target_only_tables(folder: Path) -> None:
    diff = json.loads((folder / "diff.json").read_text())
    base = {
        "check": "C1",
        "severity": "yellow",
        "column": None,
        "src": None,
        "tgt": None,
        "detail": "tabela existe só no Aurora (sem origem mapeada)",
        "expected": False,
        "kind": "finding",
    }
    diff.append({**base, "table": "public.orders"})
    diff.append({**base, "table": "public.other"})
    (folder / "diff.json").write_text(json.dumps(diff))


def test_tables_of_a_sibling_take_its_comparison_and_a_note(tmp_path):
    main = make_sibling_folder(tmp_path / "main")
    _with_target_only_tables(main)
    sibling = make_sibling_folder(tmp_path / "sibling")
    found = skill_output.sibling_tables(sibling, "CDB")
    assert set(found) == {"public.orders", "public.items", "public.logs"}
    run = from_document(
        skill_output.build_document(main, "FAKE", siblings={"CDB": found})
    )
    tables = {t.name: t for t in run.tables}
    taken = tables["public.orders"]
    assert taken.note == "Veio do banco CDB"
    assert taken.target_name == "public.orders"
    assert [c.title for c in taken.checks] == ["Tabela"]
    assert [f.severity.value for f in taken.findings] == ["red", "info"]
    assert taken.columns and taken.status.value == "attention"
    other = tables["public.other"]
    assert other.note is None and other.status.value == "review"


def test_the_sibling_option_is_read_and_validated(tmp_path):
    sibling = make_sibling_folder(tmp_path / "sibling")
    found = migration_import.read_siblings([f"CDB={sibling}"])
    assert set(found["CDB"]) == {"public.orders", "public.items", "public.logs"}
    with pytest.raises(migration_import.ImportFailure):
        migration_import.read_siblings(["sem-igual"])


def test_hyphenated_table_names_are_recognised(tmp_path):
    folder = make_sibling_folder(tmp_path / "sibling")
    diff = json.loads((folder / "diff.json").read_text())
    for item in diff:
        if item["table"] == "dbo.ORDERS" and item.get("kind") == "summary":
            item["detail"] = "presente no Aurora como dbo.invt-acct.cdb-acc-api-command"
    (folder / "diff.json").write_text(json.dumps(diff))
    assert "dbo.invt-acct.cdb-acc-api-command" in skill_output.sibling_tables(
        folder, "CDB"
    )


def _moved_document(folder: Path, target_db: str) -> dict:
    run = json.loads((folder / "run.json").read_text())
    run["tgt_db"] = target_db
    (folder / "run.json").write_text(json.dumps(run))
    return skill_output.build_document(folder, "FAKE")


def test_a_table_moved_to_another_database_gets_a_red_check(tmp_path):
    folder = make_sibling_folder(tmp_path / "moved")
    run = from_document(_moved_document(folder, "investment"))
    tables = {t.name: t for t in run.tables}
    orders = tables["dbo.ORDERS"]
    moved = [c for c in orders.checks if c.title == skill_output.MOVED_TITLE]
    assert [(c.id, c.severity.value) for c in moved] == [("C10", "red")]
    assert "database FAKE_DB (SQL" in moved[0].detail
    assert "database INVESTMENT (Aurora)" in moved[0].detail
    assert orders.findings[0].check == "C10" and orders.status.value == "attention"
    assert all(
        any(c.title == skill_output.MOVED_TITLE for c in t.checks)
        for t in run.tables
        if t.target_name
    )


def test_a_table_that_stays_in_its_database_has_no_such_check(tmp_path):
    folder = make_sibling_folder(tmp_path / "same")
    run = from_document(_moved_document(folder, "FAKE_DB"))
    assert not any(
        c.title == skill_output.MOVED_TITLE for t in run.tables for c in t.checks
    )


def test_the_move_travels_with_the_sibling_comparison(tmp_path):
    main = make_sibling_folder(tmp_path / "main")
    _with_target_only_tables(main)
    sibling = make_sibling_folder(tmp_path / "sibling")
    run_file = sibling / "run.json"
    run = json.loads(run_file.read_text())
    run["tgt_db"] = "investment"
    run_file.write_text(json.dumps(run))
    found = skill_output.sibling_tables(sibling, "CDB")
    document = skill_output.build_document(main, "FAKE", siblings={"CDB": found})
    taken = {t.name: t for t in from_document(document).tables}["public.orders"]
    assert any(c.title == skill_output.MOVED_TITLE for c in taken.checks)

import pytest
from fastapi.testclient import TestClient

from tests.support.http_theme import JSON, Rig
from tests.support.migration_fakes import sample_document

LIST = [
    {
        "database": "MGM_REFERRAL",
        "host_sql": "vaspawp-dbcad01.neonprd.corp:1433",
        "host_postgresql": "aurora.example",
        "observacao": "piloto",
    },
    {"database": "OTHER", "host_sql": "10.0.0.1"},
]


@pytest.fixture
def rig():
    return Rig()


@pytest.fixture
def client(rig) -> TestClient:
    return rig.client


def imported(client):
    return client.post("/api/migration/databases", json={"databases": LIST})


def registered(client, document=None, **extra):
    body = {"run": document or sample_document(), **extra}
    return client.post("/api/migration/validations", json=body)


def test_import_counts_databases(client):
    reply = imported(client)
    assert reply.status_code == 200
    assert reply.json() == {"imported": 2}


@pytest.mark.parametrize(
    "body", [{}, {"databases": []}, {"databases": ["x"]}, {"databases": [{}]}]
)
def test_import_rejects_malformed_lists(client, body):
    reply = client.post("/api/migration/databases", json=body)
    assert reply.status_code == 400
    assert "error" in reply.json()


def test_overview_before_any_validation(client):
    imported(client)
    rows = client.get("/api/migration/databases").json()["databases"]
    first = rows[0]
    assert first["name"] == "MGM_REFERRAL"
    assert first["validated"] is False
    assert first["status"] == "none"
    assert first["counts"] is None
    assert first["tables"] == 0
    assert first["captured"] is None
    assert first["group"] == "VASPAWP-DBCAD01"
    assert first["host_pg"] == "aurora.example"
    assert first["obs"] == "piloto"
    assert rows[1]["group"] == "10.0.0.1"
    assert set(first["res"]) == {"teleport_sql", "teleport_sql_uri", "teleport_aurora"}


def test_overview_with_a_validation(client):
    imported(client)
    registered(client)
    first = client.get("/api/migration/databases").json()["databases"][0]
    assert first["validated"] is True
    assert first["status"] == "attention"
    assert first["counts"] == {"attention": 1, "review": 0, "ok": 1}
    assert first["tables"] == 2
    assert first["captured"] == "2026-10-13T15:10:00Z"
    assert first["group"] == "VASPAWP-DBCAD01"
    assert first["res"]["teleport_sql"] == "VASPAWP-DBCAD01"


def test_validation_of_a_database_without_run(client):
    imported(client)
    reply = client.get("/api/migration/databases/OTHER")
    assert reply.status_code == 200
    body = reply.json()
    assert body["run"] is None
    assert body["database"] == {
        "name": "OTHER",
        "host_sql": "10.0.0.1",
        "host_pg": "",
        "obs": "",
    }


def test_validation_shape(client):
    imported(client)
    registered(client)
    run = client.get("/api/migration/databases/MGM_REFERRAL").json()["run"]
    assert run["src_db"] == "MGM_REFERRAL"
    assert run["tgt_schema"] == "public"
    assert run["captured"] == "2026-10-13T15:10:00Z"
    assert run["src_meta"] == {"engine": "Microsoft SQL Server 2019", "tz": "-03:00"}
    assert run["status"] == "attention"
    assert run["counts"] == {"attention": 1, "review": 0, "ok": 1}
    assert run["res"]["sct_answer"] == "não sei"
    assert run["db_findings"][0]["title"] == "Conversão de schema (SCT)"
    assert run["verifs"] == [
        {"title": "Tabela", "total": 2, "ok": 1, "yellow": 0, "red": 1, "skip": 0}
    ]
    worst, clean = run["tables"]
    assert worst["name"] == "dbv.database_version"
    assert worst["status"] == "attention"
    assert worst["n"] == {"red": 1, "yellow": 0, "info": 0, "skip": 0}
    assert worst["tgt"] is None
    assert worst["findings"][0]["expected"] is False
    assert clean["name"] == "dbo.code_used"
    assert clean["status"] == "ok"
    assert clean["columns"][0]["tgt_name"] == "code_used_id"
    assert clean["src"]["exact"] == 10
    assert clean["tgt"]["wm_col"] == "created_at_dt"
    assert clean["count_caveat"] is False


def test_findings_are_sorted_and_expected_ones_are_not_counted(client):
    document = sample_document()
    table = document["tables"][0]
    table["findings"] = [
        {"check": "C2", "sev": sev, "detail": "d", "expected": expected}
        for sev, expected in (
            ("ok", False),
            ("info", False),
            ("red", True),
            ("yellow", False),
            ("red", False),
        )
    ]
    imported(client)
    registered(client, document)
    run = client.get("/api/migration/databases/MGM_REFERRAL").json()["run"]
    table = next(t for t in run["tables"] if t["name"] == "dbo.code_used")
    assert [f["sev"] for f in table["findings"]] == [
        "red",
        "red",
        "yellow",
        "info",
        "ok",
    ]
    assert table["n"] == {"red": 1, "yellow": 1, "info": 1, "skip": 0}
    assert table["status"] == "attention"


def test_unknown_database_is_404(client):
    reply = client.get("/api/migration/databases/NOPE")
    assert reply.status_code == 404
    assert "error" in reply.json()


def test_register_returns_id_and_records_actor(rig, client):
    imported(client)
    reply = registered(client, actor="ana")
    assert reply.status_code == 201
    assert reply.json() == {"id": 1}
    assert rig.migrations.runs[0][1] == "ana"


def test_register_for_unlisted_database_is_404(client):
    reply = registered(client)
    assert reply.status_code == 404
    assert "error" in reply.json()


@pytest.mark.parametrize("run", [None, "x", {}, {"database": "MGM_REFERRAL"}])
def test_register_malformed_is_400(client, run):
    imported(client)
    reply = client.post("/api/migration/validations", json={"run": run})
    assert reply.status_code == 400
    assert "error" in reply.json()


@pytest.mark.parametrize(
    "path", ["/api/migration/databases", "/api/migration/validations"]
)
def test_posts_need_json(client, path):
    assert client.post(path, content="x").status_code == 415
    assert client.post(path, content="{", headers=JSON).status_code == 400
    assert client.post(path, content="[]", headers=JSON).status_code == 400


def test_body_limits(client):
    big = b"{" + b" " * (256 * 1024 + 1) + b"}"
    assert (
        client.post("/api/migration/databases", content=big, headers=JSON).status_code
        == 413
    )
    huge = b"{" + b" " * (4 * 1024 * 1024 + 1) + b"}"
    assert (
        client.post(
            "/api/migration/validations", content=huge, headers=JSON
        ).status_code
        == 413
    )
    # 300KB is fine for a validation, too large for a list
    middle = b'{"run": {}, "pad": "' + b"x" * 300_000 + b'"}'
    assert (
        client.post(
            "/api/migration/validations", content=middle, headers=JSON
        ).status_code
        == 400
    )

"""The Migration page (static/migration.html): string contract, route and, when
node is available, the render functions run against contract-shaped data."""

import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.adapters.inbound.http import routers
from app.adapters.inbound.http.routers.pages import pages_router

STATIC = Path(routers.__file__).resolve().parent.parent / "static"
MIGRATION = STATIC / "migration.html"
INDEX = STATIC / "index.html"


@pytest.fixture(scope="module")
def html() -> str:
    return MIGRATION.read_text()


def test_both_pages_carry_the_tab_bar():
    for page in (INDEX, MIGRATION):
        text = page.read_text()
        assert 'href="/"' in text and 'href="/migration"' in text
        assert "Ingestion Healthy" in text and "Migration" in text
    assert re.search(r'id="tab-ih"[^>]*aria-current="page"', INDEX.read_text())
    assert re.search(r'id="tab-mg"[^>]*aria-current="page"', MIGRATION.read_text())


def test_the_route_serves_the_page():
    app = FastAPI()
    app.include_router(pages_router())
    response = TestClient(app).get("/migration")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/html")
    assert response.content == MIGRATION.read_bytes()


def test_the_page_is_self_contained_and_follows_the_theme(html):
    assert not re.search(r"(src|href)=[\"']https?://", html)
    assert not re.search(r"url\(\s*[\"']?https?://", html)
    for needle in (
        'localStorage.getItem("theme")',
        'localStorage.setItem("theme"',
        'setAttribute("data-theme"',
        ':root[data-theme="dark"]',
        'id="themeBtn"',
    ):
        assert needle in html


def test_the_page_talks_to_the_contract_endpoints(html):
    assert "/api/migration/databases" in html
    assert "Nenhum banco importado ainda" in html
    assert "Não foi possível carregar" in html
    assert "#/db/" in html


NODE = shutil.which("node")
DB = {
    "name": "SALES",
    "host_sql": "SQLHOST1",
    "host_pg": "x.cluster-ro-abc.rds.example",
    "obs": "<b>obs</b>",
    "validated": True,
    "status": "attention",
    "counts": {"attention": 1, "review": 1, "ok": 1},
    "tables": 3,
    "captured": "2026-10-13T15:10:00Z",
    "group": "SQLHOST1",
    "res": {
        "teleport_sql": "sqlhost1",
        "teleport_sql_uri": "u",
        "teleport_aurora": "a",
    },
}
AURORA_ONLY = {
    "name": "dbo.only_here",
    "tgt_name": None,
    "status": "ok",
    "n": {"red": 0, "yellow": 0, "info": 0, "skip": 0},
    "checks": [],
    "findings": [
        {
            "check": "C1",
            "sev": "yellow",
            "column": None,
            "src": None,
            "tgt": None,
            "detail": "tabela existe só no Aurora; Veio do banco CDB",
            "expected": True,
        }
    ],
    "columns": [],
    "src": None,
    "tgt": None,
    "count_caveat": False,
    "note": "Veio do banco CDB",
}
TABLE = {
    "name": "dbo.<img>",
    "tgt_name": "public.t",
    "status": "review",
    "n": {"red": 0, "yellow": 1, "info": 0, "skip": 0},
    "checks": [{"id": "C1", "title": "Contagem", "sev": "ok", "detail": "igual"}],
    "findings": [
        {
            "check": "C6",
            "sev": "yellow",
            "column": "ID",
            "src": "NULL",
            "tgt": "NOT NULL",
            "detail": "aceita nulo <x>",
            "expected": False,
        }
    ],
    "columns": [
        {
            "name": "ID",
            "src": "int",
            "tgt_name": "id",
            "tgt": "integer",
            "exp": "integer",
            "nsrc": "YES",
            "ntgt": "NO",
            "status": "yellow",
            "detail": "",
        },
        {
            "name": "B",
            "src": "int",
            "tgt_name": "b",
            "tgt": "integer",
            "exp": "integer",
            "nsrc": "NO",
            "ntgt": "NO",
            "status": "ok",
            "detail": "",
        },
    ],
    "src": {"approx": 1500, "size": 2048, "exact": 10, "cutoff": "2026-01-01"},
    "tgt": {"approx": 1500, "size": 4096},
    "count_caveat": True,
    "note": "Veio do banco <CDB>",
}
RUN = {
    "src_db": "SALES",
    "tgt_db": "sales",
    "tgt_schema": "public",
    "captured": "2026-10-13T15:10:00Z",
    "src_meta": {"engine": "SQL Server 2019", "tz": "-03:00"},
    "tgt_meta": {"engine": "PostgreSQL 15", "tz": "UTC"},
    "tables": [TABLE, AURORA_ONLY],
    "verifs": [
        {"title": "Contagem", "total": 1, "ok": 1, "yellow": 0, "red": 0, "skip": 0}
    ],
    "db_findings": [
        {"check": "C0", "sev": "yellow", "title": "Conversão", "detail": "sem SCT"},
        {"check": "C9", "sev": "yellow", "title": "Outro aviso", "detail": "aviso <i>"},
    ],
    "counts": {"attention": 0, "review": 1, "ok": 0},
    "status": "review",
    "res": {"sct_answer": "não sei", "teleport_sql": "sqlhost1"},
}

JS = """
const fs = require('fs'), vm = require('vm');
const html = fs.readFileSync(process.argv[1], 'utf8');
const code = html.split('<script id="app-script">')[1].split('</script>')[0];
const ctx = vm.createContext({});
vm.runInContext(code, ctx);
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const ui = { filter: 'all', q: '', open: new Set(['dbo.<img>']), onlyDiff: {} };
const run2 = JSON.parse(JSON.stringify(input.payload));
const none = {total: 0, ok: 0, yellow: 0, red: 0, skip: 0};
run2.run.verifs.push({title: 'Maiúscula/minúscula de UUID', ...none});
run2.run.verifs.push({title: 'Tipos', ...none});
run2.run.tables.push({name: 'dbv.gone', tgt_name: null, status: 'attention',
  n: {red: 1, yellow: 0, info: 0, skip: 0}, note: null, src: null, tgt: null,
  count_caveat: false, columns: [], findings: [],
  checks: [{id: 'C1', title: 'Tabela', sev: 'red',
            detail: 'tabela ausente no Aurora'}]});
const ui2 = { filter: 'all', q: '', onlyDiff: {},
  open: new Set(['dbo.<img>', 'dbo.only_here', 'dbv.gone']) };
const out = {
  detail2: vm.runInContext('detailHtml', ctx)(run2, ui2),
  tip: vm.runInContext('tipHtml', ctx)(
    'Maiúscula/minúscula de UUID', 'na', 'x <b>y</b>'),
  tipUnknown: vm.runInContext('tipHtml', ctx)('Outra', 'ok', 'tudo certo'),
  tipHoles: vm.runInContext('tipHtml', ctx)(
    'Expurgo: SQL Server Pré Migração', 'info', 'faixas 1..20000'),
  overview: vm.runInContext('overviewHtml', ctx)(input.dbs, input.verifs, ''),
  empty: vm.runInContext('overviewHtml', ctx)([], [], ''),
  detail: vm.runInContext('detailHtml', ctx)(input.payload, ui),
  none: vm.runInContext('detailHtml', ctx)({database: input.dbs[0], run: null}, ui),
  err: vm.runInContext('errorHtml', ctx)('falhou <b>'),
  agg: vm.runInContext('aggregateVerifs', ctx)(
    [{verifs: input.verifs}, {verifs: input.verifs}]),
};
process.stdout.write(JSON.stringify(out));
"""


@pytest.fixture(scope="module")
def rendered():
    if NODE is None:
        pytest.skip("node is not installed")
    payload = {"database": {k: DB[k] for k in ("name", "host_sql", "host_pg", "obs")}}
    payload["run"] = RUN
    data = {"dbs": [DB], "verifs": RUN["verifs"], "payload": payload}
    done = subprocess.run(
        [NODE, "-e", JS, str(MIGRATION)],
        input=json.dumps(data),
        capture_output=True,
        text=True,
        timeout=30,
        check=True,
    )
    return json.loads(done.stdout)


def test_overview_has_ring_legend_bars_and_the_table(rendered):
    out = rendered["overview"]
    assert "<svg" in out and "Precisa de atenção" in out and "Contagem" in out
    assert 'href="#/db/SALES"' in out and "Atenção" in out
    assert "&lt;b&gt;obs&lt;/b&gt;" in out and "<b>obs</b>" not in out
    assert "13/10/2026 12:10" in out


def test_overview_empty_state(rendered):
    assert "Nenhum banco importado ainda" in rendered["empty"]


def test_detail_shows_route_banner_findings_and_columns_but_no_data_measures(rendered):
    out = rendered["detail"]
    for needle in (
        "Origem · antigo",
        "Destino · novo",
        "Pendência no banco · Outro aviso",
        "Mostrar só as 1 com divergência",
        "O que encontramos",
        "Tabela SQL Server",
        "Tabela Aurora",
        'data-f="attention"',
    ):
        assert needle in out, needle
    assert (
        "Conversão" not in out
        and "Resposta do operador" not in out
        and "sem SCT" not in out
    )
    assert '<span class="note-tag">Veio do banco &lt;CDB&gt;</span>' in out
    assert "<CDB>" not in out
    assert re.search(r'<td class="mono">dbo\.only_here</td>', out)
    assert "ausente</span>" not in out
    assert "Medidas" not in out and "Linhas (aprox.)" not in out
    assert "dbo.&lt;img&gt;" in out and "<img>" not in out
    assert "aceita nulo &lt;x&gt;" in out and "aviso &lt;i&gt;" in out
    assert re.search(r'data-more="dbo.&lt;img&gt;"\s*>', out)


def test_detail_without_a_run_and_error_state(rendered):
    assert "ainda não foi validado" in rendered["none"]
    assert "falhou &lt;b&gt;" in rendered["err"] and "falhou <b>" not in rendered["err"]


def test_verifications_are_summed_across_runs(rendered):
    assert rendered["agg"] == [
        {"title": "Contagem", "total": 2, "ok": 2, "yellow": 0, "red": 0, "skip": 0}
    ]


def _section(html, name):
    start = html.index(f'data-more="{name}"')
    end = html.find("<tr", start + 10)
    return html[start : end if end != -1 else len(html)]


def test_the_expanded_row_lists_every_verification_of_the_run(rendered):
    section = _section(rendered["detail2"], "dbo.&lt;img&gt;")
    for title in ("Contagem", "Maiúscula/minúscula de UUID", "Tipos"):
        assert f"<b>{title}</b>" in section
    assert 'class="chk ok"' in section and section.count('class="chk na"') == 2


def test_a_check_that_does_not_apply_is_neutral_and_says_why(rendered):
    section = _section(rendered["detail2"], "dbo.&lt;img&gt;")
    assert "a tabela não tem colunas uniqueidentifier (UUID)" in section
    assert '<span class="sq na"' in section and "–</span>" in section


def test_a_table_missing_in_the_aurora_explains_it_in_every_unchecked_flag(rendered):
    section = _section(rendered["detail2"], "dbv.gone")
    reason = (
        "Não verificado: a tabela não existe no Aurora, então não há o que comparar."
    )
    assert section.count(f'<span class="cd">{reason}</span>') == 3


def test_the_row_flags_carry_what_the_tooltip_needs(rendered):
    out = rendered["detail2"]
    assert 'data-vt="Maiúscula/minúscula de UUID" data-vk="na"' in out
    assert 'tabindex="0" role="img"' in out
    assert re.search(r'<span class="sq [a-z]+" title=', out) is None


def test_the_tooltip_describes_the_check_and_the_result(rendered):
    tip = rendered["tip"]
    assert "<b>Maiúscula/minúscula de UUID</b>" in tip and "uniqueidentifier" in tip
    assert "x &lt;b&gt;y&lt;/b&gt;" in tip and "<b>y</b>" not in tip
    assert (
        "what" not in rendered["tipUnknown"] and "tudo certo" in rendered["tipUnknown"]
    )


def test_new_data_checks_are_described_and_info_has_its_own_flag(rendered):
    tip = rendered["tipHoles"]
    assert "10.000 ids" in tip and "Informativo" in tip
    assert "<b>Expurgo: SQL Server Pré Migração</b>" in tip
    assert '<span class="sq info" aria-hidden="true">i</span>' in tip

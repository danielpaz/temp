"""What the page (static/index.html) and the API must agree on."""

import re
from pathlib import Path

import pytest

from app.adapters.inbound.http import payloads, routers

PAGE = Path(routers.__file__).resolve().parent.parent / "static" / "index.html"


@pytest.fixture(scope="module")
def html() -> str:
    return PAGE.read_text()


@pytest.fixture(scope="module")
def css(html) -> str:
    return html.split("</style>")[0]


def has_all(text, needles):
    missing = [n for n in needles if n not in text]
    assert not missing, missing


def test_the_page_can_stop_one_table_or_all_of_them(html):
    has_all(
        html,
        (
            'id="stopAllBtn"',
            "function stopTables",
            "/api/run/cancel",
            "stopTables([t.key])",
            "Interromper a atualização desta tabela",
            'cancelled: "Interrompida"',
        ),
    )


def test_no_bare_css_class_is_named_like_a_status_chip_state(html):
    """A bare `.pending { ... }` would style every chip in that state."""
    style = re.search(r"<style>(.*?)</style>", html, re.S).group(1)
    selectors = (m for s in re.findall(r"([^{}]+)\{", style) for m in s.split(","))
    bare = {m.strip() for m in selectors if re.fullmatch(r"\s*\.[a-z-]+\s*", m)}
    states = {f".{s}" for s in ("pending", "running", "retrying", "done", "error")}
    assert states & bare == set()


def test_page_has_type_column_with_ddl_hover_and_filter(html):
    has_all(
        html,
        (
            'data-sort="object_type"',
            'id="typeBtn"',
            "function typeCell",
            "object_ddl",
            'id="ddlTip"',
        ),
    )
    assert html.count("colSpan = 10") == 2
    has_all(html, ('"row-active" +', "changes: { enabled: t.enabled === false }"))


def test_page_has_copy_buttons_and_bulk_run_hooks(html):
    has_all(
        html,
        (
            "function copyBtn",
            'copyBtn(t.source_table.toLowerCase(), "tabela transactional")',
            'copyBtn(lower, "tabela analytical")',
            'const UPDATING = "__updating"',
            'id="runStatusBox"',
            "const bulkKeys",
            "tables = bulkKeys()",
        ),
    )
    assert html.count("tabela transactional") == 1, "one copy button per name"


def test_the_page_reads_the_engine_summary_bars(html):
    has_all(
        html,
        (
            "function engineBars",
            "let segSel",
            "segSel.engine",
            "function pctsOf",
            "engine: t.engine || ENGINE_NONE",
        ),
    )


def test_the_page_offers_only_the_two_time_zones(html):
    start = html.index('<select id="editMode">')
    select = html[start : html.index("</select>", start)]
    assert select.count("<option") == 2
    assert 'value="sp">America/Sao_Paulo (padrão)' in select
    assert 'value="utc">UTC' in select
    for gone in ("Automático", 'value="naive"'):
        assert gone not in html


def test_the_page_shows_when_and_in_which_zone_the_last_run_counted(html):
    has_all(
        html,
        (
            "function lastRun",
            'el("span", "runinfo"',
            "Último cálculo",
            "Calculado em",
            "(configurado: ",
        ),
    )


def test_tags_are_one_compact_chip_so_the_row_keeps_its_height(html):
    has_all(html, ("function tagChip", "[tagChip(t.tags)]"))
    assert 'el("span", "tag", g)' not in html


def test_the_top_of_the_page_counts_tables_per_tag(html):
    has_all(
        html,
        (
            'id="tagTotals"',
            "function renderTagTotals",
            "renderTagTotals(tagScope)",
            'tagFilter.value = tagFilter.value === g ? "" : g',
            "sem tag",
        ),
    )


def test_a_link_with_filters_opens_the_page_and_the_page_reads_them(html):
    has_all(
        html,
        (
            "function readUrlFilters",
            "function writeUrlFilters",
            "history.replaceState",
            'id="copyLinkBtn"',
            'u.get("tag")',
            'u.get("status")',
        ),
    )


def test_the_page_grows_with_the_window_and_keeps_a_margin(css):
    assert "max-width: 1760px" not in css
    assert "padding: 32px clamp(16px, 2.5vw, 56px)" in css


def test_titles_stay_on_one_line_with_the_filter_beside_them(css):
    assert "th { white-space: nowrap; }" in css
    assert "th.num { white-space: normal; }" not in css
    assert "table-layout: fixed" in css
    for n in range(3, 11):
        assert f"th:nth-child({n}) {{ width:" in css, f"column {n} has no width"


def test_a_cell_never_paints_over_the_next_column(html, css):
    assert "tbody td { overflow: hidden; }" in css
    has_all(
        css,
        (
            ".name-body { flex: 1 1 auto; min-width: 0; }",
            ".name-meta { display: inline-flex;",
            "td.datecol:not(.rangecol) { white-space: normal;",
        ),
    )
    assert "nameWrap.append(btn, body);" in html


def test_a_bulk_run_can_name_every_table():
    assert payloads.RUN_BODY_LIMIT >= 500 * 200


def test_the_page_has_the_filter_group_column_and_the_id_kind(html):
    has_all(
        html,
        (
            "Filter/Group Column",
            'id="editKind"',
            '<option value="id">ID</option>',
            "function syncKind",
            "Comparação por ID:",
            "filter_kind: editKind.value",
            "changes.filter_kind",
            "KIND_TEXT",
            "Filtro/agrupamento",
        ),
    )
    assert ">Date Column<" not in html


def test_the_page_opens_the_definition_in_a_dialog_with_ddl_and_indexes(html):
    has_all(
        html,
        (
            'id="srcDialog"',
            "function ddlBtn",
            "function openSource",
            "/api/ddl?table=",
            'id="tabIdx"',
            "function renderIndexes",
            "varre a tabela inteira",
            "table-layout: fixed",
        ),
    )
    name_rule = html.split("</style>")[0].split(".name {")[1].split("}")[0]
    assert "overflow-wrap: anywhere" not in name_rule


def test_the_page_explains_it_when_the_row_is_opened(html):
    assert (
        "Esta tabela não possui date column e por isso a comparação é realizada "
        "sobre o volume total da tabela."
    ) in html

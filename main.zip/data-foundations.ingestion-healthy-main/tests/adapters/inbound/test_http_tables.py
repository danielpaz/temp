import pytest

from app.domain.exceptions import Duplicate, InvalidRequest, NotFound
from tests.support.http_theme import DEFINITION, Rig

KEY = "a.b.c@d.e.f"


@pytest.fixture
def rig():
    return Rig()


@pytest.fixture
def client(rig):
    return rig.client


def test_ddl_endpoint_returns_the_definition(rig):
    rig.queries.found = DEFINITION
    reply = rig.client.get("/api/ddl", params={"table": KEY})
    assert reply.status_code == 200
    assert reply.json() == {
        "table": KEY,
        "ddl": "CREATE TABLE ...",
        "indexes": [],
        "columns": 1,
        "checked_at": None,
        "filter_column": None,
    }


def test_ddl_not_yet_read_or_unknown_table_is_404(rig):
    assert rig.client.get("/api/ddl", params={"table": KEY}).status_code == 404
    rig.queries.error = NotFound("Tabela desconhecida.")
    assert rig.client.get("/api/ddl", params={"table": KEY}).status_code == 404


def test_ddl_with_a_malformed_key_is_400(client):
    assert client.get("/api/ddl?table=zz").status_code == 400


@pytest.mark.parametrize("path", ["/", "/?tag=core_entity&status=Diferente"])
def test_the_page_opens_with_a_query_string(client, path):
    assert client.get(path).status_code == 200


def test_the_page_opens_with_a_query_on_index_and_unknown_path_is_404(client):
    assert client.get("/index.html?q=pix").status_code == 200
    assert client.get("/nope?x=1").status_code == 404


def test_edit_returns_what_changed_and_checks_an_edited_secret(rig):
    body = {"table": KEY, "changes": {"tags": ["x"]}, "actor": "ana"}
    reply = rig.client.post("/api/table", json=body)
    assert (reply.status_code, reply.json()) == (200, {"changed": ["tags"]})
    name, key, changes, actor = rig.registry.calls[0]
    assert (name, str(key), changes.tags, actor) == ("update", KEY, ["x"], "ana")
    secret = {"table": KEY, "changes": {"used_secret": "prod/x/B"}}
    assert rig.client.post("/api/table", json=secret).status_code == 200
    assert rig.hosts == ["h1.example"], "an edited secret is checked before saving"
    assert rig.secrets.asked == ["prod/x/B"]


@pytest.mark.parametrize(
    "error, code",
    [(Duplicate("dup"), 409), (InvalidRequest("ruim"), 400), (NotFound("nao"), 404)],
)
def test_edit_maps_registry_outcomes_to_status_codes(rig, error, code):
    rig.registry.fail = error
    reply = rig.client.post(
        "/api/table", json={"table": KEY, "changes": {"enabled": True}}
    )
    assert reply.status_code == code and reply.json() == {"error": str(error)}


def test_edit_without_changes_is_400(client):
    assert client.post("/api/table", json={"table": KEY}).status_code == 400


NEW = {
    "source_database": "A",
    "source_schema": "p",
    "source_table": "t",
    "target_catalog": "c",
    "target_schema": "s",
    "target_table": "t",
    "used_secret": "prod/x/B",
}


def test_create_returns_201_with_id_and_key(rig):
    reply = rig.client.post("/api/table/create", json={"fields": NEW, "actor": "ana"})
    assert reply.status_code == 201
    assert reply.json() == {"id": 7, "table": "A.p.t@c.s.t"}
    name, new, host, actor = rig.registry.calls[0]
    assert (name, host, actor) == ("create", "h1.example", "ana")


def test_create_duplicate_is_409_and_without_fields_is_400(rig):
    rig.registry.fail = Duplicate("dup")
    assert rig.client.post("/api/table/create", json={"fields": NEW}).status_code == 409
    assert rig.client.post("/api/table/create", json={}).status_code == 400


def test_delete_returns_the_key(rig):
    reply = rig.client.post("/api/table/delete", json={"table": KEY, "actor": "ana"})
    assert (reply.status_code, reply.json()) == (200, {"deleted": KEY})
    assert [c[0] for c in rig.registry.calls] == ["delete"]


def test_a_table_in_a_run_cannot_be_deleted(rig):
    rig.hold_runs()
    run_id = rig.world.start.execute(
        "2026-09-10", "2026-09-11", ["DB2.dbo.t3@trusted_zone.trusted_db2.dbo_t3"]
    )
    reply = rig.client.post(
        "/api/table/delete",
        json={"table": "DB2.dbo.t3@trusted_zone.trusted_db2.dbo_t3"},
    )
    assert reply.status_code == 409
    assert "em atualização" in reply.json()["error"]
    assert rig.registry.calls == []
    rig.world.cancel.execute()
    rig.world.run_to_end(run_id)


def test_deleting_is_refused_when_the_runs_cannot_be_checked(rig):
    def broken():
        raise RuntimeError("sem cluster")

    rig.world.states.list = broken
    reply = rig.client.post("/api/table/delete", json={"table": KEY})
    assert reply.status_code >= 500
    assert rig.registry.calls == []

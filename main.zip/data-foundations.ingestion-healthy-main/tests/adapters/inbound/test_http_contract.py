import pytest
from fastapi.testclient import TestClient

from app.adapters.inbound.http.app import create_app
from app.adapters.inbound.http.services import HttpServices
from app.application.use_cases.migration_commands import (
    GetMigrationValidation,
    ImportMigrationDatabases,
    ListMigrationOverview,
    RegisterValidation,
)
from app.application.use_cases.registry_commands import (
    CreateTable,
    DeleteTable,
    EditTable,
    GetSourceDefinition,
    ListAudit,
    ListResults,
    ListTags,
)
from tests.support.migration_fakes import MemoryMigrationValidations
from tests.support.world import World

JSON = {"Content-Type": "application/json"}


@pytest.fixture
def client():
    world = World()
    services = HttpServices(
        start_run=world.start,
        cancel_run=world.cancel,
        run_status=world.status,
        list_results=ListResults(None),
        list_tags=ListTags(None),
        list_audit=ListAudit(None),
        source_definition=GetSourceDefinition(None),
        create_table=CreateTable(world.registry, None),
        edit_table=EditTable(world.registry, None),
        delete_table=DeleteTable(world.registry, world.busy),
        import_migration_databases=ImportMigrationDatabases(
            MemoryMigrationValidations()
        ),
        register_validation=RegisterValidation(MemoryMigrationValidations()),
        migration_overview=ListMigrationOverview(MemoryMigrationValidations()),
        migration_validation=GetMigrationValidation(MemoryMigrationValidations()),
    )
    return TestClient(create_app(services), raise_server_exceptions=False)


def test_pages_and_health(client):
    assert client.get("/healthz").text == "ok"
    assert "<html" in client.get("/?tag=core_entity&status=Diferente").text.lower()
    assert client.get("/index.html").status_code == 200


def test_post_requires_json(client):
    assert client.post("/api/run", content=b"{}").status_code == 415


def test_post_rejects_big_and_invalid_bodies(client):
    big = b'{"x":"' + b"a" * 5000 + b'"}'
    assert client.post("/api/table", content=big, headers=JSON).status_code == 413
    assert client.post("/api/run", content=b"nope", headers=JSON).status_code == 400


def test_invalid_period_is_400_with_error_key(client):
    reply = client.post("/api/run", json={"from": "x", "to": "y"})
    assert reply.status_code == 400 and "error" in reply.json()


def test_tables_must_be_a_list_of_strings(client):
    reply = client.post("/api/run", json={"tables": [1]})
    assert reply.status_code == 400


def test_cancel_without_run_is_conflict(client):
    assert client.post("/api/run/cancel", json={}).status_code == 409


def test_start_returns_202_and_status_is_served(client):
    reply = client.post("/api/run", json={"from": "2026-09-10", "to": "2026-09-11"})
    assert reply.status_code == 202 and reply.json()["run_id"]
    assert client.get("/api/run").status_code == 200


def test_unknown_path_is_404(client):
    assert client.get("/nope").status_code == 404


def test_status_failure_does_not_leak_the_exception():
    def boom():
        raise RuntimeError("secret-host.internal refused")

    world = World()
    world.status.execute = boom
    services = HttpServices(
        start_run=world.start,
        cancel_run=world.cancel,
        run_status=world.status,
        list_results=ListResults(None),
        list_tags=ListTags(None),
        list_audit=ListAudit(None),
        source_definition=GetSourceDefinition(None),
        create_table=CreateTable(world.registry, None),
        edit_table=EditTable(world.registry, None),
        delete_table=DeleteTable(world.registry, world.busy),
        import_migration_databases=ImportMigrationDatabases(
            MemoryMigrationValidations()
        ),
        register_validation=RegisterValidation(MemoryMigrationValidations()),
        migration_overview=ListMigrationOverview(MemoryMigrationValidations()),
        migration_validation=GetMigrationValidation(MemoryMigrationValidations()),
    )
    reply = TestClient(create_app(services)).get("/api/run").json()
    assert reply["status"] == "unavailable"
    assert "secret-host" not in reply["message"]

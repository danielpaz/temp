import datetime as dt

import pytest

from app.adapters.outbound.kubernetes.pod_builder import WorkerPodSpec
from app.adapters.outbound.kubernetes.run_state_store import (
    ConfigMapRunStateStore,
    from_data,
    to_data,
)
from app.adapters.outbound.kubernetes.worker_pods import KubernetesWorkerPods
from app.application.ports.cluster import WorkerLaunch
from app.domain.exceptions import Conflict
from app.domain.progress import Chunks, TableState
from app.domain.run import PodInfo, RunState, RunStatus, TableRun
from tests.support.fakes import PERIOD


class FakeKube:
    def __init__(self):
        self.pods = {}
        self.maps = {}
        self.selectors = []

    def create_pod(self, manifest):
        self.pods[manifest["metadata"]["name"]] = manifest

    def delete_pod(self, name):
        self.pods.pop(name, None)

    def list_pods(self, selector):
        self.selectors.append(selector)
        run = selector.rsplit("=", 1)[1]
        return [
            PodInfo(n, "Running", "", 1.0)
            for n, m in self.pods.items()
            if m["metadata"]["labels"]["run-id"] == run
        ]

    def list_config_maps(self, selector):
        return [d for _, d in self.maps.values()]

    def create_config_map(self, name, labels, data):
        if name in self.maps:
            raise Conflict("exists")
        self.maps[name] = (labels, data)

    def replace_config_map(self, name, labels, data):
        self.maps[name] = (labels, data)

    def delete_config_map(self, name):
        self.maps.pop(name, None)


def launch(run, wid, attempt=1):
    return WorkerLaunch(run, wid, attempt, f"ih-{run}-{wid}-a{attempt}", "H", "s")


def make_state(run_id="r1") -> RunState:
    state = RunState(run_id, PERIOD, 10.0, 11.0, merge=True)
    state.status = RunStatus.COMPLETED_WITH_ERRORS
    state.finished_at = 20.0
    state.message = "ok"
    state.workers = {"w1": {"host": "A", "attempt": 1, "state": "done"}}
    state.tables = {
        "k1": TableRun(TableState.RUNNING, 1, "", Chunks(1, 3), True),
        "k2": TableRun(TableState.ERROR, 2, "boom"),
    }
    state.published = 2
    return state


def test_state_mapping_round_trip():
    state = make_state()
    state.counts.total = 2
    assert from_data(to_data(state)).snapshot() == state.snapshot()


def test_period_survives_the_mapping():
    restored = from_data(to_data(make_state()))
    assert restored.period.start == dt.date(2026, 9, 10)


def test_store_create_list_replace_delete():
    kube = FakeKube()
    store = ConfigMapRunStateStore(kube)
    store.create(make_state("r1"))
    assert list(kube.maps) == ["ih-state-r1"]
    assert kube.maps["ih-state-r1"][0] == {"app": "ingestion-healthy-state"}
    changed = make_state("r1")
    changed.message = "new"
    store.replace(changed)
    assert [s.message for s in store.list()] == ["new"]
    store.delete("r1")
    assert store.list() == []


def test_create_twice_conflicts():
    store = ConfigMapRunStateStore(FakeKube())
    store.create(make_state())
    with pytest.raises(Conflict):
        store.create(make_state())


def test_list_skips_maps_without_state():
    kube = FakeKube()
    kube.maps["x"] = ({}, {"other": "1"})
    assert ConfigMapRunStateStore(kube).list() == []


def test_pods_launch_list_delete():
    kube = FakeKube()
    pods = KubernetesWorkerPods(kube, WorkerPodSpec(image="img"))
    pods.launch(launch("r1", "w1"))
    pods.launch(launch("r1", "w2"))
    pods.launch(launch("r2", "w1"))
    assert sorted(p.name for p in pods.list("r1")) == ["ih-r1-w1-a1", "ih-r1-w2-a1"]
    pods.delete("ih-r1-w1-a1")
    pods.delete("ih-r1-w1-a1")
    pods.delete_run("r1")
    assert list(kube.pods) == ["ih-r2-w1-a1"]
    assert kube.selectors[0] == "app=ingestion-healthy-worker,run-id=r1"

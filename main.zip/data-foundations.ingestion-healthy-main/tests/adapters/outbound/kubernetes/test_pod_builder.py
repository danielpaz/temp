from app.adapters.outbound.kubernetes.pod_builder import (
    WorkerPodBuilder,
    WorkerPodSpec,
)
from app.application.ports.cluster import WorkerLaunch

LAUNCH = WorkerLaunch("r1", "w1", 2, "ih-r1-w1-a2", "HOST", "prod/x/a")


def build(**env):
    spec = WorkerPodSpec(image="img:1", forwarded_env=env)
    return WorkerPodBuilder(spec).build(LAUNCH)


def env_of(pod):
    return {e["name"]: e["value"] for e in pod["spec"]["containers"][0]["env"]}


def test_metadata():
    meta = build()["metadata"]
    assert meta["name"] == "ih-r1-w1-a2"
    assert meta["labels"] == {
        "app": "ingestion-healthy-worker",
        "run-id": "r1",
        "worker": "w1",
    }
    assert meta["annotations"] == {"karpenter.sh/do-not-disrupt": "true"}


def test_container():
    pod = build()
    container = pod["spec"]["containers"][0]
    assert container["image"] == "img:1"
    assert container["command"] == ["python", "-m", "app.adapters.inbound.worker"]
    assert container["resources"]["requests"]["memory"] == "512Mi"
    assert container["resources"]["limits"] == {"memory": "4Gi"}


def test_pod_spec():
    spec = build()["spec"]
    assert spec["restartPolicy"] == "Never"
    assert spec["serviceAccountName"] == "ingestion-healthy"


def test_env_carries_the_launch():
    env = env_of(build())
    assert env["RUN_ID"] == "r1"
    assert env["WORKER_ID"] == "w1"
    assert env["WORKER_HOST"] == "HOST"
    assert env["WORKER_SECRET"] == "prod/x/a"
    assert env["POD_ATTEMPT"] == "2"


def test_forwarded_env_cannot_override_the_launch():
    env = env_of(build(TRINO_HOST="t", RUN_ID="evil"))
    assert env["TRINO_HOST"] == "t"
    assert env["RUN_ID"] == "r1"

"""What every worker pod must look like, whatever the run."""

from app.adapters.outbound.kubernetes.pod_builder import (
    WorkerPodBuilder,
    WorkerPodSpec,
)
from app.application.ports.cluster import WorkerLaunch
from app.config.settings import Settings
from tests.support.world import World, start_all


def env_of(pod: dict) -> dict:
    return {e["name"]: e["value"] for e in pod["spec"]["containers"][0]["env"]}


def build(launch: WorkerLaunch, **spec) -> dict:
    return WorkerPodBuilder(WorkerPodSpec(image="img:1", **spec)).build(launch)


def launches() -> list:
    world = World()
    world.run_to_end(start_all(world))
    return world.pods.launched


def test_every_pod_of_a_run_carries_its_run_host_and_isolation():
    launched = launches()
    assert len(launched) == 3
    for launch in launched:
        pod = build(launch)
        spec = pod["spec"]
        env = env_of(pod)
        assert env["RUN_ID"] == launch.run_id
        assert env["WORKER_HOST"] == launch.host
        assert pod["metadata"]["labels"]["run-id"] == launch.run_id
        assert spec["restartPolicy"] == "Never"
        assert spec["serviceAccountName"] == "ingestion-healthy"
        assert spec["securityContext"]["runAsNonRoot"] is True
        assert "activeDeadlineSeconds" in spec


def test_pods_are_protected_from_node_consolidation():
    for launch in launches():
        annotations = build(launch)["metadata"]["annotations"]
        assert annotations["karpenter.sh/do-not-disrupt"] == "true"


def test_the_memory_of_the_pod_is_configurable():
    launch = launches()[0]
    default = build(launch)["spec"]["containers"][0]["resources"]
    assert default["requests"]["memory"] == "512Mi"
    assert default["limits"]["memory"] == "4Gi"
    custom = build(launch, memory_limit="6Gi")["spec"]["containers"][0]
    assert custom["resources"]["limits"]["memory"] == "6Gi"


def test_the_memory_settings_reach_the_pod_spec():
    from app.bootstrap.container import _pod_spec

    spec = _pod_spec(Settings(worker_memory_limit="6Gi", worker_image="i"))
    assert (spec.memory_request, spec.memory_limit) == ("512Mi", "6Gi")


def test_the_trino_host_setting_is_passed_to_every_worker_pod():
    forwarded = Settings(trino_host="new.example").forwarded_env()
    assert forwarded["TRINO_HOST"] == "new.example"
    for launch in launches():
        assert (
            env_of(build(launch, forwarded_env=forwarded))["TRINO_HOST"]
            == "new.example"
        )


def test_an_empty_trino_host_is_not_forwarded():
    assert "TRINO_HOST" not in Settings(trino_host="").forwarded_env()

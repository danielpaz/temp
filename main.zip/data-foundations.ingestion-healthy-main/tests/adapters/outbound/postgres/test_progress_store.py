import contextlib
import datetime as dt

import pytest

from app.adapters.outbound.postgres import progress_codec as codec
from app.adapters.outbound.postgres.progress_store import PostgresProgressStore
from app.domain.exceptions import NotFound
from app.domain.progress import RunPlan, WorkerProgress
from app.domain.values import Period
from tests.support.fakes import make_table

PERIOD = Period(dt.date(2026, 9, 10), dt.date(2026, 9, 11))


class Cursor:
    def __init__(self, rows=()):
        self.calls = []
        self.rows = list(rows)

    def execute(self, query, params=None):
        self.calls.append((query, params))

    def fetchone(self):
        return self.rows[0] if self.rows else None

    def fetchall(self):
        return self.rows


class Connections:
    def __init__(self, rows=()):
        self.cur = Cursor(rows)

    @contextlib.contextmanager
    def transaction(self):
        yield self.cur


def _store(rows=()):
    connections = Connections(rows)
    return PostgresProgressStore(connections), connections.cur


def test_saving_a_plan_purges_old_runs_first_and_upserts_the_plan():
    store, cur = _store()
    store.save_plan(RunPlan("r1", PERIOD, [make_table()], False))
    purge, insert = cur.calls
    assert "DELETE FROM run_plan" in purge[0] and "7 days" in purge[0]
    assert "INSERT INTO run_plan" in insert[0] and insert[1][0] == "r1"


def test_a_plan_round_trips_through_the_codec():
    plan = RunPlan("r1", PERIOD, [make_table()], True)
    store, _ = _store([{"body": codec.plan_to(plan)}])
    loaded = store.load_plan("r1")
    assert loaded.run_id == "r1" and loaded.merge is True
    assert [str(t.key) for t in loaded.tables] == [str(t.key) for t in plan.tables]


def test_a_missing_plan_is_not_found():
    store, _ = _store()
    with pytest.raises(NotFound):
        store.load_plan("nope")


def test_worker_progress_is_upserted_and_read_back():
    progress = WorkerProgress("w1", "A", "1")
    store, cur = _store()
    store.save_worker("r1", progress)
    query, args = cur.calls[0]
    assert "ON CONFLICT (run_id, worker_id) DO UPDATE" in query
    assert args[:2] == ("r1", "w1")
    reader, _ = _store([{"body": codec.worker_to(progress)}])
    assert reader.load_worker("r1", "w1").worker_id == "w1"


def test_a_worker_that_has_not_reported_is_none():
    store, _ = _store()
    assert store.load_worker("r1", "w1") is None


def test_cancel_requests_are_inserted_once_per_table_and_read_as_a_set():
    store, cur = _store()
    store.request_cancel("r1", {"b", "a"})
    assert [c[1] for c in cur.calls] == [("r1", "a"), ("r1", "b")]
    assert all("ON CONFLICT DO NOTHING" in c[0] for c in cur.calls)
    reader, _ = _store([{"table_key": "a"}, {"table_key": "b"}])
    assert reader.cancelled("r1") == {"a", "b"}

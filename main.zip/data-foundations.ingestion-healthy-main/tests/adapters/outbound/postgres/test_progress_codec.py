import datetime as dt

from app.adapters.outbound.postgres import progress_codec as codec
from app.domain.comparison import (
    ComparisonResult,
    DayCount,
    LakeObject,
    OriginDefinition,
    TableFacts,
)
from app.domain.progress import (
    Chunks,
    RunPlan,
    TableProgress,
    TableState,
    WorkerProgress,
)
from app.domain.values import (
    Basis,
    DayMode,
    FilterKind,
    ObjectType,
    ResultStatus,
)
from tests.support.fakes import PERIOD, make_table


def full_facts() -> TableFacts:
    return TableFacts(
        lake_object=LakeObject(ObjectType.VIEW, "create view"),
        lake_column_type="timestamp(3)",
        origin_size_bytes=1024,
        origin_definition=OriginDefinition("create table", [{"n": "ix"}], 3),
        origin_read=True,
    )


def full_result() -> ComparisonResult:
    table = make_table()
    days = [DayCount(PERIOD.start, 5, 5), DayCount(PERIOD.end, 4, 6)]
    return ComparisonResult(
        key=table.key,
        status=ResultStatus.DIFFERENT,
        period=PERIOD,
        basis=Basis.SAO_PAULO,
        filter_column="created_at_dt",
        days=days,
        origin_total=9,
        lake_total=11,
        last_id=7,
        error="x",
        facts=full_facts(),
    )


def test_table_round_trip():
    table = make_table(kind=FilterKind.ID, mode=DayMode.UTC, table_id=4)
    assert codec.table_from(codec.table_to(table)) == table


def test_table_without_column_round_trip():
    table = make_table(column=None, enabled=False)
    assert codec.table_from(codec.table_to(table)) == table


def test_plan_round_trip():
    plan = RunPlan("r1", PERIOD, [make_table(), make_table(table="t2")], True)
    assert codec.plan_from(codec.plan_to(plan)) == plan


def test_facts_round_trip():
    assert codec.facts_from(codec.facts_to(full_facts())) == full_facts()


def test_empty_facts_round_trip():
    assert codec.facts_from(codec.facts_to(TableFacts())) == TableFacts()


def test_result_round_trip():
    result = full_result()
    assert codec.result_from(codec.result_to(result)) == result


def test_minimal_result_round_trip():
    result = ComparisonResult(make_table().key, ResultStatus.ERROR, PERIOD)
    assert codec.result_from(codec.result_to(result)) == result


def test_worker_round_trip():
    progress = WorkerProgress(
        "w1",
        "A",
        "2",
        state="done",
        updated=12.5,
        tables={
            "k1": TableProgress(TableState.DONE, 1),
            "k2": TableProgress(TableState.RUNNING, 2, "boom", Chunks(1, 4)),
        },
        results={"k1": full_result()},
        partial={"k2": {"days": ["2026-09-10"]}},
    )
    assert codec.worker_from(codec.worker_to(progress)) == progress


def test_worker_keeps_the_old_keys():
    data = codec.worker_to(WorkerProgress("w1", "A", "1"))
    old = {"worker_id", "host", "pod_attempt", "state", "updated", "tables", "partial"}
    assert old <= set(data)


def test_result_day_is_iso():
    day = codec.result_to(full_result())["days"][0]["day"]
    assert dt.date.fromisoformat(day) == PERIOD.start


def test_cancel_round_trip():
    assert codec.cancel_from(codec.cancel_to({"b", "a"})) == {"a", "b"}

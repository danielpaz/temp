"""Publishing results: the mode columns travel with the row, old rows are kept."""

import contextlib
import datetime as dt

from app.adapters.outbound.postgres import result_store
from app.adapters.outbound.postgres.result_store import PostgresResultStore
from app.domain.comparison import (
    ComparisonResult,
    LakeObject,
    ObjectType,
    OriginDefinition,
    TableFacts,
)
from app.domain.entities import MonitoredTable
from app.domain.values import Period, TableKey

KEY = TableKey.parse("DB2.dbo.t3@trusted_zone.trusted_db2.dbo_t3")
PERIOD = Period(dt.date(2026, 9, 16), dt.date(2026, 9, 17))


class Cursor:
    def __init__(self):
        self.calls = []

    def execute(self, query, params=None):
        self.calls.append((query, params))


@contextlib.contextmanager
def _scope(cur):
    yield cur


class Connections:
    def __init__(self):
        self.cur = Cursor()

    def transaction(self):
        return _scope(self.cur)


def publish(table, result, monkeypatch):
    connections = Connections()
    monkeypatch.setattr(
        result_store,
        "execute_values",
        lambda cur, query, rows, page_size: cur.calls.append((query, rows)),
    )
    PostgresResultStore(connections).publish("r1", [(table, result)])  # type: ignore
    return connections.cur.calls


def test_a_daily_result_publishes_its_mode_and_keeps_the_stored_mode_source(
    monkeypatch,
):
    table = MonitoredTable(
        key=KEY, secret="s", host="h", id=3, day_mode="sp", filter_column="d"
    )
    result = ComparisonResult.daily(
        table, PERIOD, {PERIOD.start: 5}, {PERIOD.start: 5}, TableFacts()
    )
    calls = publish(table, result, monkeypatch)
    current, history = calls[0], calls[1]
    for query, params in (current, history):
        assert "day_mode" in query and "mode_source" in query
        # the mode source is read from the registry row, not overwritten
        assert "(SELECT mode_source FROM monitored_table WHERE id = %s)" in query
        assert len(params) == 15 and params[0] == params[7] == 3
        assert params[6] == "sp" and params[5] == "d"
    assert "table_result_history" in history[0]
    days = calls[3][1]
    assert days[0][1:4] == (PERIOD.start, 5, 5)


def test_a_table_without_a_date_column_publishes_total_basis_and_no_days(
    monkeypatch,
):
    table = MonitoredTable(key=KEY, secret="s", host="h", id=3)
    result = ComparisonResult.whole_table(table, PERIOD, 100, 90, TableFacts())
    calls = publish(table, result, monkeypatch)
    params = calls[0][1]
    assert (params[4], params[5], params[6], params[8]) == (
        "Diferente",
        None,
        "total",
        None,
    )
    assert (params[10], params[11], params[12]) == (100, 90, -10)
    assert calls[2][0].startswith("DELETE FROM table_result_day")


def test_facts_are_stored_with_the_table(monkeypatch):
    table = MonitoredTable(key=KEY, secret="s", host="h", id=3)
    facts = TableFacts(
        origin_size_bytes=1234,
        origin_definition=OriginDefinition("CREATE TABLE t ();", [], 3),
        lake_object=LakeObject(ObjectType.VIEW, "CREATE VIEW v"),
        lake_column_type="timestamp(3)",
    )
    result = ComparisonResult.whole_table(table, PERIOD, 1, 1, facts)
    updates = [c for c in publish(table, result, monkeypatch) if "UPDATE" in c[0]]
    by_column = {c[0].split("SET ")[1].split("=")[0]: c[1] for c in updates}
    assert by_column["source_ddl"][0] == "CREATE TABLE t ();"
    assert by_column["source_ddl"][2] == 3
    assert by_column["source_size_bytes"] == (1234, 3)
    assert by_column["trino_object_type"][1] == "CREATE VIEW v"
    assert by_column["trino_col_type"] == ("timestamp(3)", 3)

import contextlib
import datetime as dt

from app.adapters.outbound.postgres.migration_validations import (
    PostgresMigrationValidations,
)
from app.domain.migration import MigrationDatabase
from app.domain.migration_document import from_document
from tests.support.migration_fakes import sample_document


class Cursor:
    def __init__(self, rows=()):
        self.calls = []
        self.rows = list(rows)

    def execute(self, query, params=None):
        self.calls.append((query, params))

    def fetchone(self):
        return self.rows[0] if self.rows else None

    def fetchall(self):
        return self.rows


class Connections:
    def __init__(self, rows=()):
        self.cur = Cursor(rows)

    @contextlib.contextmanager
    def transaction(self):
        yield self.cur


def _store(rows=()):
    connections = Connections(rows)
    return PostgresMigrationValidations(connections), connections.cur


def test_databases_are_upserted_and_counted():
    store, cur = _store()
    items = [MigrationDatabase("A", "h1", "p1", "n"), MigrationDatabase("B")]
    assert store.upsert_databases(items) == 2
    assert all("ON CONFLICT (name) DO UPDATE" in c[0] for c in cur.calls)
    assert cur.calls[0][1] == ("A", "h1", "p1", "n")


def test_a_database_is_read_or_none():
    row = {"name": "A", "host_sql": "h", "host_postgresql": "p", "note": "n"}
    found, _ = _store([row])
    assert found.database("A") == MigrationDatabase("A", "h", "p", "n")
    missing, _ = _store()
    assert missing.database("A") is None


def test_saving_a_run_stores_summary_columns_and_the_document():
    run = from_document(sample_document("A"))
    store, cur = _store([{"id": 7}])
    assert store.save_run(run, "bruno") == 7
    query, args = cur.calls[0]
    assert "RETURNING id" in query
    assert args[0] == "A" and args[-1] == "bruno"
    assert args[5:9] == (
        run.counts.attention,
        run.counts.review,
        run.counts.ok,
        run.counts.total,
    )
    assert from_document(args[10].adapted) == run


def test_latest_run_orders_newest_first_and_parses_the_document():
    doc = sample_document("A")
    store, cur = _store([{"report": doc}])
    run = store.latest_run("A")
    assert run == from_document(doc)
    assert "ORDER BY registered_at DESC, id DESC" in cur.calls[0][0]


def test_latest_run_is_none_without_runs():
    store, _ = _store()
    assert store.latest_run("A") is None


def test_overview_is_one_query_that_does_not_read_the_report():
    when = dt.datetime(2026, 10, 13, 15, 10, tzinfo=dt.timezone.utc)
    base = {"name": "A", "host_sql": "h", "host_postgresql": "p", "note": ""}
    validated = dict(
        base,
        attention=1,
        review=2,
        ok=3,
        captured_at=when,
        teleport_sql="t",
        teleport_sql_uri=None,
        teleport_aurora="a",
    )
    pending = dict(
        base,
        name="B",
        attention=None,
        review=None,
        ok=None,
        captured_at=None,
        teleport_sql=None,
        teleport_sql_uri=None,
        teleport_aurora=None,
    )
    store, cur = _store([validated, pending])
    first, second = store.overview()
    assert len(cur.calls) == 1
    assert "report" not in cur.calls[0][0] and "ORDER BY d.name" in cur.calls[0][0]
    assert first.validated and first.counts.total == 6
    assert (first.teleport_sql, first.teleport_sql_uri) == ("t", "")
    assert first.captured_at == when
    assert not second.validated and second.teleport_aurora == ""

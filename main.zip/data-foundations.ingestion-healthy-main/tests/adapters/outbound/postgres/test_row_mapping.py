import datetime as dt

from app.adapters.outbound.postgres.row_mapping import (
    deleted_table_name,
    group_days,
    is_config_pending,
    to_audit_entry,
    to_overview,
)
from app.domain.values import ObjectType, ResultStatus

T0 = dt.datetime(2026, 1, 1, 10)


def row(**over):
    base = {
        "id": 1,
        "source_database": "db",
        "source_schema": "public",
        "source_table": "t",
        "target_catalog": "c",
        "target_schema": "s",
        "target_table": "t",
        "host": "h",
        "secret": "sec",
        "date_field": "created_at",
        "trino_col_type": None,
        "trino_day_mode": "sp",
        "mode_source": None,
        "enabled": True,
        "config_changed_at": None,
        "object_type": "VIEW",
        "object_ddl": "",
        "object_checked_at": None,
        "source_size_bytes": None,
        "filter_kind": "date",
        "last_id": None,
        "has_ddl": False,
        "col_count": None,
        "index_count": None,
        "pk_columns": None,
        "field_indexed": None,
        "status": "Igual",
        "period_from": dt.date(2026, 1, 1),
        "period_to": dt.date(2026, 1, 2),
        "result_field": "created_at",
        "result_day_mode": "sp",
        "source_total": 3,
        "trino_total": 3,
        "diff": 0,
        "error": None,
        "computed_at": T0,
        "tags": ["x"],
    }
    return {**base, **over}


def test_overview_maps_result_and_key():
    view = to_overview(row(), [])
    assert str(view.key) == "db.public.t@c.s.t"
    assert view.status is ResultStatus.EQUAL
    assert view.object_type is ObjectType.VIEW and view.object_ddl is None
    assert view.period and view.period.size == 2
    assert not view.config_pending and view.tags == ["x"]


def test_overview_without_result_is_error():
    empty = row(status=None, computed_at=None, period_from=None)
    assert to_overview(empty, []).error == "Ainda não calculada."
    off = to_overview({**empty, "enabled": False}, [])
    assert off.error == "Tabela desativada." and off.period is None


def test_pending_rules():
    assert is_config_pending(row(config_changed_at=T0 + dt.timedelta(hours=1)))
    assert is_config_pending(row(date_field="other"))
    assert is_config_pending(row(trino_day_mode="utc"))
    assert not is_config_pending(
        row(trino_day_mode="utc", filter_kind="id", result_day_mode="total")
    )
    assert is_config_pending(row(filter_kind="id"))
    assert not is_config_pending(row(computed_at=None, date_field="other"))


def test_group_days():
    rows = [
        {"table_id": 1, "day": dt.date(2026, 1, 1), "source_count": 2, "trino_count": 3}
    ]
    assert group_days(rows)[1][0].diff == 1


def test_deleted_table_name_from_snapshot():
    snap = (
        '{"source_database":"a","source_schema":"b","source_table":"c",'
        '"target_catalog":"d","target_schema":"e","target_table":"f"}'
    )
    assert deleted_table_name(snap) == "a.b.c@d.e.f"
    assert deleted_table_name("not json") is None


def test_audit_entry_recovers_deleted_table():
    snap = (
        '{"source_database":"a","source_schema":"b","source_table":"c",'
        '"target_catalog":"d","target_schema":"e","target_table":"f"}'
    )
    entry = to_audit_entry(
        {
            "at": T0,
            "actor": "x",
            "action": "delete",
            "field": "table",
            "old_value": snap,
            "new_value": None,
            "table_key": None,
        }
    )
    assert entry.table == "a.b.c@d.e.f"

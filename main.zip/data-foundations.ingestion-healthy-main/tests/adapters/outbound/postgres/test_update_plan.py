from app.adapters.outbound.postgres.update_plan import plan_update, tag_diff
from app.domain.registry_rules import TableChanges
from app.domain.values import DayMode, FilterKind

OLD = {
    "source_database": "db",
    "source_schema": "public",
    "source_table": "t",
    "target_catalog": "c",
    "target_schema": "s",
    "target_table": "t",
    "used_secret": "sec/a",
    "date_field": "created_at",
    "trino_day_mode": "sp",
    "filter_kind": "date",
    "enabled": True,
}


def plan(changes, host="h2"):
    return plan_update(OLD, "h1", changes, lambda _: host)


def test_no_change_writes_nothing():
    result = plan(TableChanges(names={"used_secret": "sec/a"}, enabled=True))
    assert not result.has_sets and result.edits == []


def test_secret_change_resolves_host_and_resets_origin_facts():
    result = plan(TableChanges(names={"used_secret": "sec/b"}))
    assert result.values["used_host"] == "h2"
    assert [e[0] for e in result.edits] == ["used_secret", "used_host"]
    assert "source_ddl=NULL" in result.literals
    assert "config_changed_at=now()" in result.literals
    assert "trino_object_type=NULL" not in result.literals


def test_target_change_resets_lake_facts_and_column_type():
    result = plan(TableChanges(names={"target_table": "other"}))
    assert "trino_object_type=NULL" in result.literals
    assert "trino_col_type=NULL" in result.literals
    assert "source_ddl=NULL" not in result.literals


def test_column_removed_clears_flag():
    result = plan(TableChanges(names={"date_field": None}))
    assert result.values["has_date_field"] is False


def test_day_mode_is_manual_and_stale():
    result = plan(TableChanges(day_mode=DayMode.UTC))
    assert result.values["trino_day_mode"] == "utc"
    assert "mode_source='manual'" in result.literals
    assert "config_changed_at=now()" in result.literals


def test_enabled_alone_does_not_stale_the_result():
    result = plan(TableChanges(enabled=False))
    assert result.edits == [("enabled", "true", "false")]
    assert result.literals == []


def test_filter_kind_resets_column_type():
    result = plan(TableChanges(filter_kind=FilterKind.ID))
    assert "trino_col_type=NULL" in result.literals
    assert result.set_clause().startswith("filter_kind=%s")


def test_tag_diff():
    assert tag_diff({"a", "b"}, ["b", "c"]) == (["c"], ["a"])

import datetime as dt

import pytest

from app.adapters.outbound.postgres.connections import PostgresConnections
from app.adapters.outbound.postgres.result_store import result_params, table_id
from app.adapters.outbound.postgres.sql import key_match, key_params, key_text
from app.application.ports.secrets import ConnectionSecret, SecretsProvider
from app.domain.comparison import ComparisonResult, TableFacts
from app.domain.engines import Engine
from app.domain.entities import MonitoredTable
from app.domain.values import Period, TableKey

KEY = TableKey.parse("db.public.t@c.s.t")


class FakeSecrets(SecretsProvider):
    calls = 0

    def connection(self, name):
        self.calls += 1
        return ConnectionSecret(Engine.POSTGRESQL, "h", 5432, "u", "p", "app")

    def host_of(self, name):
        return "h"


def test_connect_args_set_search_path_and_read_secret_once():
    secrets = FakeSecrets()
    conns = PostgresConnections(secrets, "DB")
    args = conns.connect_args()
    conns.connect_args()
    assert args["options"] == "-c search_path=ingestion_healthy"
    assert args["dbname"] == "app" and secrets.calls == 1


def test_key_helpers():
    assert key_match().count("%s") == 6
    assert "lower(t.target_table)" in key_match("t")
    assert key_params(KEY) == ("db", "public", "t", "c", "s", "t")
    assert key_text().endswith("target_table")


def test_result_params_for_whole_table_result():
    table = MonitoredTable(key=KEY, secret="s", host="h", id=7)
    period = Period(dt.date(2026, 1, 1), dt.date(2026, 1, 1))
    result = ComparisonResult.whole_table(table, period, 5, 6, TableFacts())
    params = result_params("r1", table, result)
    assert len(params) == 15 and params[0] == params[7] == 7
    assert params[4] == "Diferente" and params[6] == "total" and params[8] is None
    assert params[12] == 1


def test_table_without_id_is_rejected():
    with pytest.raises(ValueError):
        table_id(MonitoredTable(key=KEY, secret="s", host="h"))

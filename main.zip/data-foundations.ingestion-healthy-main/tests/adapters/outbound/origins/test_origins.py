import datetime as dt

import pytest

from app.adapters.outbound.origins import sql
from app.adapters.outbound.origins.base import OriginSettings
from app.adapters.outbound.origins.factory import RegistryOriginReaderFactory
from app.adapters.outbound.origins.postgres import PostgresOrigin
from app.adapters.outbound.origins.sqlserver import SqlServerOrigin
from app.application.ports.origin import OriginTable
from app.application.ports.secrets import ConnectionSecret, SecretsProvider
from app.domain.engines import Engine
from app.domain.exceptions import (
    OriginError,
    PermanentError,
    WindowTimeout,
)

TABLE = OriginTable("public", "t", (("Id", "bigint"), ("created", "date")))


def secret(engine=Engine.POSTGRESQL):
    return ConnectionSecret(engine, "h", 5432, "u", "p", "db")


class Stubbed(PostgresOrigin):
    """A PostgreSQL origin whose I/O is replaced by canned answers."""

    def __init__(self, rows=None, error=None):
        super().__init__(secret(), OriginSettings())
        self.answer, self.error, self.sent = rows or [], error, []

    def _rows(self, statement, params=()):
        self.sent.append((statement, params))
        if self.error:
            raise self.error
        return self.answer

    def _execute(self, statement):
        self.sent.append((statement, ()))


def test_find_table_matches_case_insensitively_and_by_name_when_unique():
    origin = Stubbed(
        [("Sales", "Orders", "Id", "bigint"), ("Sales", "Orders", "x", "")]
    )
    found = origin.find_table("sales", "orders")
    assert (found.schema, found.table, len(found.columns)) == ("Sales", "Orders", 2)
    assert origin.find_table("other", "orders") is found
    assert origin.find_table("sales", "missing") is None


def test_find_table_by_name_is_ambiguous_with_two_schemas():
    origin = Stubbed([("a", "t", "c", "int"), ("b", "t", "c", "int")])
    assert origin.find_table("c", "t") is None


def test_stats_size_and_definition_never_raise():
    origin = Stubbed(error=RuntimeError("boom"))
    assert origin.stats(TABLE, "created").rows == 0
    assert origin.stats(TABLE, "created").leading_index is False
    assert origin.size_bytes(TABLE) is None
    assert origin.definition(TABLE) is None


def test_stats_reads_rows_and_index():
    origin = Stubbed([(-1, True)])
    stats = origin.stats(TABLE, "created")
    assert (stats.rows, stats.leading_index) == (0, True)


def test_window_timeout_and_other_errors():
    day = dt.date(2026, 1, 1)
    slow = Stubbed(error=RuntimeError("canceling statement due to statement timeout"))
    with pytest.raises(WindowTimeout):
        slow.count_by_day(TABLE, "created", day, day, 30)
    with pytest.raises(OriginError):
        Stubbed(error=RuntimeError("boom")).count_by_day(TABLE, "c", day, day, 30)


def test_count_rows_timeout_is_permanent_and_other_errors_retryable():
    slow = Stubbed(error=RuntimeError("statement timeout"))
    with pytest.raises(PermanentError):
        slow.count_rows(TABLE)
    with pytest.raises(OriginError):
        Stubbed(error=RuntimeError("boom")).count_rows(TABLE, "Id", 5)
    assert Stubbed([(41,)]).count_rows(TABLE) == 41


def test_sqlserver_timeout_reconnects_with_the_new_limit():
    origin = SqlServerOrigin(secret(Engine.SQLSERVER), OriginSettings(query_timeout=60))
    origin._set_timeout(300)
    assert origin._timeout == 300 and origin._conn is None


def test_sql_builders():
    day = dt.date(2026, 1, 1)
    q, params = sql.ms_day_query("dbo", "t]", "c", day, day)
    assert "CAST([c] AS date)" in q and "[dbo].[t]]]" in q
    assert params == ("2026-01-01", "2026-01-01")
    q, params = sql.pg_day_query("public", "t", "c", day, day)
    assert q.startswith('SELECT ("c")::date') and "GROUP BY 1" in q
    assert sql.pg_count_query("s", "t", "id", 5) == (
        'SELECT count(*) FROM "s"."t" WHERE "id" <= %s',
        (5,),
    )
    assert sql.ms_count_query("s", "t", None, None) == (
        "SELECT COUNT_BIG(*) FROM [s].[t]",
        (),
    )
    assert "CAST(ic.seed_value AS bigint)" in sql.MS_COLUMNS
    assert sql.is_timeout("Adaptive Server connection timed out")
    assert not sql.is_timeout("syntax error")


class FakeSecrets(SecretsProvider):
    def connection(self, name):
        return secret(Engine.SQLSERVER if "sql" in name else Engine.POSTGRESQL)

    def host_of(self, name):
        return "h"


def test_factory_picks_by_engine_and_overrides_the_host():
    factory = RegistryOriginReaderFactory(FakeSecrets())
    assert isinstance(factory.open("x/postgres", "other"), PostgresOrigin)
    reader = factory.open("x/sql", "other")
    assert isinstance(reader, SqlServerOrigin) and reader._secret.host == "other"


def test_a_new_engine_is_a_new_registry_entry():
    class Custom(PostgresOrigin):
        pass

    factory = RegistryOriginReaderFactory(
        FakeSecrets(), builders={Engine.POSTGRESQL: Custom}
    )
    assert isinstance(factory.open("x/postgres", ""), Custom)
    with pytest.raises(PermanentError):
        factory.open("x/sql", "")

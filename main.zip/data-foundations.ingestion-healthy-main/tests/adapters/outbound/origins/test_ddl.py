from app.adapters.outbound.origins import ddl


def test_pg_definition_and_indexes():
    columns = [
        ("id", "bigint", True, None, "a", ""),
        ("n", "integer", False, "0", "", ""),
        ("g", "integer", False, "n + 1", "", "s"),
    ]
    text = ddl.pg_definition("public", "t", columns, [("t_pkey", "PRIMARY KEY (id)")])
    assert '"id" bigint GENERATED ALWAYS AS IDENTITY NOT NULL' in text
    assert '"n" integer DEFAULT 0' in text
    assert '"g" integer GENERATED ALWAYS AS (n + 1) STORED' in text
    assert text.endswith('CONSTRAINT "t_pkey" PRIMARY KEY (id)\n);')
    idx = ddl.pg_indexes([("i", True, True, "CREATE INDEX i", ["id"], None, None)])
    assert idx[0]["columns"] == ["id"] and idx[0]["definition"] == "CREATE INDEX i;"
    assert idx[0]["include"] == []


def test_ms_types():
    assert ddl.ms_type("varchar", -1, 0, 0) == "varchar(max)"
    assert ddl.ms_type("nvarchar", 20, 0, 0) == "nvarchar(10)"
    assert ddl.ms_type("decimal", 9, 18, 2) == "decimal(18,2)"
    assert ddl.ms_type("datetime2", 8, 27, 7) == "datetime2(7)"
    assert ddl.ms_type("int", 4, 10, 0) == "int"


def test_ms_definition_with_identity_computed_and_primary_key():
    columns = [
        ("id", "bigint", 8, 19, 0, False, True, 1, 1, None, None),
        ("v", "int", 4, 10, 0, True, False, None, None, "((0))", None),
        ("c", "int", 4, 10, 0, True, False, None, None, None, "([v]+(1))"),
    ]
    text = ddl.ms_definition("dbo", "t", columns, ["id"])
    assert "[id] bigint IDENTITY(1,1) NOT NULL" in text
    assert "[v] int NULL DEFAULT ((0))" in text
    assert "[c] AS ([v]+(1))" in text
    assert "PRIMARY KEY ([id])" in text


def test_ms_indexes_group_columns_and_includes():
    rows = [
        (1, "pk", "CLUSTERED", True, True, None, "id", False, False),
        (2, "ix", "NONCLUSTERED", False, False, "([a]=1)", "a", False, True),
        (2, "ix", "NONCLUSTERED", False, False, "([a]=1)", "b", True, False),
    ]
    pk, ix = ddl.ms_indexes("dbo", "t", rows)
    assert pk["definition"] == "CREATE UNIQUE CLUSTERED INDEX [pk] ON [dbo].[t] ([id]);"
    assert ix["include"] == ["b"] and ix["columns"] == ["a"]
    assert ix["definition"] == (
        "CREATE NONCLUSTERED INDEX [ix] ON [dbo].[t] ([a] DESC) "
        "INCLUDE ([b]) WHERE ([a]=1);"
    )

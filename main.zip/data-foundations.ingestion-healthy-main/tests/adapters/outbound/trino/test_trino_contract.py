"""What the worker relies on from the Trino adapter: session, mode, types and
the way errors are classified."""

import datetime as dt
import json

import pytest

from app.adapters.outbound.trino import connection
from app.adapters.outbound.trino.connection import TrinoSettings, open_cursor
from app.adapters.outbound.trino.reader import TrinoLakeReader
from app.adapters.outbound.trino.settings_loader import load_trino_settings
from app.domain.exceptions import LakeError, PermanentError
from app.domain.values import DayMode, ObjectType, Period, TableKey
from tests.adapters.outbound.trino.test_reader import FakeCursor

KEY = TableKey("db", "public", "t", "trusted", "s", "t")
SETTINGS = TrinoSettings("h", 443, "u", "p")


class FakeConnection:
    def __init__(self, applied):
        self.cursor_ = FakeCursor({})
        self.applied = applied

    def cursor(self):
        outer = self

        class Cursor:
            def execute(self, statement):
                pass

            def fetchone(self):
                return [outer.applied]

        return Cursor()


@pytest.fixture
def connect(monkeypatch):
    sent = {}

    def fake(applied="America/Sao_Paulo"):
        def _connect(**kwargs):
            sent.update(kwargs)
            return FakeConnection(applied)

        monkeypatch.setattr(connection.trino.dbapi, "connect", _connect)
        return sent

    return fake


def test_session_is_opened_with_sao_paulo_and_checked(connect):
    sent = connect()
    open_cursor(SETTINGS)
    assert sent["timezone"] == "America/Sao_Paulo"


def test_a_server_that_does_not_apply_the_timezone_is_a_permanent_error(connect):
    connect("UTC")
    with pytest.raises(PermanentError, match="TRINO_SESSION_TIMEZONE_MISMATCH"):
        open_cursor(SETTINGS)


def test_the_reader_drops_a_bad_session_and_classifies_it_as_permanent(connect):
    connect("UTC")
    reader = TrinoLakeReader(lambda: open_cursor(SETTINGS))
    with pytest.raises(PermanentError, match="TRINO_SESSION_TIMEZONE_MISMATCH"):
        reader.count_rows(KEY)
    assert reader._cursor is None


class SecretsClient:
    def get_secret_value(self, SecretId):
        creds = {"host": "old.example", "port": 443, "username": "u", "password": "p"}
        return {"SecretString": json.dumps(creds)}


def test_trino_host_can_be_overridden_and_empty_means_the_secret_host():
    load = load_trino_settings
    new = load(SecretsClient(), "s", "America/Sao_Paulo", host_override="new.example")
    assert new.host == "new.example"
    assert load(SecretsClient(), "s", "America/Sao_Paulo", "").host == "old.example"


def reader(answers):
    cursor = FakeCursor(answers)
    return TrinoLakeReader(lambda: cursor), cursor


PERIOD = Period(dt.date(2026, 7, 8), dt.date(2026, 7, 9))


def test_a_missing_column_is_reported_as_such():
    r, _ = reader({"SHOW COLUMNS": [("other", "timestamp(3)", "", "")]})
    with pytest.raises(PermanentError, match="TRINO_COLUMN_NOT_FOUND"):
        r.column_type(KEY, "created_at_dt")


def test_an_unsupported_column_type_is_refused_when_counting_by_day():
    r, cursor = reader({})
    with pytest.raises(PermanentError, match="TRINO_DAY_MODE_UNDEFINED"):
        r.count_by_day(KEY, "d", "varchar", DayMode.SAO_PAULO, PERIOD)
    assert cursor.sent == []


def test_the_mode_given_reaches_the_query_with_the_real_column_type():
    sent = {}
    for mode in DayMode:
        for ty in ("timestamp(3)", "date", "timestamp(6) with time zone"):
            r, cursor = reader({"count(*)": []})
            r.count_by_day(KEY, "d", ty, mode, PERIOD)
            sent[(mode, ty)] = cursor.sent[0]
    assert "'UTC'" in sent[(DayMode.UTC, "timestamp(6) with time zone")]
    assert (
        "America/Sao_Paulo" in sent[(DayMode.SAO_PAULO, "timestamp(6) with time zone")]
    )
    assert (
        sent[(DayMode.UTC, "timestamp(3)")] != sent[(DayMode.SAO_PAULO, "timestamp(3)")]
    )
    assert sent[(DayMode.UTC, "date")] == sent[(DayMode.SAO_PAULO, "date")]


def test_a_schema_error_is_permanent_and_a_dropped_connection_is_retryable():
    r, _ = reader({"count(*)": Exception("TrinoUserError(name=SCHEMA_NOT_FOUND)")})
    with pytest.raises(PermanentError):
        r.count_by_day(KEY, "d", "date", DayMode.UTC, PERIOD)
    r, _ = reader({"count(*)": Exception("connection reset")})
    with pytest.raises(LakeError):
        r.count_by_day(KEY, "d", "date", DayMode.UTC, PERIOD)


def test_a_view_records_its_type_and_ddl_in_two_queries():
    r, cursor = reader(
        {
            "table_type": [("VIEW",)],
            "SHOW CREATE VIEW": [("CREATE VIEW c.s.t AS SELECT 1",)],
        }
    )
    found = r.inspect_object(KEY)
    assert (found.type, found.ddl) == (ObjectType.VIEW, "CREATE VIEW c.s.t AS SELECT 1")
    assert "SHOW CREATE VIEW" in cursor.sent[1]


def test_a_table_has_no_ddl_and_an_unknown_object_stays_blank():
    r, cursor = reader({"table_type": [("BASE TABLE",)]})
    found = r.inspect_object(KEY)
    assert (found.type, found.ddl, len(cursor.sent)) == (ObjectType.TABLE, None, 1)
    r, _ = reader({})
    assert r.inspect_object(KEY) is None


def test_last_id_bounds_the_count_by_the_largest_id():
    r, cursor = reader(
        {"SHOW COLUMNS": [("id", "bigint", "", "")], "max(": [(1500,)], "<=": [(1490,)]}
    )
    assert r.last_id(KEY, "id") == (1500, 1490)
    assert cursor.sent[1:] == [
        'SELECT max("id") FROM "trusted"."s"."t"',
        'SELECT count(*) FROM "trusted"."s"."t" WHERE "id" <= 1500',
    ]


def test_only_integer_columns_can_be_compared_by_id():
    r, _ = reader({"SHOW COLUMNS": [("id", "varchar", "", "")]})
    with pytest.raises(PermanentError, match="inteira"):
        r.last_id(KEY, "id")


def test_the_whole_table_is_counted_without_a_filter():
    r, cursor = reader({"count(*)": [(7,)]})
    assert r.count_rows(KEY) == 7
    assert cursor.sent == ['SELECT count(*) FROM "trusted"."s"."t"']

import datetime as dt

import pytest

from app.adapters.outbound.trino import sql
from app.domain.exceptions import LakeError, PermanentError
from app.domain.values import DayMode, TableKey

KEY = TableKey("db", "public", "pix", "trusted", "pix", "dbo_pix")
START, END = dt.date(2026, 7, 8), dt.date(2026, 10, 6)
ZONED = "timestamp(6) with time zone"


def day_sql(mode, ty=ZONED):
    return sql.day_count_sql(KEY, "created_at_dt", ty, mode, START, END)


def test_zoned_column_is_bucketed_in_the_chosen_zone_with_explicit_bounds():
    sp = day_sql(DayMode.SAO_PAULO)
    assert "SELECT date(\"created_at_dt\" AT TIME ZONE 'America/Sao_Paulo')" in sp
    assert (
        "\"created_at_dt\" >= TIMESTAMP '2026-07-08 00:00:00 America/Sao_Paulo'" in sp
    )
    assert "\"created_at_dt\" < TIMESTAMP '2026-10-06 00:00:00 America/Sao_Paulo'" in sp
    assert "CAST(" not in sp
    utc = day_sql(DayMode.UTC)
    assert "date(\"created_at_dt\" AT TIME ZONE 'UTC')" in utc
    assert "TIMESTAMP '2026-07-08 00:00:00 UTC'" in utc
    assert "TIMESTAMP '2026-10-06 00:00:00 UTC'" in utc


def test_naive_timestamp_is_sao_paulo_wall_clock_and_utc_converts_it():
    sp = day_sql(DayMode.SAO_PAULO, "timestamp(3)")
    assert 'SELECT CAST("created_at_dt" AS date)' in sp
    assert (
        "\"created_at_dt\" >= TIMESTAMP '2026-07-08 00:00:00' AND "
        "\"created_at_dt\" < TIMESTAMP '2026-10-06 00:00:00'"
    ) in sp
    assert "TIME ZONE" not in sp
    utc = day_sql(DayMode.UTC, "timestamp(3)")
    wall = "with_timezone(\"created_at_dt\", 'America/Sao_Paulo')"
    assert f"date({wall} AT TIME ZONE 'UTC')" in utc
    assert f"{wall} >= TIMESTAMP '2026-07-08 00:00:00 UTC'" in utc
    assert "\"created_at_dt\" >= TIMESTAMP '2026-07-07 00:00:00'" in utc
    assert sp != utc


@pytest.mark.parametrize("mode", list(DayMode))
def test_date_column_is_its_own_day_in_both_modes(mode):
    text = day_sql(mode, "date")
    assert 'SELECT "created_at_dt", count(*)' in text
    assert "DATE '2026-07-08'" in text and "DATE '2026-10-06'" in text


def test_a_column_that_is_not_temporal_is_refused():
    with pytest.raises(PermanentError, match="TRINO_DAY_MODE_UNDEFINED"):
        day_sql(DayMode.UTC, "varchar")


def test_names_are_quoted():
    assert sql.qualified(KEY) == '"trusted"."pix"."dbo_pix"'
    assert sql.quote('a"b') == '"a""b"'
    assert sql.literal("o'k") == "'o''k'"


def test_id_queries():
    assert (
        sql.max_id_sql(KEY, "id") == 'SELECT max("id") FROM "trusted"."pix"."dbo_pix"'
    )
    assert sql.count_up_to_sql(KEY, "id", 9).endswith('WHERE "id" <= 9')
    sql.ensure_id_type("id", "bigint")
    with pytest.raises(PermanentError):
        sql.ensure_id_type("id", "varchar")


def test_error_classification():
    missing = RuntimeError("TABLE_NOT_FOUND: line 1")
    assert isinstance(sql.classify_error(missing), PermanentError)
    assert type(sql.classify_error(RuntimeError("boom"))) is LakeError
    own = PermanentError("x")
    assert sql.classify_error(own) is own


def test_session_timezone_must_match():
    sql.ensure_session_timezone("America/Sao_Paulo", "America/Sao_Paulo")
    with pytest.raises(PermanentError, match="TRINO_SESSION_TIMEZONE_MISMATCH"):
        sql.ensure_session_timezone("UTC", "America/Sao_Paulo")

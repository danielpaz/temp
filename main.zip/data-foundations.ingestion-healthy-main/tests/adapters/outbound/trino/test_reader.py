import datetime as dt

import pytest

from app.adapters.outbound.trino.reader import TrinoLakeReader
from app.domain.exceptions import LakeError, PermanentError
from app.domain.values import DayMode, ObjectType, Period, TableKey

KEY = TableKey("db", "public", "t", "trusted", "s", "t")


class FakeCursor:
    def __init__(self, answers):
        self.answers = answers
        self.sent = []
        self._rows = []

    def execute(self, statement):
        self.sent.append(statement)
        for needle, rows in self.answers.items():
            if needle in statement:
                if isinstance(rows, Exception):
                    raise rows
                self._rows = rows
                return
        self._rows = []

    def fetchall(self):
        return self._rows


def reader(answers):
    cursor = FakeCursor(answers)
    return TrinoLakeReader(lambda: cursor), cursor


def test_column_type_is_read_from_trino_and_missing_column_is_permanent():
    r, _ = reader({"SHOW COLUMNS": [("ID", "bigint", "", "")]})
    assert r.column_type(KEY, "id") == "bigint"
    with pytest.raises(PermanentError, match="TRINO_COLUMN_NOT_FOUND"):
        r.column_type(KEY, "other")


def test_last_id_returns_max_and_rows_up_to_it():
    r, _ = reader(
        {
            "SHOW COLUMNS": [("id", "bigint", "", "")],
            "max(": [(7,)],
            "<= 7": [(5,)],
        }
    )
    assert r.last_id(KEY, "id") == (7, 5)


def test_last_id_of_an_empty_table_and_non_integer_column():
    r, _ = reader({"SHOW COLUMNS": [("id", "bigint", "", "")], "max(": [(None,)]})
    assert r.last_id(KEY, "id") == (None, 0)
    r, _ = reader({"SHOW COLUMNS": [("id", "varchar", "", "")]})
    with pytest.raises(PermanentError):
        r.last_id(KEY, "id")


def test_count_by_day_and_errors():
    r, _ = reader({"count(*)": [(dt.date(2026, 1, 1), 3)]})
    period = Period(dt.date(2026, 1, 1), dt.date(2026, 1, 1))
    got = r.count_by_day(KEY, "d", "date", DayMode.UTC, period)
    assert got == {dt.date(2026, 1, 1): 3}
    r, _ = reader({"count(*)": RuntimeError("SCHEMA_NOT_FOUND")})
    with pytest.raises(PermanentError):
        r.count_rows(KEY)
    r, _ = reader({"count(*)": RuntimeError("socket closed")})
    with pytest.raises(LakeError):
        r.count_rows(KEY)


def test_inspect_object_table_view_and_best_effort():
    r, _ = reader({"table_type": [("BASE TABLE",)]})
    assert r.inspect_object(KEY).type is ObjectType.TABLE
    r, _ = reader({"table_type": [("VIEW",)], "SHOW CREATE VIEW": [("CREATE VIEW",)]})
    found = r.inspect_object(KEY)
    assert (found.type, found.ddl) == (ObjectType.VIEW, "CREATE VIEW")
    r, _ = reader({"table_type": RuntimeError("down")})
    assert r.inspect_object(KEY) is None
    r, _ = reader({})
    assert r.inspect_object(KEY) is None

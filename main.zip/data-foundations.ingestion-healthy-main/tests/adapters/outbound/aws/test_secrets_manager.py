import json

import pytest

from app.adapters.outbound.aws.secrets_manager import SecretsManagerProvider
from app.domain.engines import Engine
from app.domain.exceptions import InvalidRequest

CONNECTOR = """connector.name=postgresql
connection-url=jdbc:sqlserver://h1:1444;databaseName=pix;encrypt=false
connection-user=u
connection-password=p
"""


class FakeSM:
    def __init__(self, secrets):
        self.secrets = secrets

    def get_secret_value(self, SecretId):
        if SecretId not in self.secrets:
            raise RuntimeError("ResourceNotFound")
        return {"SecretString": self.secrets[SecretId]}


def provider(**secrets):
    return SecretsManagerProvider(FakeSM(secrets))


def test_json_secret_with_lower_case_keys():
    body = json.dumps(
        {
            "engine": "postgresql",
            "host": "h",
            "port": "5433",
            "username": "u",
            "password": "p",
            "dbname": "d",
        }
    )
    secret = provider(a=body).connection("a")
    assert (secret.engine, secret.host, secret.port) == (Engine.POSTGRESQL, "h", 5433)
    assert (secret.user, secret.password, secret.database) == ("u", "p", "d")


def test_upper_case_keys_and_engine_from_the_name():
    body = json.dumps({"HOST": "h", "USER": "u", "PASSWORD": "p", "DATABASE": "d"})
    secret = provider(**{"prod/x/postgres-a": body}).connection("prod/x/postgres-a")
    assert secret.engine is Engine.POSTGRESQL
    assert (secret.port, secret.user, secret.database) == (5432, "u", "d")


def test_connector_file():
    secret = provider(a=CONNECTOR).connection("a")
    assert secret.engine is Engine.SQLSERVER
    assert (secret.host, secret.port, secret.database) == ("h1", 1444, "pix")


def test_host_of_never_returns_credentials():
    assert provider(a=CONNECTOR).host_of("a") == "h1"


def test_missing_secret_is_invalid_request():
    with pytest.raises(InvalidRequest):
        provider().host_of("nope")


def test_unknown_engine_is_invalid_request():
    body = json.dumps({"host": "h", "user": "u", "password": "p"})
    with pytest.raises(InvalidRequest):
        provider(a=body).connection("a")


def test_secret_without_host():
    with pytest.raises(InvalidRequest):
        provider(a=json.dumps({"engine": "postgresql"})).host_of("a")


def test_unparseable_secret():
    with pytest.raises(InvalidRequest):
        provider(a="garbage").host_of("a")

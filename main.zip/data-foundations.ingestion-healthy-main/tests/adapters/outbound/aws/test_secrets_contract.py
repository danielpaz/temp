"""Secret parsing contract, ported from the old host_from_secret and region tests."""

import json

import pytest

from app.adapters.outbound.aws.secrets_manager import SecretsManagerProvider
from app.bootstrap import container
from app.config.settings import Settings
from app.domain.engines import Engine
from app.domain.exceptions import InvalidRequest

SQL_CONNECTOR = (
    "connector.name=sqlserver\n"
    "connection-url=jdbc:sqlserver://VASPCWP-DBPIX01:1433;databaseName=PIX\n"
)


class FakeSM:
    def __init__(self, text):
        self.text = text

    def get_secret_value(self, SecretId):
        return {"SecretString": self.text}


def host_of(text):
    return SecretsManagerProvider(FakeSM(text)).host_of("prod/x/sql-server/pix")


def test_host_is_read_from_json_with_upper_case_keys():
    assert host_of('{"HOST": "h1.example", "password": "p"}') == "h1.example"


def test_host_is_read_from_a_connector_file_and_never_leaks_credentials():
    assert host_of(SQL_CONNECTOR + "connection-password=hunter2\n") == "VASPCWP-DBPIX01"


def test_host_from_the_hostname_key():
    assert host_of('{"hostname": "h2"}') == "h2"


@pytest.mark.parametrize("text", ['{"user": "u"}', "nothing here"])
def test_secret_without_a_host_is_rejected(text):
    with pytest.raises(InvalidRequest):
        host_of(text)


def test_connector_file_gives_engine_port_and_database():
    secret = SecretsManagerProvider(FakeSM(SQL_CONNECTOR)).connection("x")
    assert (secret.engine, secret.host, secret.port, secret.database) == (
        Engine.SQLSERVER,
        "VASPCWP-DBPIX01",
        1433,
        "PIX",
    )


def test_the_aws_client_gets_an_explicit_region(monkeypatch):
    seen = {}
    monkeypatch.setattr(
        container.boto3,
        "client",
        lambda service, **kw: seen.update(service=service, **kw),
    )
    container._client("secretsmanager", Settings(aws_region="sa-east-1"))
    assert seen == {"service": "secretsmanager", "region_name": "sa-east-1"}


def test_json_secret_roundtrip_keeps_the_schema_free_fields():
    body = json.dumps({"host": "h", "username": "u", "password": "p", "dbname": "d",
                       "engine": "postgresql"})  # fmt: skip
    secret = SecretsManagerProvider(FakeSM(body)).connection("a")
    assert (secret.host, secret.database) == ("h", "d")

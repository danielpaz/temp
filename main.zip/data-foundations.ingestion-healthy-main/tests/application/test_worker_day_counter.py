import datetime as dt
import threading
import time

import pytest

from app.application.concurrency import SingleFlight
from app.application.ports.origin import OriginStats, OriginTable
from app.application.use_cases.origin_day_counter import DayCountRequest
from app.domain.exceptions import OriginError, PermanentError, WindowTimeout
from app.domain.values import Period
from tests.support.fakes import Behaviour
from tests.support.worker_kit import (
    BIG,
    ScriptedOrigin,
    new_counter,
    one_per_day,
)

PERIOD = Period(dt.date(2026, 7, 8), dt.date(2026, 10, 5))  # 90 days
TABLE = OriginTable("dbo", "t", (("created_at_dt", "timestamp"),))


def request(origin, stats=BIG, store=None, seen=None):
    return DayCountRequest(
        origin=origin,
        table=TABLE,
        column="created_at_dt",
        period=PERIOD,
        stats=stats,
        instance="x",
        windows_done={} if store is None else store,
        on_chunk=(lambda n, t: seen.append((n, t)))
        if seen is not None
        else (lambda n, t: None),
    )


def slow_over(limit_days):
    def window(start, end):
        if (end - start).days > limit_days:
            raise WindowTimeout("statement timeout")
        return one_per_day(start, end)

    return window


def test_chunked_counts_are_consolidated_and_progress_is_reported():
    origin = ScriptedOrigin(Behaviour(), lambda a, b: one_per_day(a, b))
    seen = []
    out = new_counter().count(request(origin, seen=seen))
    assert len(origin.world.windows) == 6
    assert len(out) == 90
    assert seen == [(i, 6) for i in range(1, 7)]


def test_finished_windows_are_not_queried_again_after_a_failure():
    store, calls = {}, []

    def flaky(start, end):
        calls.append((start, end))
        if len(calls) == 3:
            raise OriginError("connection reset by peer")
        return one_per_day(start, end)

    counter = new_counter()
    with pytest.raises(OriginError):
        counter.count(request(ScriptedOrigin(Behaviour(), flaky), store=store))
    assert len(store) == 2, "the two windows that finished are kept"
    again = ScriptedOrigin(Behaviour(), lambda a, b: one_per_day(a, b))
    out = counter.count(request(again, store=store))
    assert len(again.world.windows) == 4
    assert len(out) == 90


def test_big_table_without_index_is_a_single_query():
    origin = ScriptedOrigin(Behaviour(), lambda a, b: one_per_day(a, b))
    out = new_counter().count(request(origin, OriginStats(4_500_000_000, False)))
    assert len(out) == 90
    (call,) = origin.world.windows
    assert (call[1], call[2]) == (dt.date(2026, 7, 8), dt.date(2026, 10, 6))


def test_timeout_without_index_has_an_actionable_message():
    def window(start, end):
        raise WindowTimeout("statement timeout")

    origin = ScriptedOrigin(Behaviour(), window)
    with pytest.raises(PermanentError) as caught:
        new_counter().count(request(origin, OriginStats(4_500_000_000, False)))
    assert "sem índice em created_at_dt" in str(caught.value)
    assert "4.5 bi" in str(caught.value)


def test_a_window_that_times_out_is_split_in_halves_until_it_fits():
    origin = ScriptedOrigin(Behaviour(), slow_over(5))
    out = new_counter().count(request(origin))
    assert len(out) == 90, "every day of the period is still counted"
    sizes = [(b - a).days for _, a, b, _ in origin.world.windows]
    assert min(sizes) <= 5, "it kept halving until a piece fit"
    assert len(sizes) > 6, "the 15-day windows were retried in smaller pieces"


def test_a_single_day_that_times_out_is_a_permanent_error():
    origin = ScriptedOrigin(Behaviour(), slow_over(0))
    with pytest.raises(PermanentError):
        new_counter().count(request(origin))


def test_a_retry_after_a_timeout_does_not_query_finished_windows_again():
    store = {}
    counter = new_counter()
    counter.count(request(ScriptedOrigin(Behaviour(), slow_over(7)), store=store))
    again = ScriptedOrigin(Behaviour(), lambda a, b: one_per_day(a, b))
    counter.count(request(again, store=store))
    assert again.world.windows == []


def test_identical_queries_from_two_threads_run_once():
    flight, runs, results = SingleFlight(), [], []

    def slow():
        runs.append(1)
        time.sleep(0.2)
        return {"n": 7}

    threads = [
        threading.Thread(target=lambda: results.append(flight.do(("k", 1), slow)))
        for _ in range(3)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert (len(runs), results) == (1, [{"n": 7}] * 3)


def test_a_failed_query_is_not_remembered():
    flight, calls = SingleFlight(), []

    def work():
        calls.append(1)
        if len(calls) == 1:
            raise RuntimeError("boom")
        return "ok"

    with pytest.raises(RuntimeError):
        flight.do("k", work)
    assert flight.do("k", work) == "ok"

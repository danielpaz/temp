import datetime as dt
from concurrent.futures import ThreadPoolExecutor

import pytest

from app.application.use_cases.progress_recorder import ProgressRecorder
from app.domain.comparison import LakeObject
from app.domain.exceptions import OriginError
from app.domain.progress import TableState, WorkerProgress
from app.domain.values import (
    Basis,
    DayMode,
    FilterKind,
    ObjectType,
    Period,
    ResultStatus,
)
from tests.support.fakes import (
    PERIOD,
    Behaviour,
    FakeClock,
    FakeLake,
    FakeOrigin,
    WorkerClock,
    make_table,
)
from tests.support.worker_kit import (
    JsonStore,
    ScriptedOrigin,
    one_per_day,
    process,
    processor,
)


class RecordingLake(FakeLake):
    def __init__(self, behaviour, column_type="timestamp(3)"):
        super().__init__(behaviour)
        self.type, self.calls = column_type, []

    def column_type(self, key, column):
        return self.type

    def count_by_day(self, key, column, column_type, mode, period):
        self.calls.append((mode, column_type))
        return super().count_by_day(key, column, column_type, mode, period)


@pytest.mark.parametrize("mode", list(DayMode))
@pytest.mark.parametrize("ty", ["timestamp(3)", "date", "timestamp(6) with time zone"])
def test_the_mode_of_the_table_and_the_real_column_type_reach_the_lake(mode, ty):
    behaviour = Behaviour()
    lake = RecordingLake(behaviour, ty)
    table = make_table(mode=mode)
    done = process(table, PERIOD, behaviour, lake=lake)
    assert lake.calls == [(mode, ty)]
    assert done.result.facts.lake_column_type == ty
    expected = Basis.UTC if mode is DayMode.UTC else Basis.SAO_PAULO
    assert done.result.basis is expected


def test_a_column_that_is_not_a_date_is_refused_as_permanent():
    behaviour = Behaviour()
    behaviour.column_types["public_t1"] = "varchar"
    done = process(make_table(), PERIOD, behaviour, sleeps=[])
    assert done.progress.attempts == 1
    assert done.result.status is ResultStatus.ERROR
    assert "varchar" in done.result.error


def test_a_column_missing_in_the_origin_is_reported_as_such():
    done = process(make_table(column="nope"), PERIOD, Behaviour())
    assert done.result.status is ResultStatus.ERROR
    assert "date column not found in origin" in done.result.error
    assert done.progress.attempts == 1


def test_missing_lake_table_is_permanent_and_skips_the_origin_scan():
    behaviour = Behaviour()
    behaviour.missing_in_lake.add("public_t1")
    done = process(make_table(), PERIOD, behaviour)
    assert (done.progress.state, done.progress.attempts) == (TableState.ERROR, 1)
    assert behaviour.windows == []
    assert done.result.status is ResultStatus.ERROR
    assert "TABLE_NOT_FOUND" in done.result.error


def test_transient_origin_failures_are_retried_and_drop_the_connection():
    calls, sleeps = [], []

    def window(start, end):
        calls.append(1)
        if len(calls) < 3:
            raise OriginError("connection reset by peer")
        return {d: 5 for d in one_per_day(start, end)}

    behaviour = Behaviour()
    origin = ScriptedOrigin(behaviour, window)
    done = process(make_table(), PERIOD, behaviour, origin=origin, sleeps=sleeps)
    assert done.result.status is ResultStatus.EQUAL
    assert done.progress.attempts == 3
    assert sleeps == [1, 2]
    assert origin.closed == 2


def test_gives_up_after_the_attempts_with_the_last_error():
    def window(start, end):
        raise OriginError("connection reset by peer")

    behaviour = Behaviour()
    origin = ScriptedOrigin(behaviour, window)
    done = process(make_table(), PERIOD, behaviour, origin=origin)
    assert done.progress.attempts == 3
    assert done.progress.state is TableState.ERROR
    assert "connection reset" in done.result.error


def test_progress_is_safe_under_concurrent_tables():
    store = JsonStore()
    clock = WorkerClock(FakeClock())
    rec = ProgressRecorder(store, "run", WorkerProgress("w1", "A", "1"), clock)
    behaviour = Behaviour()
    process_table = processor()
    tables = [make_table(table=f"t{i}") for i in range(60)]

    def work(table):
        origin = FakeOrigin(behaviour, "s", "h")
        process_table.run(table, PERIOD, origin, FakeLake(behaviour), rec)

    with ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(work, tables))
    done = [p for p in rec.progress.tables.values() if p.state is TableState.DONE]
    assert len(done) == 60
    assert len(rec.progress.results) == 60
    assert store.saves >= 60


def test_view_and_table_are_recorded_with_the_ddl_of_the_view():
    class ViewLake(FakeLake):
        def inspect_object(self, key):
            return LakeObject(ObjectType.VIEW, "CREATE VIEW c.s.t AS SELECT 1")

    behaviour = Behaviour()
    view = process(make_table(), PERIOD, behaviour, lake=ViewLake(behaviour))
    found = view.result.facts.lake_object
    assert (found.type, found.ddl) == (ObjectType.VIEW, "CREATE VIEW c.s.t AS SELECT 1")
    table = process(make_table(), PERIOD, behaviour)
    assert table.result.facts.lake_object == LakeObject(ObjectType.TABLE)


def id_table():
    return make_table(column="id", kind=FilterKind.ID)


def id_run(last_id, lake_rows, origin_rows, column_type="bigint"):
    behaviour = Behaviour()
    behaviour.last_ids["public_t1"] = (last_id, lake_rows)
    behaviour.origin_rows["t1"] = origin_rows
    behaviour.column_types["public_t1"] = column_type
    return process(id_table(), PERIOD, behaviour), behaviour


def test_the_origin_is_counted_up_to_the_largest_id_found_in_the_lake():
    done, behaviour = id_run(1500, 1500, 1500)
    assert behaviour.row_counts == [("t1", "id", 1500)]
    result = done.result
    assert (result.status, result.basis, result.filter_column) == (
        ResultStatus.EQUAL,
        Basis.ID,
        "id",
    )
    assert (result.last_id, result.origin_total, result.lake_total) == (
        1500,
        1500,
        1500,
    )
    assert (result.diff, result.days) == (0, [])
    assert behaviour.windows == [], "no per-day count when comparing by id"
    different, _ = id_run(1500, 1490, 1500)
    assert (different.result.status, different.result.diff) == (
        ResultStatus.DIFFERENT,
        -10,
    )


def test_an_empty_lake_table_is_compared_with_the_whole_origin():
    done, behaviour = id_run(None, 0, 7)
    assert behaviour.row_counts == [("t1", None, None)]
    result = done.result
    assert (result.last_id, result.origin_total, result.lake_total) == (None, 7, 0)
    assert result.status is ResultStatus.DIFFERENT


def test_only_integer_columns_can_be_compared_by_id():
    done, behaviour = id_run(1, 1, 1, column_type="varchar")
    assert done.result.status is ResultStatus.ERROR
    assert "inteira" in done.result.error
    assert done.progress.attempts == 1
    assert behaviour.row_counts == []


def test_a_missing_id_column_in_the_origin_is_permanent():
    behaviour = Behaviour()
    behaviour.column_types["public_t1"] = "bigint"
    behaviour.last_ids["public_t1"] = (5, 5)
    done = process(make_table(column="nope", kind=FilterKind.ID), PERIOD, behaviour)
    assert "id column not found in origin" in done.result.error
    assert done.progress.attempts == 1


def whole_run(origin_rows, lake_rows):
    behaviour = Behaviour()
    behaviour.origin_rows["t1"], behaviour.lake_rows["public_t1"] = (
        origin_rows,
        lake_rows,
    )
    return process(make_table(column=None), PERIOD, behaviour), behaviour


def test_equal_and_different_whole_table_totals():
    done, behaviour = whole_run(100, 100)
    result = done.result
    assert (result.status, result.basis, result.filter_column) == (
        ResultStatus.EQUAL,
        Basis.TOTAL,
        None,
    )
    assert (result.origin_total, result.lake_total, result.diff) == (100, 100, 0)
    assert result.days == [] and done.progress.state is TableState.DONE
    assert result.facts.origin_size_bytes == 1234
    assert behaviour.windows == [], "no per-day count for a table without a column"
    different, _ = whole_run(100, 90)
    assert (different.result.status, different.result.diff) == (
        ResultStatus.DIFFERENT,
        -10,
    )


def test_a_period_is_carried_in_every_result():
    done, _ = whole_run(1, 1)
    assert done.result.period == Period(dt.date(2026, 9, 10), dt.date(2026, 9, 11))

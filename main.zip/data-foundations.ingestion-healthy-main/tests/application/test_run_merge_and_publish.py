"""Runs of some tables merge into what is published; a full run replaces it."""

import pytest

from app.domain.exceptions import InvalidRequest
from tests.support.runs import (
    key_of,
    keys_of,
    make_world,
    set_behaviour,
    wait_until,
)
from tests.support.world import World, start_all


def full_run(world: World) -> None:
    assert world.run_to_end(start_all(world))["status"] == "succeeded"


def subset(world: World, keys, date_from="2026-09-10", date_to="2026-09-11"):
    return world.start.execute(date_from, date_to, keys)


def test_rerunning_some_tables_keeps_the_others_published():
    world = World()
    full_run(world)
    before = dict(world.results.current)
    pods_before = len(world.pods.launched)
    run_id = subset(world, keys_of(world, "t3"))
    snap = world.run_to_end(run_id)
    assert (snap["status"], snap["merge"]) == ("succeeded", True)
    assert len(world.pods.launched) - pods_before == 1, "one server, one pod"
    assert set(world.results.current) == set(before)
    t1 = key_of(world, "t1")
    assert world.results.current[t1] == before[t1]
    assert sum(len(r.days) for r in world.results.current.values()) == 8


def test_each_table_keeps_its_own_period():
    world = World()
    full_run(world)
    periods = {r.period for r in world.results.current.values()}
    assert len(periods) == 1
    before = dict(world.results.current)
    world.run_to_end(subset(world, keys_of(world, "t3"), "2026-09-10", "2026-09-12"))
    current = world.results.current
    t3 = current[key_of(world, "t3")]
    assert (str(t3.period.start), str(t3.period.end)) == ("2026-09-10", "2026-09-12")
    assert len(t3.days) == 3
    assert current[key_of(world, "t1")] == before[key_of(world, "t1")]
    assert len(current) == 4, "nothing was lost"


def test_unknown_or_empty_table_lists_are_rejected():
    world = World()
    unknown = "DB9.public.nope@trusted_zone.trusted_db9.public_nope"
    with pytest.raises(InvalidRequest):
        subset(world, [unknown])
    with pytest.raises(InvalidRequest):
        subset(world, [])
    assert not world.pods.launched


def test_a_full_run_is_promoted_once_at_the_end():
    world = make_world(run_timeout=300, publish_every=10)
    world.pod_behaviour[("w3", 1)] = "hang"
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "completed_with_errors", snap
    assert len(world.results.batches) == 1, "the page never shows a half result"
    assert len(world.results.batches[0][1]) == 4
    assert "published" not in snap


def test_a_subset_run_publishes_finished_tables_before_it_ends():
    world = make_world(run_timeout=300, publish_every=10)
    full_run(world)
    old = dict(world.results.current)
    world.results.batches.clear()
    world.pod_behaviour[("w2", 1)] = "hang"  # t4 (server C) never finishes
    chosen = keys_of(world, "t3", "t4")
    snap = world.run_to_end(subset(world, chosen))
    first_batch = world.results.batches[0][1]
    assert first_batch == keys_of(world, "t3"), "t3 is out before the run ends"
    assert snap["published"] >= 1
    current = world.results.current
    assert len(current) == 4, "no row ever disappears"
    for name in ("t1", "t2"):
        assert current[key_of(world, name)] == old[key_of(world, name)]
    assert current[key_of(world, "t4")].error, "the stuck table ends as an error"


def test_tables_already_in_the_catalog_are_flagged_in_the_run_state():
    world = make_world(publish_every=0)
    run_id = subset(world, keys_of(world, "t3", "t4"))
    snap = world.run_to_end(run_id)
    assert snap["status"] == "succeeded", snap
    assert all(t.get("published") for t in snap["tables"].values()), snap["tables"]


def test_tables_of_the_run_are_reported_in_its_state():
    world = make_world()
    set_behaviour(world, "hang")
    chosen = keys_of(world, "t1", "t3")
    run_id = subset(world, chosen)
    wait_until(lambda: world.pods.pods)
    state = world.states.get(run_id)
    assert set(state.tables) == set(chosen)
    assert state.counts.total == 2
    world.cancel.execute()
    world.run_to_end(run_id)

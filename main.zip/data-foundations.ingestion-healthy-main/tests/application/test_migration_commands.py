import pytest

from app.application.use_cases.migration_commands import (
    GetMigrationValidation,
    ImportMigrationDatabases,
    ListMigrationOverview,
    RegisterValidation,
)
from app.domain.exceptions import InvalidRequest, NotFound
from tests.support.migration_fakes import MemoryMigrationValidations, sample_document

LIST = [
    {
        "database": "MGM_REFERRAL",
        "host_sql": "10.0.0.1",
        "host_postgresql": "pg",
        "observacao": "",
    },
    {
        "database": "OTHER",
        "host_sql": "",
        "host_postgresql": "",
        "observacao": "sem host",
    },
]


def _repo():
    repo = MemoryMigrationValidations()
    ImportMigrationDatabases(repo).execute(LIST)
    return repo


def test_the_list_is_imported_and_validated():
    repo = _repo()
    assert set(repo.databases) == {"MGM_REFERRAL", "OTHER"}
    for bad in (None, [], "x", [{"database": "a b"}], [3]):
        with pytest.raises(InvalidRequest):
            ImportMigrationDatabases(repo).execute(bad)


def test_a_validation_needs_a_known_database():
    repo = MemoryMigrationValidations()
    with pytest.raises(NotFound):
        RegisterValidation(repo).execute(sample_document(), "bruno")


def test_a_registered_validation_shows_in_the_overview_and_the_detail():
    repo = _repo()
    RegisterValidation(repo).execute(sample_document(), "  bruno ")
    assert repo.runs[0][1] == "bruno"
    rows = {r.name: r for r in ListMigrationOverview(repo).execute()}
    assert rows["MGM_REFERRAL"].validated and rows["MGM_REFERRAL"].counts.attention == 1
    assert not rows["OTHER"].validated
    view = GetMigrationValidation(repo).execute("MGM_REFERRAL")
    assert view.run is not None and view.run.target_db == "mgm_referral"
    assert GetMigrationValidation(repo).execute("OTHER").run is None


def test_the_latest_run_wins_and_unknown_databases_are_not_found():
    repo = _repo()
    RegisterValidation(repo).execute(sample_document(), "a")
    doc = sample_document()
    doc["tables"].pop()
    RegisterValidation(repo).execute(doc, "b")
    assert (
        GetMigrationValidation(repo).execute("MGM_REFERRAL").run.counts.attention == 0
    )
    with pytest.raises(NotFound):
        GetMigrationValidation(repo).execute("NOPE")

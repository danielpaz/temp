"""Several runs at once: exclusion, limits, dead runs and old states."""

import threading

import pytest

from app.domain.exceptions import Conflict
from app.domain.progress import TableState
from tests.support.runs import (
    hang_all,
    key_of,
    keys_of,
    make_world,
    seed_run,
    wait_until,
)
from tests.support.world import World, start_all


def finish_hung(world: World) -> None:
    world.cancel.execute()
    for _ in range(400):
        world.spawner.join(0.05)
        if not any(t.is_alive() for t in world.spawner.threads):
            return


def subset(world: World, *names: str) -> str:
    return world.start.execute("2026-09-10", "2026-09-11", keys_of(world, *names))


def test_runs_of_different_tables_go_at_the_same_time_and_none_is_lost():
    world = make_world()
    world.run_to_end(start_all(world))
    world.behaviour.per_day.update({"t3": 111, "t4": 222})
    world.behaviour.lake_per_day.update({"t3": 111, "t4": 222})
    a, b = subset(world, "t3"), subset(world, "t4")
    world.run_to_end(a)
    assert world.states.get(a).status.value == "succeeded"
    assert world.states.get(b).status.value == "succeeded"
    totals = {
        k.split(".")[2].split("@")[0]: r.origin_total
        for k, r in world.results.current.items()
    }
    assert totals == {"t1": 10, "t2": 10, "t3": 222, "t4": 444}


def test_the_same_table_cannot_be_updated_twice_at_once():
    world = make_world()
    hang_all(world)
    subset(world, "t3")
    with pytest.raises(Conflict) as error:
        subset(world, "t3")
    assert key_of(world, "t3") in str(error.value)
    subset(world, "t4")  # another table is fine
    finish_hung(world)


def test_a_full_run_refuses_to_start_while_a_subset_is_active():
    world = make_world()
    hang_all(world)
    subset(world, "t3")
    with pytest.raises(Conflict):
        start_all(world)
    finish_hung(world)


def test_a_subset_refuses_to_start_while_a_full_run_is_active():
    world = make_world()
    hang_all(world)
    start_all(world)
    with pytest.raises(Conflict) as error:
        subset(world, "t1")
    assert "completa" in str(error.value)
    finish_hung(world)


def test_the_number_of_simultaneous_runs_is_limited():
    world = make_world(max_runs=2)
    hang_all(world)
    subset(world, "t1")
    subset(world, "t3")
    with pytest.raises(Conflict) as error:
        subset(world, "t4")
    assert "2" in str(error.value)
    finish_hung(world)


def test_status_is_one_view_over_all_active_runs():
    world = make_world()
    hang_all(world)
    subset(world, "t3")
    subset(world, "t4")
    view = world.status.execute()
    assert view["status"] == "running"
    assert (view["active_runs"], view["full"]) == (2, False)
    assert view["counts"]["total"] == 2
    assert sorted(view["tables"]) == sorted(keys_of(world, "t3", "t4"))
    finish_hung(world)


def test_busy_tables_are_those_of_runs_in_progress_only():
    world = make_world()
    hang_all(world)
    subset(world, "t3")
    assert world.busy.execute() == set(keys_of(world, "t3"))
    finish_hung(world)
    done = World()
    done.run_to_end(start_all(done))
    assert done.busy.execute() == set()


def test_second_full_start_while_running_is_rejected():
    world = World()
    seed_run(world, "r0", merge=False)
    with pytest.raises(Conflict):
        start_all(world)
    assert not world.pods.launched


def test_stale_run_is_reported_interrupted_and_can_be_taken_over():
    world = World()
    seed_run(world, "r0", age=500, merge=False)
    assert world.status.execute()["status"] == "interrupted"
    run_id = start_all(world)
    snap = world.run_to_end(run_id)
    assert run_id != "r0"
    assert snap["status"] == "succeeded"


def test_a_dead_run_is_reaped_and_frees_its_tables():
    world = World()
    pods = world.pods
    t3 = key_of(world, "t3")
    seed_run(world, "r0", age=500, keys={t3: TableState.RUNNING})
    run_id = subset(world, "t3")
    assert world.states.get("r0").status.value == "interrupted"
    assert "r0" in world.history.finished_runs
    assert not [p for p in pods.launched if p.run_id == "r0"]
    snap = world.run_to_end(run_id)
    assert snap["status"] == "succeeded"


def test_old_finished_states_are_pruned():
    world = make_world(keep_finished=2)
    for i in range(4):
        seed_run(world, f"old{i}", "succeeded", started_at=10 + i, age=0)
    hang_all(world)
    subset(world, "t1")
    left = set(world.states.items)
    assert {"old0", "old1"}.isdisjoint(left), "the oldest finished are dropped"
    assert {"old2", "old3"} <= left
    finished = [s for s in world.states.list() if s.status.value != "running"]
    assert len(finished) == 2
    finish_hung(world)


def test_concurrent_starts_only_one_wins():
    world = make_world()
    hang_all(world)
    results = []

    def go():
        try:
            start_all(world)
            results.append("ok")
        except Conflict:
            results.append("conflict")

    threads = [threading.Thread(target=go) for _ in range(5)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert sorted(results) == ["conflict"] * 4 + ["ok"]
    wait_until(lambda: world.pods.launched)
    finish_hung(world)


def test_a_state_creation_conflict_is_a_conflict_and_closes_the_history():
    world = World()

    def exists(_state):
        raise Conflict("exists")

    world.states.create = exists
    with pytest.raises(Conflict):
        start_all(world)
    (state,) = world.history.finished_runs.values()
    assert state.status.value == "failed"
    assert not world.pods.launched

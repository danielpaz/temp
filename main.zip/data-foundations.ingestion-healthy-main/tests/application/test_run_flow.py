from tests.support.world import World, start_all


def test_full_run_publishes_every_table_and_removes_pods():
    world = World()
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "succeeded", snap
    assert len(world.results.current) == 4
    assert len(world.pods.launched) == 3
    assert not world.pods.pods


def test_failed_pod_is_retried_and_results_still_published():
    world = World()
    world.pod_behaviour[("w1", 1)] = "fail"
    run_id = start_all(world)
    snap = world.run_to_end(run_id)
    assert snap["status"] == "succeeded", snap
    assert len(world.results.current) == 4
    assert any(p.attempt == 2 for p in world.pods.launched)


def test_gives_up_after_max_attempts():
    world = World()
    for attempt in (1, 2, 3):
        world.pod_behaviour[("w1", attempt)] = "vanish"
    run_id = start_all(world)
    snap = world.run_to_end(run_id)
    assert snap["counts"]["error"] >= 1, snap
    assert len(world.results.current) == 4


def test_subset_run_merges_only_its_tables():
    world = World()
    chosen = [
        str(t.key) for t in world.registry.tables if t.key.source_table in ("t1", "t3")
    ]
    run_id = world.start.execute("2026-09-10", "2026-09-11", chosen)
    snap = world.run_to_end(run_id)
    assert snap["status"] == "succeeded", snap
    assert snap["merge"] is True
    assert set(world.results.current) == set(chosen)
    assert len(world.results.current) == 2


def test_hung_pod_ends_in_error_by_run_timeout():
    from app.domain.run import RunRules
    from tests.support.world import RULES

    rules = RunRules(retry=RULES.retry, run_timeout=200, heartbeat_ttl=30)
    world = World(rules=rules)
    for attempt in (1, 2, 3):
        world.pod_behaviour[("w1", attempt)] = "hang"
    snap = world.run_to_end(start_all(world))
    assert snap["counts"]["error"] >= 1, snap


def test_second_full_run_is_refused_while_one_is_active():
    import pytest

    from app.domain.exceptions import Conflict

    world = World()
    world.pod_behaviour[("w1", 1)] = "pending"
    start_all(world)
    with pytest.raises(Conflict):
        start_all(world)
    world.cancel.execute()

"""Stopping tables of runs in progress."""

import pytest

from app.domain.exceptions import Conflict, InvalidRequest
from app.domain.progress import TableProgress, TableState, WorkerProgress
from tests.support.runs import (
    hang_all,
    keys_of,
    make_world,
    only_run_id,
    set_behaviour,
    wait_until,
)
from tests.support.world import World

ALL = ("t1", "t2", "t3", "t4")


def start_four(world: World) -> str:
    keys = keys_of(world, *ALL)
    run_id = world.start.execute("2026-09-10", "2026-09-11", keys)
    wait_until(lambda: len(world.pods.launched) >= 3)
    return run_id


def test_stopping_some_tables_keeps_old_results_and_publishes_the_rest():
    world = make_world()
    set_behaviour(world, "hang", ["w1"])
    run_id = start_four(world)
    t1, t2, t3, t4 = keys_of(world, *ALL)
    assert world.cancel.execute([t1]) == 1
    assert world.cancel.execute([t2]) == 1  # host A has nothing left: pod dropped
    snap = world.run_to_end(run_id)
    assert snap["status"] == "succeeded", snap
    states = {k: v["state"] for k, v in snap["tables"].items()}
    assert states == {t1: "cancelled", t2: "cancelled", t3: "done", t4: "done"}
    assert snap["counts"] == {"total": 4, "done": 2, "error": 0, "cancelled": 2}
    assert "2 tabela(s) interrompida(s)" in snap["message"]
    assert set(world.results.current) == {t3, t4}, "stopped tables get no result"
    assert world.progress.cancelled(run_id) == {t1, t2}
    assert not world.pods.pods


def test_stopping_everything_ends_the_run_as_cancelled():
    world = make_world()
    hang_all(world)
    run_id = start_four(world)
    assert world.cancel.execute() == 4
    snap = world.run_to_end(run_id)
    assert (snap["status"], snap["message"]) == (
        "cancelled",
        "Atualização interrompida.",
    )
    assert snap["counts"] == {"total": 4, "done": 0, "error": 0, "cancelled": 4}
    assert not world.pods.pods
    assert world.results.current == {}, "nothing finished: nothing published"


def test_a_running_table_gets_its_pod_replaced_without_using_an_attempt():
    world = make_world()
    set_behaviour(world, "hang", ["w1"], [1])
    run_id = start_four(world)
    t1, t2 = keys_of(world, "t1", "t2")
    world.progress.save_worker(
        run_id,
        WorkerProgress(
            "w1",
            "A",
            "1",
            tables={
                t1: TableProgress(TableState.RUNNING, 1),
                t2: TableProgress(TableState.PENDING, 0),
            },
        ),
    )
    world.cancel.execute([t1])
    wait_until(
        lambda: any(p.worker_id == "w1" and p.attempt == 2 for p in world.pods.launched)
    )
    snap = world.run_to_end(run_id)
    assert snap["tables"][t1]["state"] == "cancelled"
    assert snap["tables"][t2]["state"] == "done", "the new pod does the rest"
    assert snap["status"] == "succeeded", snap
    assert not any(p.attempt == 3 for p in world.pods.launched)


def test_nothing_to_stop_is_refused():
    world = World()
    with pytest.raises(Conflict):
        world.cancel.execute()


def test_unknown_tables_are_refused_while_a_run_is_active():
    world = make_world()
    hang_all(world)
    run_id = start_four(world)
    assert only_run_id(world) == run_id
    with pytest.raises(InvalidRequest):
        world.cancel.execute(["X.y.z@a.b.c"])
    world.cancel.execute()
    world.run_to_end(run_id)

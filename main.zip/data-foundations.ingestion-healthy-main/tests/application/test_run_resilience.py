"""A run survives pods that fail, vanish, hang or never start."""

from app.domain.comparison import ResultStatus
from tests.support.fakes import make_table
from tests.support.runs import key_of, make_world, set_behaviour
from tests.support.world import World, start_all


def attempts(world: World, number: int) -> list:
    return [p for p in world.pods.launched if p.attempt == number]


def test_one_pod_per_server_and_results_published():
    world = World()
    run_id = start_all(world)
    snap = world.run_to_end(run_id)
    assert snap["status"] == "succeeded", snap
    names = sorted(p.pod_name for p in world.pods.launched)
    assert names == sorted(f"ih-{run_id}-w{i}-a1" for i in (1, 2, 3))
    assert snap["counts"] == {"total": 4, "done": 4, "error": 0, "cancelled": 0}
    assert len(world.results.current) == 4
    assert sum(len(r.days) for r in world.results.current.values()) == 8
    assert not world.pods.pods, "worker pods are cleaned up"


def test_exactly_one_pod_per_host_with_its_secret():
    world = World()
    run_id = start_all(world)
    world.run_to_end(run_id)
    pairs = sorted((p.host, p.secret) for p in world.pods.launched)
    assert pairs == [("A", "prod/x/A"), ("B", "prod/x/B"), ("C", "prod/x/C")]
    assert {p.run_id for p in world.pods.launched} == {run_id}


def test_failed_pod_is_retried_and_resumes_without_redoing_tables():
    world = make_world()
    world.pod_behaviour[("w1", 1)] = "fail"
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "succeeded", snap
    assert [p.worker_id for p in attempts(world, 2)] == ["w1"]
    t1_windows = [w for w in world.behaviour.windows if w[0] == "t1"]
    assert len(t1_windows) == 1, "the table finished before the crash is kept"


def test_vanished_pod_is_retried():
    world = make_world()
    world.pod_behaviour[("w3", 1)] = "vanish"
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "succeeded", snap
    assert [p.worker_id for p in attempts(world, 2)] == ["w3"]


def test_pod_stuck_in_pending_is_retried():
    world = make_world()
    world.pod_behaviour[("w1", 1)] = "pending"
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "succeeded", snap
    assert [p.worker_id for p in attempts(world, 2)] == ["w1"]


def test_gives_up_after_max_attempts_and_reports_the_failed_table():
    world = make_world()
    world.poison = {"t2"}
    set_behaviour(world, "poison", ["w1"])
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "completed_with_errors", snap
    assert snap["counts"] == {"total": 4, "done": 3, "error": 1, "cancelled": 0}
    assert [p.worker_id for p in attempts(world, 3)] == ["w1"]
    assert not attempts(world, 4)
    results = {k.source_table: r for k, r in _by_table(world).items()}
    assert results["t3"].status is ResultStatus.EQUAL
    assert results["t1"].status is ResultStatus.EQUAL, "finished before the crash"
    assert results["t2"].status is ResultStatus.ERROR
    assert "OOMKilled" in results["t2"].error
    error = snap["tables"][_key(world, "t2")]["error"]
    assert "3 tentativas" in error


def test_all_workers_failing_still_keeps_the_tables_finished_before():
    world = make_world()
    world.poison = {"t2", "t3", "t4"}
    set_behaviour(world, "poison")
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "completed_with_errors", snap
    assert snap["counts"] == {"total": 4, "done": 1, "error": 3, "cancelled": 0}
    assert len(world.results.current) == 4


def test_every_table_failing_is_a_failed_run():
    world = make_world()
    world.pod_behaviour.update(
        {(w, a): "vanish" for w in ("w1", "w2", "w3") for a in (1, 2, 3)}
    )
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "failed", snap
    assert snap["counts"]["error"] == 4


def test_run_timeout_marks_unfinished_tables_as_errors():
    world = make_world(run_timeout=200, heartbeat_ttl=30)
    world.pod_behaviour[("w1", 1)] = "hang"
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "completed_with_errors", snap
    assert "tempo limite" in snap["tables"][_key(world, "t1")]["error"]
    assert snap["tables"][_key(world, "t3")]["state"] == "done"
    assert not world.pods.pods


def test_a_host_with_two_secrets_gets_a_pod_per_secret():
    tables = [
        make_table("DB1", "public", "t1", "prod/x/A", "A"),
        make_table("DB1", "public", "t2", "prod/x/another", "A"),
        make_table("DB2", "dbo", "t3", "prod/x/B", "B"),
        make_table("DB3", "public", "t4", "prod/x/C", "C"),
    ]
    world = make_world(tables)
    snap = world.run_to_end(start_all(world))
    assert snap["status"] == "succeeded", snap
    assert snap["counts"] == {"total": 4, "done": 4, "error": 0, "cancelled": 0}
    assert len(world.pods.launched) == 4, "3 hosts, one with 2 secrets: 4 pods"
    assert len({(w["host"], w["secret"]) for w in snap["workers"].values()}) == 4


def _by_table(world: World) -> dict:
    return {r.key: r for r in world.results.current.values()}


def _key(world: World, name: str) -> str:
    return key_of(world, name)

"""Wiring of the HTTP adapter over fakes, with a recording registry."""

from __future__ import annotations

import datetime as dt
from typing import List, Optional

from fastapi.testclient import TestClient

from app.adapters.inbound.http.app import create_app
from app.adapters.inbound.http.services import HttpServices
from app.application.ports.registry import RegistryQueries
from app.application.ports.secrets import SecretsProvider
from app.application.read_models import SourceDefinitionView
from app.application.use_cases.migration_commands import (
    GetMigrationValidation,
    ImportMigrationDatabases,
    ListMigrationOverview,
    RegisterValidation,
)
from app.application.use_cases.registry_commands import (
    CreateTable,
    DeleteTable,
    EditTable,
    GetSourceDefinition,
    ListAudit,
    ListResults,
    ListTags,
)
from app.domain.exceptions import NotFound
from app.domain.run import RunRules
from app.domain.values import TableKey
from tests.support.fakes import MemoryRegistry
from tests.support.migration_fakes import MemoryMigrationValidations
from tests.support.world import RULES, World

# a fake clock runs fast: a held run must not hit a deadline
PATIENT = RunRules(
    retry=RULES.retry,
    poll=4.0,
    run_timeout=1e12,
    pending_timeout=1e12,
    heartbeat_ttl=1e12,
)

JSON = {"Content-Type": "application/json"}


class RecordingRegistry(MemoryRegistry):
    """Remembers what it was asked; `fail` is raised by every command."""

    def __init__(self, tables) -> None:
        super().__init__(tables)
        self.calls: List[tuple] = []
        self.fail: Optional[Exception] = None
        self.hosts: List[str] = []

    def _run(self, name: str, *args) -> None:
        if self.fail:
            raise self.fail
        self.calls.append((name,) + args)

    def create(self, new, host, actor) -> int:
        self._run("create", new, host, actor)
        return 7

    def update(self, key, changes, resolve_host, actor) -> List[str]:
        self._run("update", key, changes, actor)
        if changes.names.get("used_secret"):
            self.hosts.append(resolve_host(changes.names["used_secret"]))
        return ["tags"]

    def delete(self, key, actor) -> None:
        self._run("delete", key, actor)


class StubSecrets(SecretsProvider):
    def __init__(self) -> None:
        self.asked: List[str] = []

    def connection(self, name: str):
        raise NotImplementedError

    def host_of(self, name: str) -> str:
        self.asked.append(name)
        return "h1.example"


class StubQueries(RegistryQueries):
    def __init__(self) -> None:
        self.found: Optional[SourceDefinitionView] = None
        self.error: Optional[Exception] = None

    def overview(self):
        return []

    def version(self) -> tuple:
        return ()

    def known_tags(self):
        return []

    def audit(self, key, limit):
        return []

    def source_definition(self, key: TableKey):
        if self.error:
            raise self.error
        return self.found


DEFINITION = SourceDefinitionView(
    table="a.b.c@d.e.f",
    ddl="CREATE TABLE ...",
    indexes=[],
    columns=1,
    checked_at=None,
    filter_column=None,
)


class Rig:
    """A client over a `World` plus the doubles the table endpoints need."""

    def __init__(self, busy=None) -> None:
        self.world = World(rules=PATIENT)
        self.registry = RecordingRegistry(self.world.registry.tables)
        self.secrets = StubSecrets()
        self.queries = StubQueries()
        self.migrations = MemoryMigrationValidations()
        services = HttpServices(
            start_run=self.world.start,
            cancel_run=self.world.cancel,
            run_status=self.world.status,
            list_results=ListResults(self.queries),
            list_tags=ListTags(self.queries),
            list_audit=ListAudit(self.queries),
            source_definition=GetSourceDefinition(self.queries),
            create_table=CreateTable(self.registry, self.secrets),
            edit_table=EditTable(self.registry, self.secrets),
            delete_table=DeleteTable(self.registry, busy or self.world.busy),
            import_migration_databases=ImportMigrationDatabases(self.migrations),
            register_validation=RegisterValidation(self.migrations),
            migration_overview=ListMigrationOverview(self.migrations),
            migration_validation=GetMigrationValidation(self.migrations),
        )
        self.client = TestClient(create_app(services), raise_server_exceptions=False)

    @property
    def hosts(self) -> List[str]:
        return self.registry.hosts

    def hold_runs(self) -> None:
        """Every worker pod stays pending, so a run stays in progress."""
        for worker in range(1, 5):
            for attempt in range(1, 4):
                self.world.pod_behaviour[(f"w{worker}", attempt)] = "pending"


def unknown_table() -> Exception:
    return NotFound("Tabela desconhecida.")


__all__ = ["JSON", "DEFINITION", "Rig", "dt", "unknown_table"]

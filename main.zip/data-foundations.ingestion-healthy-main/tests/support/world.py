"""A whole system in memory: the supervisor side and a simulated cluster whose
pods run the real worker job."""

from __future__ import annotations

import threading
from typing import Dict, Set, Tuple

from app.application.concurrency import SingleFlight
from app.application.use_cases.comparers import (
    DailyComparer,
    IdComparer,
    WholeTableComparer,
)
from app.application.use_cases.coordinator import RunCoordinator, RunReaper
from app.application.use_cases.fleet import WorkerFleet
from app.application.use_cases.origin_day_counter import OriginDayCounter
from app.application.use_cases.process_table import ProcessTable
from app.application.use_cases.publisher import ResultPublisher
from app.application.use_cases.run_commands import (
    BusyTables,
    CancelRun,
    GetRunStatus,
    StartRun,
)
from app.application.use_cases.supervisor import RunSupervisor
from app.application.use_cases.worker_job import RunWorkerJob
from app.domain.policies import RetryPolicy, WindowPlanner
from app.domain.run import RunRules
from app.domain.values import Criterion
from tests.support.fakes import (
    Behaviour,
    FakeClock,
    FakeLakeFactory,
    FakeOriginFactory,
    FakePods,
    InlineSpawner,
    MemoryHistory,
    MemoryProgressStore,
    MemoryRegistry,
    MemoryResults,
    MemoryStateStore,
    WorkerClock,
    standard_tables,
)

RULES = RunRules(retry=RetryPolicy(3, (1, 2)), poll=4.0)


class World:
    """`pod_behaviour` maps (worker id, attempt) to "ok" (default), "fail",
    "hang", "vanish", "pending" or
    "poison" (crashes on the tables in `poison`, the others finish first);
    set it before starting the run."""

    def __init__(self, tables=None, rules: RunRules = RULES) -> None:
        self.rules = rules
        self.clock = FakeClock()
        self.behaviour = Behaviour()
        self.registry = MemoryRegistry(tables or standard_tables())
        self.states = MemoryStateStore()
        self.progress = MemoryProgressStore()
        self.pods = FakePods(self.clock)
        self.results = MemoryResults()
        self.history = MemoryHistory()
        self.spawner = InlineSpawner()
        self.pod_behaviour: Dict[Tuple[str, int], str] = {}
        # source tables whose comparison crashes the pod ("poison" behaviour)
        self.poison: Set[str] = set()
        self.job_threads: Dict[str, threading.Thread] = {}
        self.job_errors: Dict[str, str] = {}
        self.origins = FakeOriginFactory(self.behaviour)
        self.lakes = FakeLakeFactory(self.behaviour)
        self._wire()
        self.clock.on_sleep = self._step

    def _wire(self) -> None:
        r, c = self.rules, self.clock
        self.coordinator = RunCoordinator()
        self.reaper = RunReaper(self.states, self.pods, self.history, c, r)
        fleet = WorkerFleet(self.pods, c, r)
        supervisor = RunSupervisor(
            self.states,
            self.progress,
            self.pods,
            fleet,
            ResultPublisher(self.results),
            self.history,
            c,
            r,
        )
        self.start = StartRun(
            self.registry,
            self.states,
            self.history,
            self.reaper,
            self.coordinator,
            supervisor,
            self.spawner,
            c,
            r,
        )
        self.cancel = CancelRun(self.progress, self.reaper, self.coordinator)
        self.status = GetRunStatus(self.states, self.coordinator, c, r)
        self.busy = BusyTables(self.states, c, r)

    def worker_job(self) -> RunWorkerJob:
        clock = WorkerClock(self.clock)
        counter = OriginDayCounter(WindowPlanner(3, 10**9), SingleFlight(), 60, 30)
        comparers = {
            Criterion.DATE: DailyComparer(counter),
            Criterion.ID: IdComparer(),
            Criterion.TOTAL: WholeTableComparer(),
        }
        process = ProcessTable(comparers, self.rules.retry, clock.sleep)
        return RunWorkerJob(
            self.progress,
            self.origins,
            self.lakes,
            process,
            clock,
            log=lambda _line: None,
        )

    def _step(self) -> None:
        for name, pod in list(self.pods.pods.items()):
            pod["age"] += 1
            launch = pod["launch"]
            key = (launch.worker_id, launch.attempt)
            self._advance(name, pod, self.pod_behaviour.get(key, "ok"))

    def _advance(self, name: str, pod: dict, behaviour: str) -> None:
        if behaviour == "pending":
            return
        if behaviour == "vanish" and pod["age"] == 2:
            self.pods.pods.pop(name, None)
        elif pod["age"] == 1:
            pod["phase"] = "Running"
        elif pod["age"] == 3 and behaviour != "hang":
            self._run_job(name, pod, behaviour)
        elif name in self.job_threads and not self.job_threads[name].is_alive():
            if pod["phase"] == "Running":
                failed = name in self.job_errors
                pod["phase"] = "Failed" if failed else "Succeeded"
                pod["reason"] = "OOMKilled (exit 137)" if failed else ""

    def _run_job(self, name: str, pod: dict, behaviour: str) -> None:
        launch = pod["launch"]

        def work() -> None:
            try:
                if behaviour == "fail":
                    self._fail_after_first_table(launch)
                elif behaviour == "poison":
                    self._run_poisoned(launch)
                else:
                    self.worker_job().run(
                        launch.run_id,
                        launch.worker_id,
                        launch.host,
                        launch.secret,
                        str(launch.attempt),
                    )
            except Exception as error:
                self.job_errors[name] = repr(error)

        thread = threading.Thread(target=work, daemon=True)
        self.job_threads[name] = thread
        thread.start()
        thread.join(20)

    def _run_poisoned(self, launch) -> None:
        job = self.worker_job()
        real = job.process.run

        def crash_on_poison(table, *args, **kwargs):
            if table.key.source_table in self.poison:
                raise RuntimeError("pod crashed")
            return real(table, *args, **kwargs)

        job.process.run = crash_on_poison
        job.run(
            launch.run_id,
            launch.worker_id,
            launch.host,
            launch.secret,
            str(launch.attempt),
        )

    def _fail_after_first_table(self, launch) -> None:
        job = self.worker_job()
        real = job.process.run
        calls = []

        def crash_on_second(*args, **kwargs):
            if calls:
                raise RuntimeError("pod crashed")
            calls.append(1)
            return real(*args, **kwargs)

        job.process.run = crash_on_second
        job.run(
            launch.run_id,
            launch.worker_id,
            launch.host,
            launch.secret,
            str(launch.attempt),
        )

    def run_to_end(self, run_id: str, limit: int = 2000) -> dict:
        """Lets the supervisor thread go on until the run is over."""
        for _ in range(limit):
            self.spawner.join(0.05)
            if not any(t.is_alive() for t in self.spawner.threads):
                break
        return self.states.get(run_id).snapshot()


def start_all(world: World, date_from="2026-09-10", date_to="2026-09-11") -> str:
    return world.start.execute(date_from, date_to)

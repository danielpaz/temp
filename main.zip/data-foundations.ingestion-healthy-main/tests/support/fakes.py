"""In-memory stand-ins for every port, and a simulated cluster, so the use cases
run end to end without any network."""

from __future__ import annotations

import datetime as dt
import threading
import time
from typing import Callable, Dict, List, Optional, Sequence, Set, Tuple

from app.application.ports.cluster import RunStateStore, WorkerLaunch, WorkerPods
from app.application.ports.lake import LakeReader, LakeReaderFactory
from app.application.ports.origin import (
    OriginReader,
    OriginReaderFactory,
    OriginStats,
    OriginTable,
)
from app.application.ports.progress import ProgressStore
from app.application.ports.registry import ResultStore, RunHistory, TableRegistry
from app.application.ports.runtime import Clock, Spawner
from app.domain.comparison import (
    ComparisonResult,
    LakeObject,
    OriginDefinition,
    TableFacts,
)
from app.domain.entities import MonitoredTable
from app.domain.exceptions import Conflict, NotFound, PermanentError
from app.domain.progress import RunPlan, WorkerProgress
from app.domain.registry_rules import NewTable, TableChanges
from app.domain.run import PodInfo, RunState
from app.domain.values import (
    DayMode,
    FilterKind,
    ObjectType,
    Period,
    TableKey,
)

PERIOD = Period(dt.date(2026, 9, 10), dt.date(2026, 9, 11))


def make_table(
    database: str = "DB1",
    schema: str = "public",
    table: str = "t1",
    secret: str = "prod/x/A",
    host: str = "A",
    column: Optional[str] = "created_at_dt",
    kind: FilterKind = FilterKind.DATE,
    mode: DayMode = DayMode.SAO_PAULO,
    enabled: bool = True,
    table_id: Optional[int] = None,
) -> MonitoredTable:
    key = TableKey(
        database,
        schema,
        table,
        "trusted_zone",
        f"trusted_{database.lower()}",
        f"{schema}_{table}",
    )
    return MonitoredTable(
        key=key,
        secret=secret,
        host=host,
        filter_column=column,
        filter_kind=kind,
        day_mode=mode,
        enabled=enabled,
        id=table_id,
    )


def standard_tables() -> List[MonitoredTable]:
    """Host A has two tables (one secret), B and C one each."""
    return [
        make_table("DB1", "public", "t1", "prod/x/A", "A"),
        make_table("DB1", "public", "t2", "prod/x/A", "A"),
        make_table("DB2", "dbo", "t3", "prod/x/B", "B"),
        make_table("DB3", "public", "t4", "prod/x/C", "C"),
    ]


class FakeClock(Clock):
    """Time only moves when somebody sleeps; each sleep can step a simulation."""

    def __init__(self, start: float = 1000.0) -> None:
        self.t = start
        self.on_sleep: Callable[[], None] = lambda: None
        self._lock = threading.Lock()

    def now(self) -> float:
        return self.t

    def sleep(self, seconds: float) -> None:
        with self._lock:
            self.t += seconds
            self.on_sleep()
        # a real pause lets concurrent runs take turns on the shared clock,
        # so a run is never seen as dead only because another one spins
        time.sleep(0.0005)


class InlineSpawner(Spawner):
    """Runs the work in a real thread, like production, and remembers it."""

    def __init__(self) -> None:
        self.threads: List[threading.Thread] = []

    def spawn(self, name: str, work: Callable[[], None]) -> None:
        thread = threading.Thread(target=work, daemon=True, name=name)
        self.threads.append(thread)
        thread.start()

    def join(self, timeout: float = 20) -> None:
        for thread in self.threads:
            thread.join(timeout)


class MemoryStateStore(RunStateStore):
    def __init__(self) -> None:
        self.items: Dict[str, dict] = {}
        self._lock = threading.Lock()

    def list(self) -> List[RunState]:
        with self._lock:
            return [RunState.from_snapshot(v) for v in self.items.values()]

    def create(self, state: RunState) -> None:
        with self._lock:
            if state.run_id in self.items:
                raise Conflict("estado da execução já existe")
            self.items[state.run_id] = state.snapshot()

    def replace(self, state: RunState) -> None:
        with self._lock:
            self.items[state.run_id] = state.snapshot()

    def delete(self, run_id: str) -> None:
        with self._lock:
            self.items.pop(run_id, None)

    def get(self, run_id: str) -> RunState:
        return RunState.from_snapshot(self.items[run_id])


class MemoryProgressStore(ProgressStore):
    def __init__(self) -> None:
        self.plans: Dict[str, RunPlan] = {}
        self.workers: Dict[Tuple[str, str], WorkerProgress] = {}
        self.cancel: Dict[str, Set[str]] = {}
        self._lock = threading.Lock()

    def save_plan(self, plan: RunPlan) -> None:
        self.plans[plan.run_id] = plan

    def load_plan(self, run_id: str) -> RunPlan:
        if run_id not in self.plans:
            raise NotFound("plano da execução não encontrado")
        return self.plans[run_id]

    def load_worker(self, run_id: str, worker_id: str) -> Optional[WorkerProgress]:
        with self._lock:
            return self.workers.get((run_id, worker_id))

    def save_worker(self, run_id: str, progress: WorkerProgress) -> None:
        with self._lock:
            self.workers[(run_id, progress.worker_id)] = _copy(progress)

    def request_cancel(self, run_id: str, keys: Set[str]) -> None:
        self.cancel.setdefault(run_id, set()).update(keys)

    def cancelled(self, run_id: str) -> Set[str]:
        return set(self.cancel.get(run_id, set()))


def _copy(progress: WorkerProgress) -> WorkerProgress:
    import copy

    return copy.deepcopy(progress)


class FakePods(WorkerPods):
    def __init__(self, clock: Clock) -> None:
        self.clock = clock
        self.pods: Dict[str, dict] = {}
        self.launched: List[WorkerLaunch] = []
        self._lock = threading.Lock()

    def launch(self, launch: WorkerLaunch) -> None:
        with self._lock:
            self.launched.append(launch)
            self.pods[launch.pod_name] = {
                "launch": launch,
                "phase": "Pending",
                "reason": "",
                "age": 0,
                "created": self.clock.now(),
            }

    def delete(self, pod_name: str) -> None:
        with self._lock:
            self.pods.pop(pod_name, None)

    def list(self, run_id: str) -> List[PodInfo]:
        with self._lock:
            return [
                PodInfo(name, p["phase"], p["reason"], p["created"])
                for name, p in self.pods.items()
                if p["launch"].run_id == run_id
            ]

    def delete_run(self, run_id: str) -> None:
        with self._lock:
            for name in [
                n for n, p in self.pods.items() if p["launch"].run_id == run_id
            ]:
                del self.pods[name]


class MemoryRegistry(TableRegistry):
    def __init__(self, tables: Sequence[MonitoredTable]) -> None:
        self.tables = list(tables)

    def active_tables(self) -> List[MonitoredTable]:
        return [t for t in self.tables if t.enabled]

    def create(self, new: NewTable, host: str, actor: str) -> int:
        raise NotImplementedError

    def update(self, key, changes: TableChanges, resolve_host, actor) -> List[str]:
        raise NotImplementedError

    def delete(self, key: TableKey, actor: str) -> None:
        raise NotImplementedError


class MemoryResults(ResultStore):
    def __init__(self) -> None:
        self.current: Dict[str, ComparisonResult] = {}
        self.batches: List[Tuple[str, List[str]]] = []
        self._lock = threading.Lock()

    def publish(self, run_id, items) -> None:
        with self._lock:
            for table, result in items:
                self.current[str(table.key)] = result
            self.batches.append((run_id, [str(t.key) for t, _ in items]))


class MemoryHistory(RunHistory):
    def __init__(self) -> None:
        self.started_runs: Dict[str, dict] = {}
        self.finished_runs: Dict[str, RunState] = {}

    def started(self, run_id, period, merge, tables, actor) -> None:
        self.started_runs[run_id] = {
            "merge": merge,
            "tables": len(tables),
            "actor": actor,
        }

    def finished(self, run_id: str, state: RunState) -> None:
        self.finished_runs[run_id] = state


class FakeOrigin(OriginReader):
    """Every table has 5 rows a day in the origin unless the behaviour says so."""

    def __init__(self, world: "Behaviour", secret: str, host: str) -> None:
        self.world, self.secret, self.host = world, secret, host
        self.closed = 0

    def find_table(self, schema: str, table: str) -> Optional[OriginTable]:
        if (schema, table) in self.world.missing_in_origin:
            return None
        columns = (("id", "bigint"), ("created_at_dt", "timestamp"))
        return OriginTable(schema, table, columns)

    def stats(self, table: OriginTable, column: str) -> OriginStats:
        return self.world.stats.get(table.table, OriginStats(0, False))

    def size_bytes(self, table: OriginTable) -> Optional[int]:
        return 1234

    def definition(self, table: OriginTable) -> Optional[OriginDefinition]:
        return OriginDefinition(f"CREATE TABLE {table.table} ();", [], 2)

    def count_by_day(self, table, column, start, end_exclusive, timeout_seconds):
        self.world.windows.append((table.table, start, end_exclusive, timeout_seconds))
        error = self.world.window_errors.get((table.table, start, end_exclusive))
        if error is not None:
            raise error
        days = (end_exclusive - start).days
        per = self.world.per_day.get(table.table, 5)
        return {start + dt.timedelta(days=i): per for i in range(days)}

    def count_rows(self, table, id_column=None, up_to=None) -> int:
        self.world.row_counts.append((table.table, id_column, up_to))
        return self.world.origin_rows.get(table.table, 10)

    def close(self) -> None:
        self.closed += 1


class FakeLake(LakeReader):
    def __init__(self, world: "Behaviour") -> None:
        self.world = world

    def inspect_object(self, key: TableKey) -> Optional[LakeObject]:
        return LakeObject(ObjectType.TABLE)

    def column_type(self, key: TableKey, column: str) -> str:
        if key.target_table in self.world.missing_in_lake:
            raise PermanentError("trino query failed: TABLE_NOT_FOUND")
        return self.world.column_types.get(key.target_table, "timestamp(3)")

    def count_by_day(self, key, column, column_type, mode, period):
        per = self.world.lake_per_day.get(key.target_table, 5)
        return {d: per for d in period.days}

    def count_rows(self, key: TableKey) -> int:
        return self.world.lake_rows.get(key.target_table, 10)

    def last_id(self, key: TableKey, column: str):
        return self.world.last_ids.get(key.target_table, (100, 10))


class Behaviour:
    """What the fake databases answer. Tests change these dictionaries."""

    def __init__(self) -> None:
        self.per_day: Dict[str, int] = {}
        self.lake_per_day: Dict[str, int] = {}
        self.origin_rows: Dict[str, int] = {}
        self.lake_rows: Dict[str, int] = {}
        self.last_ids: Dict[str, Tuple[Optional[int], int]] = {}
        self.stats: Dict[str, OriginStats] = {}
        self.column_types: Dict[str, str] = {}
        self.missing_in_origin: Set[Tuple[str, str]] = set()
        self.missing_in_lake: Set[str] = set()
        self.window_errors: Dict[tuple, Exception] = {}
        self.windows: List[tuple] = []
        self.row_counts: List[tuple] = []


class FakeOriginFactory(OriginReaderFactory):
    def __init__(self, behaviour: Behaviour) -> None:
        self.behaviour = behaviour
        self.opened: List[FakeOrigin] = []

    def open(self, secret: str, host: str) -> OriginReader:
        reader = FakeOrigin(self.behaviour, secret, host)
        self.opened.append(reader)
        return reader


class FakeLakeFactory(LakeReaderFactory):
    def __init__(self, behaviour: Behaviour) -> None:
        self.behaviour = behaviour

    def open(self) -> LakeReader:
        return FakeLake(self.behaviour)


def a_result(table: MonitoredTable, period: Period = PERIOD) -> ComparisonResult:
    """A finished comparison, for tests that need progress without running a worker."""
    days = {d: 5 for d in period.days}
    return ComparisonResult.daily(table, period, days, days, TableFacts())


class WorkerClock(Clock):
    """The clock seen by code inside a pod: sleeping moves time, nothing else."""

    def __init__(self, clock: FakeClock) -> None:
        self.clock = clock

    def now(self) -> float:
        return self.clock.t

    def sleep(self, seconds: float) -> None:
        self.clock.t += seconds

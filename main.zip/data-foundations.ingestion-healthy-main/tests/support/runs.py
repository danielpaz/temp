"""Helpers for the tests of run orchestration."""

from __future__ import annotations

import time
from typing import Callable, Dict, Iterable

from app.domain.progress import TableState
from app.domain.run import RunCounts, RunRules, RunState, TableRun
from app.domain.values import Period
from tests.support.fakes import PERIOD
from tests.support.world import RULES, World

WORKERS = ("w1", "w2", "w3", "w4")
ATTEMPTS = (1, 2, 3, 4)


def rules(**changes) -> RunRules:
    """The test rules; the run timeout is huge so a hanging pod stays hung."""
    base = dict(retry=RULES.retry, poll=RULES.poll, run_timeout=1e12)
    return RunRules(**{**base, **changes})


def make_world(tables=None, **changes) -> World:
    return World(tables, rules(**changes))


def set_behaviour(
    world: World,
    behaviour: str,
    workers: Iterable[str] = WORKERS,
    attempts: Iterable[int] = ATTEMPTS,
) -> None:
    for worker in workers:
        for attempt in attempts:
            world.pod_behaviour[(worker, attempt)] = behaviour


def hang_all(world: World) -> None:
    set_behaviour(world, "hang")


def wait_until(condition: Callable[[], bool], timeout: float = 15) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if condition():
            return
        time.sleep(0.005)
    raise AssertionError("condition not reached")


def key_of(world: World, source_table: str) -> str:
    return next(
        str(t.key) for t in world.registry.tables if t.key.source_table == source_table
    )


def keys_of(world: World, *source_tables: str) -> list:
    return [key_of(world, name) for name in source_tables]


def seed_run(
    world: World,
    run_id: str,
    status: str = "running",
    age: float = 0,
    started_at: float = 1,
    merge: bool = True,
    keys: Dict[str, TableState] | None = None,
) -> RunState:
    """A run another replica left in the state store; `age` is how long ago
    its heartbeat was."""
    from app.domain.run import RunStatus

    tables = {k: TableRun(s, 1) for k, s in (keys or {}).items()}
    state = RunState(
        run_id,
        Period(PERIOD.start, PERIOD.end),
        started_at,
        world.clock.now() - age,
        merge=merge,
        status=RunStatus(status),
        tables=tables,
        counts=RunCounts(total=len(tables)),
    )
    world.states.create(state)
    return state


def only_run_id(world: World) -> str:
    wait_until(lambda: len(world.states.items) == 1)
    return next(iter(world.states.items))

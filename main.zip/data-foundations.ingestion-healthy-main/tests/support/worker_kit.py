"""Helpers for the worker/comparison tests: one table processed at a time."""

from __future__ import annotations

import datetime as dt
import json
from typing import Callable, Dict, Optional

from app.adapters.outbound.postgres import progress_codec as codec
from app.application.concurrency import SingleFlight
from app.application.ports.origin import OriginStats
from app.application.use_cases.comparers import (
    DailyComparer,
    IdComparer,
    WholeTableComparer,
)
from app.application.use_cases.origin_day_counter import OriginDayCounter
from app.application.use_cases.process_table import ProcessTable
from app.application.use_cases.progress_recorder import ProgressRecorder
from app.domain.entities import MonitoredTable
from app.domain.policies import RetryPolicy, WindowPlanner
from app.domain.progress import WorkerProgress
from app.domain.values import Criterion, Period
from tests.support.fakes import (
    Behaviour,
    FakeClock,
    FakeLake,
    FakeOrigin,
    MemoryProgressStore,
    WorkerClock,
)

BIG = OriginStats(2_500_000_000, True)
RETRY = RetryPolicy(3, (1, 2))


class ScriptedOrigin(FakeOrigin):
    """An origin whose day counts per window are decided by a function."""

    def __init__(self, behaviour: Behaviour, window: Callable) -> None:
        super().__init__(behaviour, "s", "h")
        self.window = window

    def count_by_day(self, table, column, start, end_exclusive, timeout_seconds):
        self.world.windows.append((table.table, start, end_exclusive, timeout_seconds))
        return self.window(start, end_exclusive)


def one_per_day(start: dt.date, end: dt.date) -> Dict[dt.date, int]:
    return {start + dt.timedelta(days=i): 1 for i in range((end - start).days)}


class JsonStore(MemoryProgressStore):
    """Serialises every save like the database does: a torn dict would fail here."""

    def __init__(self) -> None:
        super().__init__()
        self.saves = 0

    def save_worker(self, run_id, progress) -> None:
        json.dumps(codec.worker_to(progress))
        self.saves += 1
        super().save_worker(run_id, progress)


def new_counter(chunk_days: int = 15, min_rows: int = 10**9) -> OriginDayCounter:
    return OriginDayCounter(WindowPlanner(chunk_days, min_rows), SingleFlight(), 60, 30)


def processor(
    sleeps: Optional[list] = None, counter: Optional[OriginDayCounter] = None
) -> ProcessTable:
    comparers = {
        Criterion.DATE: DailyComparer(counter or new_counter()),
        Criterion.ID: IdComparer(),
        Criterion.TOTAL: WholeTableComparer(),
    }
    sink = sleeps if sleeps is not None else []
    return ProcessTable(comparers, RETRY, sink.append)


def recorder(store: Optional[MemoryProgressStore] = None) -> ProgressRecorder:
    clock = WorkerClock(FakeClock())
    progress = WorkerProgress("w1", "A", "1")
    return ProgressRecorder(store or MemoryProgressStore(), "run", progress, clock)


class Outcome:
    """What one table ended as, read from the recorder."""

    def __init__(self, rec: ProgressRecorder, table: MonitoredTable) -> None:
        key = str(table.key)
        self.progress = rec.table(key)
        self.result = rec.progress.results[key]


def process(
    table: MonitoredTable,
    period: Period,
    behaviour: Behaviour,
    lake: Optional[FakeLake] = None,
    origin: Optional[FakeOrigin] = None,
    sleeps: Optional[list] = None,
) -> Outcome:
    rec = recorder()
    reader = origin or FakeOrigin(behaviour, table.secret, table.host)
    processor(sleeps).run(table, period, reader, lake or FakeLake(behaviour), rec)
    return Outcome(rec, table)

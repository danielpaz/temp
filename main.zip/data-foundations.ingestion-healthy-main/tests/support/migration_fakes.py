"""An in-memory MigrationValidations and a small, well-formed validation document."""

from __future__ import annotations

import copy
from typing import Dict, List, Optional, Sequence

from app.application.ports.migration import MigrationValidations
from app.application.read_models import MigrationOverviewRow
from app.domain.migration import MigrationDatabase, ValidationRun


class MemoryMigrationValidations(MigrationValidations):
    def __init__(self) -> None:
        self.databases: Dict[str, MigrationDatabase] = {}
        self.runs: List[tuple] = []

    def upsert_databases(self, databases: Sequence[MigrationDatabase]) -> int:
        for item in databases:
            self.databases[item.name] = item
        return len(databases)

    def database(self, name: str) -> Optional[MigrationDatabase]:
        return self.databases.get(name)

    def save_run(self, run: ValidationRun, actor: str) -> int:
        self.runs.append((run, actor))
        return len(self.runs)

    def latest_run(self, name: str) -> Optional[ValidationRun]:
        mine = [r for r, _ in self.runs if r.database == name]
        return mine[-1] if mine else None

    def overview(self) -> List[MigrationOverviewRow]:
        rows = []
        for name, db in sorted(self.databases.items()):
            run = self.latest_run(name)
            res = run.resources if run else {}
            rows.append(
                MigrationOverviewRow(
                    name,
                    db.host_sql,
                    db.host_postgresql,
                    db.note,
                    run.counts if run else None,
                    run.captured_at if run else None,
                    res.get("teleport_sql", ""),
                    res.get("teleport_sql_uri", ""),
                    res.get("teleport_aurora", ""),
                )
            )
        return rows


def sample_document(database: str = "MGM_REFERRAL") -> dict:
    """Two tables: one clean, one with a missing table in the target (red)."""
    ok = {
        "id": "C1",
        "title": "Tabela",
        "sev": "ok",
        "detail": "existe como public.code_used",
    }
    return copy.deepcopy(
        {
            "database": database,
            "src_db": database,
            "tgt_db": database.lower(),
            "tgt_schema": "public",
            "captured": "2026-10-13T15:10:00Z",
            "src_meta": {"engine": "Microsoft SQL Server 2019", "tz": "-03:00"},
            "tgt_meta": {"engine": "PostgreSQL 15.4", "tz": "UTC"},
            "tables": [
                {
                    "name": "dbo.code_used",
                    "tgt_name": "public.code_used",
                    "checks": [ok],
                    "findings": [],
                    "columns": [
                        {
                            "name": "CODE_USED_ID",
                            "src": "uniqueidentifier",
                            "tgt_name": "code_used_id",
                            "tgt": "uuid",
                            "exp": "uuid",
                            "nsrc": "NO",
                            "ntgt": "NO",
                            "status": "ok",
                            "detail": "",
                        }
                    ],
                    "src": {
                        "approx": 10,
                        "size": 1024,
                        "wm_col": "CREATED_AT_DT",
                        "wm_min": "2026-01-01",
                        "wm_max": "2026-10-13",
                        "exact": 10,
                        "cutoff": None,
                    },
                    "tgt": {
                        "approx": 10,
                        "size": 2048,
                        "wm_col": "created_at_dt",
                        "wm_min": "2026-01-01",
                        "wm_max": "2026-10-13",
                        "exact": 10,
                        "cutoff": None,
                    },
                    "count_caveat": False,
                    "note": None,
                },
                {
                    "name": "dbv.database_version",
                    "tgt_name": None,
                    "checks": [
                        {
                            "id": "C1",
                            "title": "Tabela",
                            "sev": "red",
                            "detail": "ausente no Aurora",
                        }
                    ],
                    "findings": [
                        {
                            "check": "C1",
                            "sev": "red",
                            "column": None,
                            "src": None,
                            "tgt": None,
                            "detail": "tabela ausente no Aurora",
                            "expected": False,
                        }
                    ],
                    "columns": [],
                    "src": {
                        "approx": 0,
                        "size": 0,
                        "wm_col": None,
                        "wm_min": None,
                        "wm_max": None,
                        "exact": None,
                        "cutoff": None,
                    },
                    "tgt": None,
                    "count_caveat": False,
                    "note": None,
                },
            ],
            "db_findings": [
                {
                    "check": "C0",
                    "sev": "yellow",
                    "title": "Conversão de schema (SCT)",
                    "detail": "sem evidência",
                }
            ],
            "res": {"teleport_sql": "VASPAWP-DBCAD01", "sct_answer": "não sei"},
        }
    )

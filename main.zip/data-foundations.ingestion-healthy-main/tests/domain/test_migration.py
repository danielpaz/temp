import pytest

from app.domain.exceptions import InvalidRequest
from app.domain.migration import MigrationDatabase, TableStatus
from app.domain.migration_document import from_document, to_document
from tests.support.migration_fakes import sample_document


def test_a_document_round_trips():
    doc = sample_document()
    assert to_document(from_document(doc)) == doc


def test_table_status_comes_from_the_findings_that_were_not_expected():
    run = from_document(sample_document())
    assert {t.name: t.status for t in run.tables} == {
        "dbo.code_used": TableStatus.OK,
        "dbv.database_version": TableStatus.ATTENTION,
    }
    assert run.counts.attention == 1 and run.counts.ok == 1
    assert run.status is TableStatus.ATTENTION


def test_an_expected_finding_does_not_count():
    doc = sample_document()
    doc["tables"][1]["findings"][0]["expected"] = True
    assert from_document(doc).counts.attention == 0


def test_tables_are_ordered_worst_first():
    names = [t.name for t in from_document(sample_document()).ordered_tables()]
    assert names == ["dbv.database_version", "dbo.code_used"]


def test_verifications_summarise_each_kind_of_check():
    (summary,) = from_document(sample_document()).verifications()
    assert (summary.title, summary.total, summary.ok, summary.red) == (
        "Tabela",
        2,
        1,
        1,
    )


@pytest.mark.parametrize(
    "mutate",
    [
        lambda d: d.pop("database"),
        lambda d: d.update(tables=[]),
        lambda d: d.update(captured="ontem"),
        lambda d: d["tables"][0]["checks"][0].update(sev="purple"),
        lambda d: d.update(src_meta=None),
        lambda d: d["tables"][0]["src"].update(approx="muitas"),
    ],
)
def test_a_malformed_document_is_refused(mutate):
    doc = sample_document()
    mutate(doc)
    with pytest.raises(InvalidRequest):
        from_document(doc)


def test_database_names_are_validated():
    with pytest.raises(InvalidRequest):
        MigrationDatabase("bad name; drop")

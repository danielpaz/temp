import datetime as dt

import pytest

from app.domain.exceptions import PermanentError
from app.domain.policies import RetryPolicy, WindowPlanner, halves, run_with_retry
from app.domain.values import Period

D = dt.date


def test_succeeds_after_transient_failures_with_backoff():
    calls, sleeps = [], []

    def work(attempt):
        calls.append(attempt)
        if attempt < 3:
            raise RuntimeError("boom")
        return "ok"

    out = run_with_retry(work, RetryPolicy(3, (5, 15)), sleep=sleeps.append)
    assert (out.result, out.error, out.attempts_used) == ("ok", None, 3)
    assert sleeps == [5, 15]


def test_gives_up_with_the_last_error():
    sleeps = []
    out = run_with_retry(lambda _: 1 / 0, RetryPolicy(3, (1,)), sleep=sleeps.append)
    assert out.result is None and out.attempts_used == 3
    assert "ZeroDivisionError" in out.error
    assert sleeps == [1, 1]


def test_permanent_errors_are_not_retried():
    calls = []

    def work(attempt):
        calls.append(attempt)
        raise PermanentError("table not found")

    out = run_with_retry(work, RetryPolicy(3, (1,)), sleep=lambda _: None)
    assert (out.result, out.error, out.attempts_used, calls) == (
        None,
        "table not found",
        1,
        [1],
    )


def test_windows_cover_the_period_exactly():
    period = Period(D(2026, 7, 8), D(2026, 10, 5))
    w = WindowPlanner(15, 0).windows(period, True)
    assert len(w) == 6
    assert (w[0][0], w[-1][1]) == (D(2026, 7, 8), D(2026, 10, 6))
    assert all(w[i][1] == w[i + 1][0] for i in range(len(w) - 1))
    assert sum((b - a).days for a, b in w) == 90


def test_the_last_window_is_the_remainder_and_short_periods_are_one_window():
    planner = WindowPlanner(15, 0)
    last = planner.windows(Period(D(2026, 1, 1), D(2026, 1, 31)), True)
    assert [(b - a).days for a, b in last] == [15, 15, 1]
    assert len(planner.windows(Period(D(2026, 1, 1), D(2026, 1, 10)), True)) == 1
    whole = planner.windows(Period(D(2026, 1, 1), D(2026, 1, 31)), False)
    assert whole == [(D(2026, 1, 1), D(2026, 2, 1))]


@pytest.mark.parametrize(
    "rows, index, days, chunk",
    [
        (2_500_000_000, True, 90, True),
        (2_500_000_000, False, 90, False),  # no index: N windows = N full scans
        (5_000_000, True, 90, False),  # small tables stay a single query
        (2_500_000_000, True, 15, False),  # a period that fits one window
    ],
)
def test_only_big_indexed_tables_over_long_periods_are_split(rows, index, days, chunk):
    planner = WindowPlanner(15, 1_000_000_000)
    assert planner.should_chunk(rows, index, days) is chunk


def test_halves_split_a_window_in_two_contiguous_pieces():
    first, second = halves(D(2026, 1, 1), D(2026, 1, 16))
    assert first == (D(2026, 1, 1), D(2026, 1, 8))
    assert second == (D(2026, 1, 8), D(2026, 1, 16))
    assert halves(D(2026, 1, 1), D(2026, 1, 3)) == (
        (D(2026, 1, 1), D(2026, 1, 2)),
        (D(2026, 1, 2), D(2026, 1, 3)),
    )

import pytest

from app.domain.engines import engine_label
from app.domain.exceptions import InvalidRequest
from app.domain.registry_rules import clean_names, clean_tags
from app.domain.values import TableKey


def test_names_are_trimmed_validated_and_required():
    ok = clean_names(
        {
            "source_database": " CDB ",
            "target_catalog": "trusted_zone",
            "used_secret": "prod/engenhariadedados/sql-server/pix",
            "date_field": " RegisterDate ",
        }
    )
    assert ok == {
        "source_database": "CDB",
        "target_catalog": "trusted_zone",
        "used_secret": "prod/engenhariadedados/sql-server/pix",
        "date_field": "RegisterDate",
    }


def test_an_empty_date_column_means_none():
    assert clean_names({"date_field": "  "}) == {"date_field": None}


@pytest.mark.parametrize(
    "bad",
    [
        {"source_table": "a b"},
        {"source_schema": "x;drop"},
        {"target_table": "t'"},
        {"used_secret": "has space"},
        {"date_field": "1abc"},
        {"source_database": ""},
    ],
)
def test_invalid_names_are_rejected(bad):
    with pytest.raises(InvalidRequest):
        clean_names(bad)


def test_a_required_name_must_be_given():
    with pytest.raises(InvalidRequest):
        clean_names({}, required=("source_table",))


def test_tags_are_deduplicated_sorted_and_limited():
    assert clean_tags([" b", "a", "a"]) == ["a", "b"]


@pytest.mark.parametrize(
    "bad",
    ["a,b", ["com espaço"], ["x"] * 3 + ["y" * 41], [str(i) for i in range(21)], [1]],
)
def test_invalid_tags_are_rejected(bad):
    with pytest.raises(InvalidRequest):
        clean_tags(bad)


def test_key_has_origin_and_trino_table():
    key = TableKey.parse("A.public.t@trusted.x.dbo_t")
    assert (key.source_database, key.source_schema, key.source_table) == (
        "A",
        "public",
        "t",
    )
    assert (key.target_catalog, key.target_schema, key.target_table) == (
        "trusted",
        "x",
        "dbo_t",
    )


@pytest.mark.parametrize("bad", ["A.public.t", "A.public.t@x.y", "@a.b.c"])
def test_incomplete_keys_are_rejected(bad):
    with pytest.raises(InvalidRequest):
        TableKey.parse(bad)


def test_a_view_and_its_base_table_are_two_rows_of_the_same_origin():
    table = TableKey("A", "p", "t", "trusted_zone", "s", "p_t")
    view = TableKey("A", "p", "t", "trusted", "a", "dbo_t")
    assert table != view
    assert str(table) != str(view)
    assert table.source_name == view.source_name
    assert TableKey.parse(str(view)) == view


def test_engine_labels():
    names = (
        "prod/x/postgresql/a",
        "prod/x/sql-server/b",
        "prod/engenhariadedados/trino/catalog/pix",
        "prod/x/other",
    )
    assert [engine_label(n) for n in names] == [
        "PostgreSQL",
        "SQL Server",
        "SQL Server",
        "",
    ]

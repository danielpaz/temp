# Ingestion Healthy

Volume-based ingestion health check: compares per-day, per-id and total row
counts between PostgreSQL / SQL Server origins and the Trino lake.

## Architecture (hexagonal)

```
app/
  domain/        entities, values, run state machines, policies (no I/O)
  application/   ports (interfaces) and use cases
  adapters/
    inbound/     http (FastAPI), worker (pod entrypoint)
    outbound/    postgres, origins, trino, aws (Secrets Manager), kubernetes
  config/        Settings (pydantic-settings, environment)
  bootstrap/     Container (dependency-injector): the only place that knows
                 concrete classes
migrations/      SQL for the app database (schema ingestion_healthy)
deploy/k8s/      RBAC, service account and the reference web manifest
```

Dependencies point inwards: adapters depend on ports, never the opposite.
A new database engine is one `OriginReader` adapter registered in the origin
factory; a new comparison criterion is one `TableComparer`.

## Runs

The web pod supervises a run and launches one worker pod per origin instance.
Workers use the **same image** with another entrypoint:

```
uvicorn app.main:app                 # web
python -m app.adapters.inbound.worker # worker (env: RUN_ID, WORKER_ID, WORKER_HOST, WORKER_SECRET, POD_ATTEMPT)
```

Run state lives in ConfigMaps (`ih-state-<run_id>`); the plan, the progress of each
worker and cancel requests live in the app database (`run_plan`,
`run_worker_progress`, `run_cancel_request`, kept for 7 days).

## Migration tab

`/migration` shows the validation of SQL Server -> Aurora PostgreSQL migrations done with the
`sqlserver-aurora-compare` skill. Results are stored in the app database (migration 009).
After running the skill for a database, from the repo root, on your machine:

```
export MIGRATION_URL=https://<app host>
python -m app.adapters.inbound.cli.migration_import databases databases.csv
python -m app.adapters.inbound.cli.migration_import validation <result folder> \
    --database NAME --resources recursos.json [--dry-run]
```

Only the summary the page needs is sent (never the sample rows of the snapshots).

## Development

```
pipenv install --dev
make test        # pytest
flake8 app tests && mypy app
make run
```

Tests need no network: the use cases run end to end against in-memory fakes
(`tests/support/world.py` simulates the cluster and runs the real worker job).
Configuration is read from environment variables (see `app/config/settings.py`).
